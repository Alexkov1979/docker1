/*---------------------------------------------------------
* Copyright (C) Microsoft Corporation. All rights reserved.
*--------------------------------------------------------*/
"use strict";
exports.RESPONSIVE_EVENT = "responsive";
exports.SHOW_EVENT = "show";
exports.UNRESPONSIVE_EVENT = "unresponsive";
//# sourceMappingURL=browser-window.js.map