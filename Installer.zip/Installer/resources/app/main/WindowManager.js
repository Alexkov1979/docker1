/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../typings/globals/electron/github-electron/index.d.ts" />
/// <reference path="../typings/globals/node/index.d.ts" />
"use strict";
var electron_1 = require("electron");
var path = require("path");
var window_options_1 = require("../lib/window-options");
var WindowCaptureManager_1 = require("./WindowCaptureManager");
var browser_window_factory_1 = require("./browser-window-factory");
var browserWindowFactory = new browser_window_factory_1.BrowserWindowFactory();
function hideAllWindows() {
    var windows = electron_1.BrowserWindow.getAllWindows() || [];
    windows.forEach(function (window) { return window.hide(); });
}
exports.hideAllWindows = hideAllWindows;
// quit when all windows are closed.
/* istanbul ignore next */
function allWindowsClosed() {
    // on OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== "darwin") {
        electron_1.app.quit();
    }
}
electron_1.app.on("window-all-closed", allWindowsClosed);
// configure the window
var appVersion = electron_1.app.getVersion();
exports.rendererDir = path.join(path.dirname(__dirname), "renderer");
/* istanbul ignore next */
function handleIncomingArgs(branch, locale, additionalQueryParameters) {
    if (additionalQueryParameters) {
        var windowPageUrl = getWindowUrl(branch, locale, additionalQueryParameters);
        exports.mainWindow.loadURL(windowPageUrl);
    }
}
exports.handleIncomingArgs = handleIncomingArgs;
/* istanbul ignore next */
function loadMainPage(windowOptions, windowPageUrl, telemetry) {
    // create a window for the app
    exports.mainWindow = new electron_1.BrowserWindow(windowOptions);
    // hide the menu bar
    exports.mainWindow.setMenuBarVisibility(false);
    // load the main page of the app
    exports.mainWindow.loadURL(windowPageUrl);
    // This prevents the title from being changed
    exports.mainWindow.on("page-title-updated", function (e) {
        e.preventDefault();
    });
    // clean up when the window is closed. Don"t call quit()
    // since there might be other windows open.
    // app will shutdown when mainWindow is GC"d
    exports.mainWindow.on("closed", function () {
        exports.mainWindow = null;
    });
    if (telemetry) {
        telemetry.monitor(exports.mainWindow);
    }
    return exports.mainWindow;
}
/* istanbul ignore next */
function getWindowUrl(branch, locale, additionalQueryParameters) {
    var startPage = path.join(exports.rendererDir, "index.html");
    var queryOptions = { appVersion: appVersion, branch: branch, locale: locale };
    return browserWindowFactory.formatUrlWithQueryOptions(startPage, queryOptions, additionalQueryParameters);
}
/* istanbul ignore next */
function init(queryOptions, args, telemetry) {
    var startPageFileName = args.focusedUi ? "focused.html" : "index.html";
    var startPagePath = path.join(exports.rendererDir, startPageFileName);
    var windowPageUrl = browserWindowFactory.formatUrlWithQueryOptions(startPagePath, queryOptions, args.queryParameters);
    var isUninstallRoot = false;
    var windowOptions = window_options_1.convertArgsToWindowOptions(args.focusedUi, args.quiet, isUninstallRoot);
    return loadMainPage(windowOptions, windowPageUrl, telemetry);
}
exports.init = init;
/* istanbul ignore next */
function initUninstall(queryOptions, args, telemetry) {
    var startPage = path.join(exports.rendererDir, "uninstall.html");
    var windowPageUrl = browserWindowFactory.formatUrlWithQueryOptions(startPage, queryOptions, args.queryParameters);
    var isUninstallRoot = true;
    var isFocusedUi = false;
    var windowOptions = window_options_1.convertArgsToWindowOptions(isFocusedUi, args.quiet, isUninstallRoot);
    return loadMainPage(windowOptions, windowPageUrl, telemetry);
}
exports.initUninstall = initUninstall;
/* istanbul ignore next */
function minimize() {
    exports.mainWindow.minimize();
}
exports.minimize = minimize;
/* istanbul ignore next */
function maximizeOrRestore() {
    if (exports.mainWindow.isMaximized()) {
        exports.mainWindow.unmaximize();
    }
    else {
        exports.mainWindow.maximize();
    }
}
exports.maximizeOrRestore = maximizeOrRestore;
/* istanbul ignore next */
function getWindowScreenshot() {
    var windowCaptureManager = new WindowCaptureManager_1.WindowCaptureManager(exports.mainWindow);
    return windowCaptureManager.captureWindow();
}
exports.getWindowScreenshot = getWindowScreenshot;
/* istanbul ignore next */
function createQueryOptions(branch, locale, showDownlevelSkus, isAnotherInstanceRunning) {
    if (branch === void 0) { branch = ""; }
    if (locale === void 0) { locale = ""; }
    if (showDownlevelSkus === void 0) { showDownlevelSkus = false; }
    if (isAnotherInstanceRunning === void 0) { isAnotherInstanceRunning = false; }
    return {
        appVersion: appVersion,
        branch: branch,
        locale: locale,
        showDownlevelSkus: showDownlevelSkus,
        isAnotherInstanceRunning: isAnotherInstanceRunning
    };
}
exports.createQueryOptions = createQueryOptions;
//# sourceMappingURL=WindowManager.js.map