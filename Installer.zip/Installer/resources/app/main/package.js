/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
/* tslint:disable:no-var-requires no-require-imports */
var packageJson = require("../package.json");
/* tslint:enable */
exports.BRANCH_NAME = packageJson.branch;
exports.APPLICATION_NAME = packageJson.description;
exports.EXE_NAME = packageJson.name;
exports.EXE_VERSION = packageJson.version;
exports.ARP_DESCRIPTION = packageJson.arp_description;
//# sourceMappingURL=package.js.map