/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var electron_1 = require("electron");
var microsoft_servicehub_1 = require("microsoft-servicehub");
var servicehub_logger_adapter_1 = require("../lib/servicehub-logger-adapter");
var opt_in_experiments_1 = require("../lib/experiments/opt-in-experiments");
var experiments_ipc_rpc_service_1 = require("../lib/experiments/ipc/experiments-ipc-rpc-service");
var feedback_ipc_rpc_service_1 = require("../lib/feedback/feedback-ipc-rpc-service");
var feedback_info_1 = require("../lib/feedback/feedback-info");
var Logger_1 = require("../lib/Logger");
var user_data_store_factory_1 = require("./user-data-store-factory");
var experiments_adapter_1 = require("../lib/experiments/service-hub/experiments-adapter");
var experimentation_client_1 = require("../lib/experiments/service-hub/experimentation-client");
var experimentation_telemetry_adapter_1 = require("../lib/experiments/service-hub/experimentation-telemetry-adapter");
var Telemetry_1 = require("../lib/Telemetry/Telemetry");
var VSFeedbackIdentityProvider_1 = require("../main/VSFeedbackIdentityProvider");
var logger = Logger_1.getLogger();
var serviceHubLogger = new servicehub_logger_adapter_1.ServiceHubLoggerAdapter(logger);
var appReadyPromise = new Promise(function (resolve, reject) {
    electron_1.app.on("ready", function () {
        resolve();
    });
});
var _experimentsIpcService;
function getExperimentsIpcService(clientName, clientVersion, appData) {
    if (_experimentsIpcService) {
        logger.writeWarning("getExperimentsIpcService called more than once.");
        return _experimentsIpcService;
    }
    return _experimentsIpcService = appReadyPromise
        .then(function () {
        logger.writeVerbose("Starting ServiceHub Experimentation client.");
        appData = appData || user_data_store_factory_1.getUserDataStore();
        var hubClient = new microsoft_servicehub_1.HubClient(experimentation_client_1.experimentationServiceClientName, serviceHubLogger);
        return hubClient.requestService(experimentation_client_1.experimentationServiceName)
            .then(function (stream) {
            var service = new experimentation_client_1.ServiceHubExperimentationClient(stream, new experimentation_telemetry_adapter_1.ExperimentationTelemetryAdapter(Telemetry_1.telemetryConfiguration), logger, clientName, clientVersion);
            logger.writeVerbose("ServiceHub Experimentation client started.");
            return new experiments_adapter_1.ServiceHubExperimentsAdapter(service);
        })
            .catch(function (error) {
            logger.writeError("Experiments Ipc Service creation failed.\n     error: [" + error.name + "] " + error.message + " at " + error.stack);
            return null;
        })
            .then(function (adapter) {
            var cachedExperiments = new opt_in_experiments_1.OptInExperiments(appData.optInExperiments, appData.optOutExperiments, adapter);
            var service = new experiments_ipc_rpc_service_1.ExperimentsIpcRpcService(electron_1.ipcMain, experiments_ipc_rpc_service_1.EXPERIMENTS_SERVICE_CHANNEL, cachedExperiments, logger);
            logger.writeVerbose("Experiments Ipc Service started.");
            return service;
        })
            .catch(function (error) {
            _experimentsIpcService = null;
            throw error;
        });
    });
}
exports.getExperimentsIpcService = getExperimentsIpcService;
var _feedbackIpcRpcService;
function getFeedbackIpcRpcService(vsTelemetryListener, culture, uiCulture, branchName, exeName, exeVersion) {
    if (_feedbackIpcRpcService) {
        return _feedbackIpcRpcService;
    }
    return _feedbackIpcRpcService = VSFeedbackIdentityProvider_1.createVSFeedbackIdentityProvider(vsTelemetryListener)
        .then(function (identityProvider) {
        var feedbackInfo = new feedback_info_1.FeedbackInfoProvider({
            userId: identityProvider.userId,
            culture: culture,
            uiCulture: uiCulture,
            branchName: branchName,
            exeName: exeName,
            exeVersion: exeVersion
        });
        return new feedback_ipc_rpc_service_1.FeedbackIpcRpcService(electron_1.ipcMain, feedback_ipc_rpc_service_1.FEEDBACK_SERVICE_CHANNEL, feedbackInfo);
    })
        .catch(function (error) {
        _feedbackIpcRpcService = null;
        throw error;
    });
}
exports.getFeedbackIpcRpcService = getFeedbackIpcRpcService;
//# sourceMappingURL=ipc-rpc-factory.js.map