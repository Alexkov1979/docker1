/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/modules/yargs/index.d.ts" />
"use strict";
var fs = require("fs");
var path = require("path");
var url = require("url");
var yargs = require("yargs");
var CommandLine_1 = require("../../lib/CommandLine");
var errors_1 = require("../../lib/errors");
var nickname_utilities_1 = require("../../lib/nickname-utilities");
var string_utilities_1 = require("../../lib/string-utilities");
var requires = require("../../lib/requires");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var WindowsInstaller = require("../WindowsInstaller");
var CommandLineParser = (function () {
    function CommandLineParser(logger, showDialogOnError, errorHandlerFactory) {
        var _this = this;
        // define the commands supported by the installer
        this.supportedCommands = [
            {
                command: CommandLine_1.CommandNames.install,
                description: "Installs a product",
                ignoredOptions: [],
            },
            {
                command: CommandLine_1.CommandNames.modify,
                description: "Modifies an installed product",
                ignoredOptions: [
                    CommandLine_1.OptionNames.channelUri,
                    CommandLine_1.OptionNames.installChannelUri,
                    CommandLine_1.OptionNames.installCatalogUri,
                    CommandLine_1.OptionNames.layoutPath,
                    CommandLine_1.OptionNames.nickname,
                    CommandLine_1.OptionNames.productKey,
                ]
            },
            {
                command: CommandLine_1.CommandNames.update,
                description: "Updates an installed product",
                ignoredOptions: [
                    CommandLine_1.OptionNames.channelUri,
                    CommandLine_1.OptionNames.installChannelUri,
                    CommandLine_1.OptionNames.installCatalogUri,
                    CommandLine_1.OptionNames.layoutPath,
                    CommandLine_1.OptionNames.add,
                    CommandLine_1.OptionNames.remove,
                    CommandLine_1.OptionNames.focusedUi,
                    CommandLine_1.OptionNames.all,
                    CommandLine_1.OptionNames.allWorkloads,
                    CommandLine_1.OptionNames.includeRecommended,
                    CommandLine_1.OptionNames.includeOptional,
                    CommandLine_1.OptionNames.addProductLang,
                    CommandLine_1.OptionNames.removeProductLang,
                    CommandLine_1.OptionNames.nickname,
                ]
            },
            {
                command: CommandLine_1.CommandNames.repair,
                description: "Repairs an installed product",
                ignoredOptions: [
                    CommandLine_1.OptionNames.channelUri,
                    CommandLine_1.OptionNames.installChannelUri,
                    CommandLine_1.OptionNames.installCatalogUri,
                    CommandLine_1.OptionNames.layoutPath,
                    CommandLine_1.OptionNames.add,
                    CommandLine_1.OptionNames.remove,
                    CommandLine_1.OptionNames.focusedUi,
                    CommandLine_1.OptionNames.all,
                    CommandLine_1.OptionNames.allWorkloads,
                    CommandLine_1.OptionNames.includeRecommended,
                    CommandLine_1.OptionNames.includeOptional,
                    CommandLine_1.OptionNames.addProductLang,
                    CommandLine_1.OptionNames.removeProductLang,
                    CommandLine_1.OptionNames.nickname,
                    CommandLine_1.OptionNames.productKey,
                ]
            },
            {
                command: CommandLine_1.CommandNames.resume,
                description: "Resumes a partial installation, usually after a system reboot",
                ignoredOptions: [
                    CommandLine_1.OptionNames.channelUri,
                    CommandLine_1.OptionNames.installChannelUri,
                    CommandLine_1.OptionNames.installCatalogUri,
                    CommandLine_1.OptionNames.layoutPath,
                    CommandLine_1.OptionNames.add,
                    CommandLine_1.OptionNames.remove,
                    CommandLine_1.OptionNames.focusedUi,
                    CommandLine_1.OptionNames.all,
                    CommandLine_1.OptionNames.allWorkloads,
                    CommandLine_1.OptionNames.includeRecommended,
                    CommandLine_1.OptionNames.includeOptional,
                    CommandLine_1.OptionNames.addProductLang,
                    CommandLine_1.OptionNames.removeProductLang,
                    CommandLine_1.OptionNames.nickname,
                ],
            },
            {
                command: CommandLine_1.CommandNames.uninstall,
                description: "Uninstalls an installed product",
                ignoredOptions: [
                    CommandLine_1.OptionNames.channelUri,
                    CommandLine_1.OptionNames.installChannelUri,
                    CommandLine_1.OptionNames.installCatalogUri,
                    CommandLine_1.OptionNames.layoutPath,
                    CommandLine_1.OptionNames.add,
                    CommandLine_1.OptionNames.remove,
                    CommandLine_1.OptionNames.focusedUi,
                    CommandLine_1.OptionNames.all,
                    CommandLine_1.OptionNames.allWorkloads,
                    CommandLine_1.OptionNames.includeRecommended,
                    CommandLine_1.OptionNames.includeOptional,
                    CommandLine_1.OptionNames.addProductLang,
                    CommandLine_1.OptionNames.removeProductLang,
                    CommandLine_1.OptionNames.nickname,
                    CommandLine_1.OptionNames.productKey,
                    CommandLine_1.OptionNames.cache,
                    CommandLine_1.OptionNames.nocache,
                ]
            },
            {
                command: CommandLine_1.CommandNames.reportaproblem,
                description: "Launches VS Feedback Report A Problem console and exits",
                hidden: true,
                ignoredOptions: []
            },
            {
                command: CommandLine_1.CommandNames.collectdiagnostics,
                description: "Launches VS Diagnostics Data Collection and exits",
                hidden: true,
                ignoredOptions: []
            }
        ];
        // define the options supported by the installer
        this.supportedOptions = [
            {
                name: CommandLine_1.OptionNames.installPath,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The installation directory for the instance to act upon. " +
                        "For the install command, this is where the instance will be installed. " +
                        "For other commands, this is where the previously-installed instance was installed."
                }
            },
            {
                name: CommandLine_1.OptionNames.productId,
                implies: CommandLine_1.OptionNames.channelId,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The ID of the product for the instance that will be installed. " +
                        "This is required for the install command, " +
                        "ignored for other commands if --installPath is specified."
                }
            },
            {
                name: CommandLine_1.OptionNames.channelId,
                implies: CommandLine_1.OptionNames.productId,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The ID of the channel for the instance that will be installed. " +
                        "This is required for the install command, " +
                        "ignored for other commands if --installPath is specified."
                }
            },
            {
                name: CommandLine_1.OptionNames.channelUri,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: false,
                    description: "The URI of the channel manifest.  This can be used for the install " +
                        "command; it is ignored for other commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.installChannelUri,
                supportRelativePath: true,
                // --installChannelUri requires --channelUri, but we can't use the "implies" functionality because
                // yargs will throw an "implications failed" error if --channelUri is specified without an argument.
                // We'll handle this implication explicitly in emitErrors.
                // implies: OptionNames.channelUri,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The URI of the channel manifest to use for the installation.  " +
                        "The URI specified by --channelUri (which must be specified when " +
                        "--installChannelUri is specified) will be used to detect updates.  " +
                        "If updates are not desired, --channelUri must be specified without an argument.  " +
                        "This can be used for the install command; it is ignored for other commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.installCatalogUri,
                supportRelativePath: true,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The URI of the catalog manifest to use for the installation.  If specified, " +
                        "the channel manager will attempt to download the catalog manifest from this URI " +
                        "before using the URI in the install channel manifest.  This parameter is used " +
                        "to support offline install, where the layout cache will be created with " +
                        "the product catalog already downloaded.  This can be used for the install command; " +
                        "it is ignored for other commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.layoutPath,
                supportRelativePath: true,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The layout directory to check for packages before attempting to download them using " +
                        "the location in the manifest. This can be used for the install command; it is ignored " +
                        "for other commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.add,
                multiInstance: true,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "This defines an artifact (group, workload, or component) that is to be " +
                        "added to the installation.  It can appear multiple times on the command line. " +
                        "\n\nThe required components of the artifact are installed, but not the recommended or optional " +
                        "components. You can control additional components globally using --includeRecommended and/or " +
                        '--includeOptional. For finer-grained control, you can append ";includeRecommended" and/or ' +
                        '";includeOptional" to the artifactId (e.g. "--add Workload1;includeRecommended" or ' +
                        '"--add Workload2;includeOptional;includeRecommended").\n\n' +
                        "It is optional for the install and modify commands, ignored for the update, " +
                        "repair and uninstall commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.remove,
                multiInstance: true,
                excludes: [CommandLine_1.OptionNames.focusedUi],
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "This defines an artifact (group, workload, or component) that is to be " +
                        "removed from the installation.  It can appear multiple times on the command line. " +
                        "It is optional for the install and modify commands, ignored for the update, " +
                        "repair and uninstall commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.all,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Installs all workloads and all components.",
                },
            },
            {
                name: CommandLine_1.OptionNames.allWorkloads,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Installs all workloads and their required components, " +
                        "no recommended or optional components.",
                },
            },
            {
                name: CommandLine_1.OptionNames.includeRecommended,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Includes the recommended components for any workloads that are installed, " +
                        "but not the optional components.  The workloads are specified either with " +
                        "--allWorkloads or --add.",
                },
            },
            {
                name: CommandLine_1.OptionNames.includeOptional,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Includes the optional components for any workloads that are installed, " +
                        "but not the recommended components.  The workloads are specified either with " +
                        "--allWorkloads or --add.",
                },
            },
            {
                name: CommandLine_1.OptionNames.campaign,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The identifier of the campaign, for campaign tracking. If supplied, " +
                        "this ID will be logged with the installer's \"AppLaunched\" telemetry event."
                }
            },
            {
                name: CommandLine_1.OptionNames.activityId,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "An ID that can be used to correlate the installer command with an event in " +
                        "Visual Studio.  If supplied, this ID will be logged with the installer's " +
                        "\"AppLaunched\" event."
                }
            },
            {
                name: CommandLine_1.OptionNames.responseFile,
                prohibitedInResponseFile: true,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The URI or path to a response file"
                }
            },
            {
                name: CommandLine_1.OptionNames.version,
                options: {
                    alias: CommandLine_1.OptionAliases.version,
                    required: false,
                    requiresArg: false,
                    description: "Writes the application's version number to the console and exits"
                }
            },
            {
                name: CommandLine_1.OptionNames.passive,
                excludes: [
                    CommandLine_1.OptionNames.quiet,
                    CommandLine_1.OptionNames.focusedUi
                ],
                options: {
                    alias: CommandLine_1.OptionAliases.passive,
                    required: false,
                    requiresArg: false,
                    description: "If present, the command proceeds with UI, immediately and without user interaction. " +
                        "This option cannot be used with --quiet."
                }
            },
            {
                name: CommandLine_1.OptionNames.quiet,
                excludes: [
                    CommandLine_1.OptionNames.passive,
                    CommandLine_1.OptionNames.focusedUi
                ],
                options: {
                    alias: CommandLine_1.OptionAliases.quiet,
                    required: false,
                    requiresArg: false,
                    description: "If present, the command proceeds without UI.  Progress messages are written to stdout " +
                        "and error messages are written to stderr.  This option cannot be used with --passive."
                }
            },
            {
                name: CommandLine_1.OptionNames.noRestart,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "If present, commands with --passive or --quiet will not automatically restart the " +
                        "machine (if required).  This is ignored if neither --passive nor --quiet are specified."
                }
            },
            {
                name: CommandLine_1.OptionNames.locale,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The locale to be displayed on the GUI."
                }
            },
            {
                name: CommandLine_1.OptionNames.focusedUi,
                implies: CommandLine_1.OptionNames.add,
                excludes: [
                    CommandLine_1.OptionNames.quiet,
                    CommandLine_1.OptionNames.passive,
                    CommandLine_1.OptionNames.remove
                ],
                options: {
                    required: false,
                    requiresArg: false,
                    description: "If present, a minimal GUI will be displayed for a client to review before commiting " +
                        "the operation. This option cannot be used with --passive, --quiet, or --remove."
                }
            },
            {
                name: CommandLine_1.OptionNames.installSessionId,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "The sessionId from a previous instance of the client, for telemetry."
                },
            },
            {
                name: CommandLine_1.OptionNames.runOnce,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Starts a new instance(process) of installer with current set of arguments " +
                        "except the runOnce argument."
                },
            },
            {
                name: CommandLine_1.OptionNames.addProductLang,
                multiInstance: true,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "This defines the language of an artifact (group, workload, or component) that is to be " +
                        "installed.  It can appear multiple times on the command line. " +
                        "It is optional for the install and modify commands, ignored for the update, " +
                        "repair and uninstall commands. If not present, the installation will use the machine locale."
                }
            },
            {
                name: CommandLine_1.OptionNames.removeProductLang,
                multiInstance: true,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "This defines the language of an artifact (group, workload, or component) that is to be " +
                        "removed.  It can appear multiple times on the command line. " +
                        "It is optional for the install and modify commands, ignored for the update, " +
                        "repair and uninstall commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.nickname,
                multiInstance: false,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "This defines the nickname to assign to an installed product. " +
                        ("The nickname cannot be longer than " + nickname_utilities_1.MAX_NICKNAME_LENGTH + " characters. ") +
                        "It is optional for the install command, ignored for the modify, update, " +
                        "repair and uninstall commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.noUpdateInstaller,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Prevents the installer from updating itself when quiet is specified. " +
                        "The installer will fail the command and return a non-zero exit code if noUpdateInstaller " +
                        "is specified with quiet when an installer update is required."
                },
            },
            {
                name: CommandLine_1.OptionNames.productKey,
                multiInstance: false,
                options: {
                    type: "string",
                    required: false,
                    requiresArg: true,
                    description: "This defines the product key to use for an installed product. It is composed of " +
                        "25 alphanumeric characters either in the format 'xxxxx-xxxxx-xxxxx-xxxxx-xxxxx' or " +
                        "'xxxxxxxxxxxxxxxxxxxxxxxxx'. It is optional for the install and update commands, ignored for" +
                        " the repair, modify and uninstall commands."
                }
            },
            {
                name: CommandLine_1.OptionNames.cache,
                excludes: [
                    CommandLine_1.OptionNames.nocache
                ],
                options: {
                    required: false,
                    requiresArg: false,
                    description: "If present, packages will be kept after being installed for subsequent repairs. " +
                        "This will override the global policy setting to be used for subsequent installs, " +
                        "repairs, or modifications. The default policy is to cache packages. " +
                        "This is ignored for the uninstall command."
                }
            },
            {
                name: CommandLine_1.OptionNames.nocache,
                excludes: [
                    CommandLine_1.OptionNames.cache
                ],
                options: {
                    required: false,
                    requiresArg: false,
                    description: "If present, packages will be be deleted after being installed or repaired. " +
                        "They will be downloaded again only if needed and deleted again after use. " +
                        "This will override the global policy setting to be used for subsequent installs, " +
                        "repairs, or modifications. The default policy is to cache packages. " +
                        "This is ignored for the uninstall command."
                }
            },
            {
                name: CommandLine_1.OptionNames.noWeb,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "No to any web download.",
                },
            },
            {
                name: CommandLine_1.OptionNames.force,
                options: {
                    required: false,
                    requiresArg: false,
                    description: "Force terminate any running Visual Studio processes.",
                },
            },
        ];
        this.supportedAliases = [];
        requires.notNullOrUndefined(logger, "logger");
        requires.notNullOrUndefined(errorHandlerFactory, "errorHandlerFactory");
        this._logger = logger;
        this._showDialogOnError = showDialogOnError;
        this._parser = this.createParser(errorHandlerFactory);
        this._errorHandler = errorHandlerFactory.createErrorHandler(this._parser, this._logger, this._showDialogOnError);
        this.supportedOptions.forEach(function (option) {
            if (option.options.alias) {
                if (Array.isArray(option.options.alias)) {
                    option.options.alias.forEach(function (alias) {
                        _this.supportedAliases.push(alias);
                    });
                }
                else {
                    _this.supportedAliases.push(option.options.alias);
                }
            }
        });
    }
    CommandLineParser.getParametersForResume = function (installPath, installSessionId, isQuiet, isPassive, productKey) {
        var launchParams = (CommandLine_1.CommandNames.resume + " --" + CommandLine_1.OptionNames.installPath + " ") +
            ("\"" + installPath + "\" --" + CommandLine_1.OptionNames.runOnce);
        if (installSessionId) {
            launchParams = launchParams.concat(" --" + CommandLine_1.OptionNames.installSessionId + " " + installSessionId);
        }
        if (isQuiet) {
            launchParams = launchParams.concat(" --" + CommandLine_1.OptionNames.quiet);
        }
        if (isPassive) {
            launchParams = launchParams.concat(" --" + CommandLine_1.OptionNames.passive);
        }
        if (productKey) {
            launchParams = launchParams.concat(" --" + CommandLine_1.OptionNames.productKey + " " + productKey);
        }
        return launchParams;
    };
    // This is used to determine whether we should show a dialog if there
    // is an error, which we need to determine BEFORE parsing.
    CommandLineParser.argsContainQuietOrPassive = function (args) {
        return args.some(function (s) {
            return string_utilities_1.caseInsensitiveAreEqual(s, "--" + CommandLine_1.OptionNames.quiet)
                || string_utilities_1.caseInsensitiveAreEqual(s, "--" + CommandLine_1.OptionNames.passive)
                || string_utilities_1.caseInsensitiveAreEqual(s, "--" + CommandLine_1.OptionAliases.quiet)
                || string_utilities_1.caseInsensitiveAreEqual(s, "--" + CommandLine_1.OptionAliases.passive)
                || string_utilities_1.caseInsensitiveAreEqual(s, "-" + CommandLine_1.OptionAliases.quiet)
                || string_utilities_1.caseInsensitiveAreEqual(s, "-" + CommandLine_1.OptionAliases.passive);
        });
    };
    /**
     * Returns an object containing the parsed values of command line arguments
     */
    CommandLineParser.prototype.parse = function (args, isDevBuild) {
        var _this = this;
        try {
            var isTestMode = args.some(function (arg) { return arg === "--" + CommandLine_1.OptionNames.testMode; });
            if (isTestMode) {
                this._logger.writeVerbose("CommandLineParser detected --test mode");
            }
            args = this.removeIgnoredArguments(args);
            var argv_1 = this._parser.parse(args);
            // normalize the command and put it in the object as a named property
            argv_1 = this.extractAndNormalizeCommand(argv_1);
            // normalize option names
            argv_1 = this.normalizeAndValidateOptionNames(argv_1, !isTestMode);
            // make sure the multi instance properties are arrays
            this.multiInstanceOptions.forEach(function (option) {
                argv_1[option.name] = _this.ensureArray(argv_1[option.name]);
            });
            // merge command line arguments with those from a response file (if we got one)
            argv_1 = this.mergeResponseFile(argv_1);
            // if an artifact is in both the add and remove lists, it is neither added nor removed
            argv_1 = this.clearOffsettingOptions(argv_1, CommandLine_1.OptionNames.add, CommandLine_1.OptionNames.remove);
            // if a language is in both the addProductLang and removeProductLang lists, it is neither added nor removed
            argv_1 = this.clearOffsettingOptions(argv_1, CommandLine_1.OptionNames.addProductLang, CommandLine_1.OptionNames.removeProductLang);
            // always enable debugging for a dev build
            if (isDevBuild) {
                argv_1.debug = true;
            }
            this.emitErrors(argv_1);
            this.emitWarnings(argv_1);
            // if we get this far, all is well with the command line/response
            // file -- generate the query string for use in the renderer
            this.computeQueryString(argv_1);
            return argv_1;
        }
        finally {
            yargs.reset();
        }
    };
    /**
     * Computes the query string for an object based on its contents
     */
    CommandLineParser.prototype.computeQueryString = function (argv) {
        // delete any existing query string properties
        delete argv.query;
        delete argv.queryParameters;
        var query = this.generateQueryString(argv);
        if (query) {
            argv.query = query;
            argv.queryParameters = query.substring(query.indexOf("?") + 1);
        }
    };
    /**
     * Removes a supported option from argument list. Note it wont remove a supported command.
     */
    CommandLineParser.prototype.removeOptionFromArgumentList = function (args, argToRemove) {
        requires.stringNotEmpty(argToRemove, "argToRemove");
        requires.notNullOrUndefined(args, "args");
        if (args.length === 0) {
            return args.slice();
        }
        if (this.findCommand(argToRemove) !== undefined) {
            throw new errors_1.InvalidParameterError("argToRemove cannot be a supported command");
        }
        var currentOption = this.findOption(argToRemove);
        if (currentOption === undefined) {
            throw new errors_1.InvalidParameterError("argToRemove is not a supported option");
        }
        var index = args.indexOf("--" + argToRemove);
        if (index === -1) {
            throw new errors_1.InvalidParameterError("argToRemove supplied is not present in the supplied argument list");
        }
        var resultArgs = args.slice();
        var isLastArg = (resultArgs.length - 1) === index;
        // Remove the argument of the option if it has one
        if (!isLastArg && args[index + 1].charAt(0) !== "-") {
            resultArgs.splice(index + 1, 1);
        }
        // Remove the option
        resultArgs.splice(index, 1);
        return resultArgs;
    };
    CommandLineParser.prototype.isSupportedAlias = function (name) {
        return this.supportedAliases.some(function (alias) {
            return string_utilities_1.caseInsensitiveAreEqual(alias, name);
        });
    };
    /* tslint:disable:max-line-length */
    CommandLineParser.prototype.normalizeAndValidateProductKey = function (productKey) {
        // We need to handle the case where the user passes in multiple product keys
        if (Array.isArray(productKey)) {
            this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.multipleInstancesOfASingleInstanceParameter(CommandLine_1.OptionNames.productKey));
        }
        // verify that the product key is a 25 character alphanumeric string
        var alphaNumeric = "[0-9a-zA-Z]";
        var withHyphens = new RegExp("^" + alphaNumeric + "{5}-" + alphaNumeric + "{5}-" + alphaNumeric + "{5}-" + alphaNumeric + "{5}-" + alphaNumeric + "{5}$");
        var withoutHyphens = new RegExp("^" + alphaNumeric + "{25}$");
        if (productKey.match(withHyphens)) {
            return productKey.replace(/-/g, "");
        }
        if (productKey.match(withoutHyphens)) {
            return productKey;
        }
        this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.invalidProductKeyError(productKey));
    };
    /* tslint: enable */
    CommandLineParser.prototype.generateQueryString = function (argv) {
        // trim down argv, removing undefined properties and those that aren't
        // pertinent to the query string
        var queryObject = {};
        Object.keys(argv).forEach(function (key) {
            if (argv[key] === undefined) {
                return;
            }
            switch (key) {
                case "_":
                case "$0":
                case "help":
                // Exclude --locale because we handle --locale with argv.locale in Main.ts
                case CommandLine_1.OptionNames.locale:
                case CommandLine_1.OptionNames.responseFile:
                    break;
                case CommandLine_1.OptionNames.add:
                case CommandLine_1.OptionNames.remove:
                case CommandLine_1.OptionNames.addProductLang:
                case CommandLine_1.OptionNames.removeProductLang:
                    // the add or remove arrays might be empty; only include them if they're not
                    if (argv[key].length) {
                        queryObject[key] = argv[key];
                    }
                    break;
                default:
                    queryObject[key] = argv[key];
                    break;
            }
        });
        var formatObject = {
            query: queryObject
        };
        // if we got a command add it to the query string
        var command = argv[CommandLine_1.CommandNames.propertyName];
        if (command) {
            formatObject.pathname = "/" + command;
        }
        return url.format(formatObject);
    };
    /**
     * Removes the command line arguments that apply to the installer itself
     * (those are handled separately)
     */
    CommandLineParser.prototype.removeIgnoredArguments = function (args) {
        var ignoredArguments = [
            "--debug",
            WindowsInstaller.getInstallerFinalizeInstallParameter().toLowerCase(),
            WindowsInstaller.getInstallerUninstallParameter().toLowerCase(),
            WindowsInstaller.getInstallerUpdateParameter().toLowerCase(),
            WindowsInstaller.getInstallerFinalizeUpdateParameter().toLowerCase()
        ];
        return args.filter(function (arg) {
            arg = arg.toLowerCase();
            // ignore the argument if it begins with one of the ignored args
            var index = ignoredArguments.findIndex(function (ignoredArg) { return arg.startsWith(ignoredArg); });
            return (index === -1);
        });
    };
    /**
     * Removes artifacts that appear in both array parameters
     */
    CommandLineParser.prototype.clearOffsettingOptions = function (argv, optionName1, optionName2) {
        var option1Array = argv[optionName1];
        var option2Array = argv[optionName2];
        for (var i = 0; i < option1Array.length; i++) {
            var indexInRemove = option2Array.indexOf(option1Array[i]);
            if (indexInRemove !== -1) {
                option1Array.splice(i--, 1);
                option2Array.splice(indexInRemove, 1);
            }
        }
        argv[optionName1] = option1Array;
        argv[optionName2] = option2Array;
        return argv;
    };
    /**
     * yargs' parsing isn't case sensitive.  What this means is that if you define
     * a boolean option named "Foo" and pass "--foo" on the command line, yargs will
     * accept the option and add argv.foo with a value of true.  Other code will
     * be looking for argv.Foo, so we need to make sure all of the properties on
     * argv match the expected casing.
     */
    CommandLineParser.prototype.normalizeAndValidateOptionNames = function (argv, throwOnError) {
        var _this = this;
        var normalizedArgv = {
            $0: argv.$0,
            _: argv._,
        };
        // The command is normalized in extractAndNormalizeCommand
        normalizedArgv[CommandLine_1.CommandNames.propertyName] = argv[CommandLine_1.CommandNames.propertyName];
        // Map of arrays to handle multiple, differing cases for each multiInstance option.
        var multiInstanceArrayMap = {};
        this.multiInstanceOptions.forEach(function (option) {
            multiInstanceArrayMap[option.name] = [];
        });
        Object.keys(argv).forEach(function (key) {
            // yargs adds all possible command line options to argv as properties, but
            // they'll be undefined if they weren't on the command line; we therefore
            // need to explicity compare to undefined instead of doing a falsey check
            if (argv[key] !== undefined) {
                switch (key) {
                    case "$0":
                    case "_":
                    case CommandLine_1.CommandNames.propertyName:
                        // already handled
                        break;
                    default:
                        // copy the value using the normalized key name
                        var option = _this.findOption(key);
                        if (option) {
                            if (!option.multiInstance) {
                                if (option.name === CommandLine_1.OptionNames.productKey) {
                                    normalizedArgv[option.name] = _this.normalizeAndValidateProductKey(argv[key]);
                                }
                                else {
                                    normalizedArgv[option.name] = argv[key];
                                }
                                break;
                            }
                            // merge the array parameters to handle multiple, differing cases
                            // (e.g. --add, --Add and --ADD)
                            if (Array.isArray(argv[key])) {
                                Array.prototype.push.apply(multiInstanceArrayMap[option.name], argv[key]);
                            }
                            else {
                                multiInstanceArrayMap[option.name].push(argv[key]);
                            }
                        }
                        else if (["help", "h", "?"].some(function (helpKey) { return string_utilities_1.caseInsensitiveAreEqual(key, helpKey); })) {
                            _this._errorHandler.emitHelp();
                        }
                        else if (!_this.isSupportedAlias(key)) {
                            if (throwOnError) {
                                _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.unsupportedOptionOnCommandLine(key));
                            }
                            else {
                                _this._logger.writeWarning("Ignoring unsupported command line option: --" + key);
                            }
                        }
                        break;
                }
            }
        });
        this.multiInstanceOptions.forEach(function (multiInstanceOption) {
            normalizedArgv[multiInstanceOption.name] = multiInstanceArrayMap[multiInstanceOption.name];
        });
        return normalizedArgv;
    };
    /**
     * The Yargs parser is case-insensitive since we don't call "strict()" on the parser,
     * so we need to normalize the command name. We also add the command back to the argv
     * object under the more readable key "command" to access later.
     */
    CommandLineParser.prototype.extractAndNormalizeCommand = function (argv) {
        if (argv._.length > 1) {
            this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.atMostOneCommandParameter);
        }
        if (argv._.length && argv._[0]) {
            var commandDescriptor = this.findCommand(argv._[0]);
            if (commandDescriptor) {
                argv[CommandLine_1.CommandNames.propertyName] = commandDescriptor.command;
            }
            else {
                this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.unsupportedCommandOnCommandLine(argv._[0]));
            }
        }
        // set argv._ to null to prevent other code from using the non-normalized version of the command
        argv._ = null;
        return argv;
    };
    /**
     * Merges the contents of a response file with command line arguments
     */
    CommandLineParser.prototype.mergeResponseFile = function (argv) {
        var responseFilePath = argv[CommandLine_1.OptionNames.responseFile];
        // if there's no response file, short out
        if (!responseFilePath) {
            return argv;
        }
        this.validateSingleInstanceOption(argv, CommandLine_1.OptionNames.responseFile);
        var responseFileContents = this.readResponseFile(responseFilePath);
        this.validateResponseFileContents(responseFileContents);
        argv = this.mergeResponseFileContents(argv, responseFileContents);
        return this.resolveRelativePaths(argv, responseFilePath);
    };
    CommandLineParser.prototype.readResponseFile = function (responseFilePath) {
        try {
            var contentsJson = fs.readFileSync(responseFilePath, "utf8");
            if (!contentsJson) {
                return undefined;
            }
            return JSON.parse(contentsJson);
        }
        catch (err) {
            this._errorHandler.emitError(err);
        }
    };
    CommandLineParser.prototype.validateResponseFileContents = function (responseFileContents) {
        var _this = this;
        if (!responseFileContents) {
            return;
        }
        Object.keys(responseFileContents).forEach(function (key) {
            // allow a comment key
            if (key === CommandLine_1.OptionNames.comment) {
                return;
            }
            // if the key isn't in the options list, fail
            var index = _this.supportedOptions.findIndex(function (option) { return key === option.name; });
            if (index === -1) {
                _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.unrecognizedOptionInResponseFile(key));
            }
            // if the key is in the options list but isn't supported in response files, fail
            if (_this.supportedOptions[index].prohibitedInResponseFile) {
                _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.unsupportedOptionInResponseFile(key));
            }
        });
    };
    CommandLineParser.prototype.mergeResponseFileContents = function (argv, responseFileContents) {
        var _this = this;
        if (!responseFileContents) {
            return argv;
        }
        // make sure the multiInstance properties in the response file are present and are arrays
        this.multiInstanceOptions.forEach(function (option) {
            responseFileContents[option.name] = _this.ensureArray(responseFileContents[option.name]);
        });
        // properties on the command line override properties in the response file
        Object.keys(argv).forEach(function (key) {
            // yargs adds all possible command line options to argv as properties, but
            // they'll be undefined if they weren't on the command line; we therefore
            // need to explicity compare to undefined instead of doing a falsey check
            if (argv[key] !== undefined) {
                switch (key) {
                    case CommandLine_1.OptionNames.add:
                        // add array is merged
                        argv[key].forEach(function (element) {
                            if (responseFileContents[key].indexOf(element) === -1) {
                                responseFileContents[key].push(element);
                            }
                            // a command line add overrides a response file remove
                            var index = responseFileContents[CommandLine_1.OptionNames.remove].indexOf(element);
                            if (index !== -1) {
                                responseFileContents[CommandLine_1.OptionNames.remove].splice(index, 1);
                            }
                        });
                        break;
                    case CommandLine_1.OptionNames.remove:
                        // remove array is merged
                        argv[key].forEach(function (element) {
                            if (responseFileContents[key].indexOf(element) === -1) {
                                responseFileContents[key].push(element);
                            }
                            // a command line remove overrides a response file add
                            var index = responseFileContents[CommandLine_1.OptionNames.add].indexOf(element);
                            if (index !== -1) {
                                responseFileContents[CommandLine_1.OptionNames.add].splice(index, 1);
                            }
                        });
                        break;
                    case CommandLine_1.OptionNames.addProductLang:
                        // addProductLang array is merged
                        argv[key].forEach(function (element) {
                            if (responseFileContents[key].indexOf(element) === -1) {
                                responseFileContents[key].push(element);
                            }
                            // a command line addProductLang overrides a response file removeProductLang
                            var index = responseFileContents[CommandLine_1.OptionNames.removeProductLang].indexOf(element);
                            if (index !== -1) {
                                responseFileContents[CommandLine_1.OptionNames.removeProductLang].splice(index, 1);
                            }
                        });
                        break;
                    case CommandLine_1.OptionNames.removeProductLang:
                        // removeProductLang array is merged
                        argv[key].forEach(function (element) {
                            if (responseFileContents[key].indexOf(element) === -1) {
                                responseFileContents[key].push(element);
                            }
                            // a command line removeProductLang overrides a response file addProductLang
                            var index = responseFileContents[CommandLine_1.OptionNames.addProductLang].indexOf(element);
                            if (index !== -1) {
                                responseFileContents[CommandLine_1.OptionNames.addProductLang].splice(index, 1);
                            }
                        });
                        break;
                    default:
                        responseFileContents[key] = argv[key];
                        break;
                }
            }
        });
        return responseFileContents;
    };
    /**
     * For options accepting relative paths: if the values are relative paths, resolves them to full paths using the
     * response file path. This is needed to support offline installation.
     */
    CommandLineParser.prototype.resolveRelativePaths = function (argv, responseFilePath) {
        var _this = this;
        requires.notNullOrUndefined(argv, "argv");
        requires.stringNotEmpty(responseFilePath, "responseFilePath");
        // Quick check to see if the arguments set contains any arguments that can support relative paths with values.
        var supportRelativePathOptions = this.supportedOptions.filter(function (option) {
            return option.supportRelativePath && argv[option.name];
        });
        if (supportRelativePathOptions.length <= 0) {
            return argv;
        }
        var directoryPath = path.dirname(responseFilePath);
        supportRelativePathOptions.forEach(function (option) { return _this.resolveRelativePath(argv, option.name, directoryPath); });
        return argv;
    };
    /**
     * If the given option value is a relative path, resolves it to full path using the given directory path.
     */
    CommandLineParser.prototype.resolveRelativePath = function (argv, optionName, directoryPath) {
        requires.notNullOrUndefined(argv, "argv");
        requires.stringNotEmpty(directoryPath, "directoryPath");
        var optionValue = argv[optionName];
        requires.notNullOrUndefined(optionValue, "argv[" + optionName + "]");
        // If the argument value is already an URL with protocol (https:// or file://), no-op.
        var valueUrl = url.parse(optionValue);
        if (valueUrl.protocol) {
            return;
        }
        if (path.isAbsolute(optionValue)) {
            return;
        }
        optionValue = path.resolve(path.normalize(path.join(directoryPath, optionValue)));
        argv[optionName] = optionValue;
    };
    CommandLineParser.prototype.ensureArray = function (value) {
        if (value === undefined) {
            return [];
        }
        if (Array.isArray(value)) {
            return value;
        }
        return [value];
    };
    /**
     * Evaluates the parsed arguments for error conditions.  If an error is detected,
     * a message is written to process.stderr and the process terminates.
     */
    CommandLineParser.prototype.emitErrors = function (argv) {
        var _this = this;
        // for options that require values, make sure the value is present
        var optionsRequiringArgs = this.supportedOptions.filter(function (option) { return option.options.requiresArg; });
        optionsRequiringArgs.forEach(function (option) {
            if (argv[option.name] === "") {
                _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.missingOptionValue(option.name));
            }
        });
        // if we got a command, make sure we have the required parameters
        var command = argv[CommandLine_1.CommandNames.propertyName];
        if (command) {
            var hasChannelIdAndProductId = argv[CommandLine_1.OptionNames.channelId] && argv[CommandLine_1.OptionNames.productId];
            switch (command) {
                case CommandLine_1.CommandNames.install:
                    // for the install command, make sure we also get --channelId and --productId
                    if (!hasChannelIdAndProductId) {
                        this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.installRequiresChannelIdAndProductId);
                    }
                    // if we got --nickname, make sure the nickname isn't too long
                    var nickname = argv[CommandLine_1.OptionNames.nickname];
                    if (nickname) {
                        if (!nickname_utilities_1.isValidNickname(nickname)) {
                            this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.invalidNicknameVerbose(nickname));
                        }
                        if (nickname.length > nickname_utilities_1.MAX_NICKNAME_LENGTH) {
                            this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.nicknameTooLong(nickname_utilities_1.MAX_NICKNAME_LENGTH));
                        }
                    }
                    break;
                case CommandLine_1.CommandNames.resume:
                    // for the resume command, it only needs --installPath
                    if (!argv[CommandLine_1.OptionNames.installPath]) {
                        this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.commandRequiresInstallPath(command));
                    }
                    break;
                // for other commands, we need either --installPath or --channelId/--productId
                case CommandLine_1.CommandNames.modify:
                case CommandLine_1.CommandNames.update:
                case CommandLine_1.CommandNames.repair:
                case CommandLine_1.CommandNames.uninstall:
                    if (!argv[CommandLine_1.OptionNames.installPath] && !hasChannelIdAndProductId) {
                        this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.commandRequiresInstallPathOrChannelIdAndProductId(command));
                    }
                    break;
            }
        }
        // if we got --installChannelUri, make sure we also got --channelUri
        if (argv[CommandLine_1.OptionNames.installChannelUri] && (argv[CommandLine_1.OptionNames.channelUri] === undefined)) {
            this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.installChannelUriRequiresChannelUri);
        }
        // If --channelUri was specified without an argument, its value will be "".  We can only accept
        // this if --installChannelUri was also specified.  In that case we'll convert it to null.
        if (argv[CommandLine_1.OptionNames.channelUri] === "") {
            if (argv[CommandLine_1.OptionNames.installChannelUri]) {
                argv[CommandLine_1.OptionNames.channelUri] = null;
            }
            else {
                this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.channelUriRequiresArgument);
            }
        }
        // make sure we don't have any conflicting args
        var optionsWithExclusions = this.supportedOptions.filter(function (option) { return !!option.excludes; });
        optionsWithExclusions.forEach(function (option) {
            // if the option wasn't specified, there's nothing to do
            if (!isSpecified(option)) {
                return;
            }
            option.excludes.forEach(function (excludedOptionName) {
                var excludedOption = _this.findOption(excludedOptionName);
                if (isSpecified(excludedOption)) {
                    _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.optionsAreMutuallyExclusive(option.name, excludedOptionName));
                }
            });
            function isSpecified(opt) {
                if (!opt) {
                    return false;
                }
                var value = argv[opt.name];
                if (!value) {
                    return false;
                }
                // for --add and --remove, if they aren't specified value will be an empty array
                if (Array.isArray(value) && (value.length === 0)) {
                    return false;
                }
                return true;
            }
        });
        // for options that imply others, make sure the implied option is also present
        var optionsWithImplications = this.supportedOptions.filter(function (option) { return !!option.implies; });
        optionsWithImplications.forEach(function (option) {
            if (argv[option.name] && (argv[option.implies] === undefined)) {
                _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.parameterRequiresAnotherParameter(option.name, option.implies));
            }
        });
        // make sure we didn't get multiple instances of single-instance options
        this.supportedOptions.forEach(function (option) {
            if (!option.multiInstance) {
                _this.validateSingleInstanceOption(argv, option.name);
            }
        });
        // make sure boolean properties have boolean values
        var booleanOptions = this.supportedOptions.filter(function (option) { return !option.options.requiresArg && (option.options.type !== "string"); });
        booleanOptions.forEach(function (option) {
            var value = argv[option.name];
            var type = typeof value;
            if ((type !== "boolean") && (type !== "undefined")) {
                _this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.parameterCannotHaveAValue(option.name, value));
            }
        });
    };
    /**
     * Evaluates the parsed arguments for conditions that should result in warnings.
     * If such a condition is detected, a message is written to process.stdout.
     */
    CommandLineParser.prototype.emitWarnings = function (argv) {
        var _this = this;
        // see if we got arguments that are ignored for the given command
        var command = argv[CommandLine_1.CommandNames.propertyName];
        if (command) {
            var descriptor = this.findCommand(command);
            for (var i = 0; i < descriptor.ignoredOptions.length; i++) {
                var ignoredOption = descriptor.ignoredOptions[i];
                if (argv[ignoredOption]) {
                    // if this an array but the array is empty, don't warn
                    if (Array.isArray(argv[ignoredOption]) && (argv[ignoredOption].length === 0)) {
                        continue;
                    }
                    this.emitWarning(ResourceStrings_1.ResourceStrings.ignoredOptionForCommand(command, ignoredOption));
                }
            }
            // special case:  for commands other than install, if we got --installPath then we ignore
            // --channelId and --productId
            if ((command !== CommandLine_1.CommandNames.install) && argv[CommandLine_1.OptionNames.installPath]) {
                var optionsToIgnore = [
                    CommandLine_1.OptionNames.channelId,
                    CommandLine_1.OptionNames.productId
                ];
                optionsToIgnore.forEach(function (optionToIgnore) {
                    if (argv[optionToIgnore]) {
                        var message = ResourceStrings_1.ResourceStrings.ignoredOptionForCommandWithInstallPath(command, optionToIgnore);
                        _this.emitWarning(message);
                    }
                });
            }
        }
        // see if we got "--norestart" without "--passive" or "--quiet"
        var argvAsAny = argv;
        if (argvAsAny.norestart && !(argvAsAny.passive || argvAsAny.quiet)) {
            argvAsAny.norestart = false;
            this.emitWarning(ResourceStrings_1.ResourceStrings.noRestartOptionIgnored);
        }
    };
    /**
     * Creates a yargs parser for the installer command line
     */
    CommandLineParser.prototype.createParser = function (errorHandlerFactory) {
        var _this = this;
        var parser = yargs
            .usage("Usage: $0 [command [options]]")
            .fail(function (message) {
            var errorHandler = errorHandlerFactory.createErrorHandler(parser, _this._logger, _this._showDialogOnError);
            errorHandler.emitError(message);
            // this.onParseFailed(parser, message);
        });
        // define the commands
        for (var i = 0; i < this.supportedCommands.length; i++) {
            var descriptor = this.supportedCommands[i];
            // yargs documentation specifies that setting the description of a command to
            // false hides that command from the help output. And they strict check for the
            // value false, not falsey.  However the available typings insist that description
            // must be a string. Thus the "false as any"
            // https://github.com/yargs/yargs#commandmodule
            // https://github.com/yargs/yargs/blob/master/lib/command.js#L24
            parser.command(descriptor.command, (descriptor.hidden ? false : descriptor.description));
        }
        // define the options
        for (var i = 0; i < this.supportedOptions.length; i++) {
            var descriptor = this.supportedOptions[i];
            parser.option(descriptor.name, descriptor.options);
        }
        return parser;
    };
    CommandLineParser.prototype.validateSingleInstanceOption = function (argv, option) {
        if (argv[option]) {
            var optType = typeof (argv[option]);
            optType = optType.toLowerCase();
            if ((optType === "array") || (optType === "object")) {
                this._errorHandler.emitError(ResourceStrings_1.ResourceStrings.multipleInstancesOfASingleInstanceParameter(option));
            }
        }
    };
    CommandLineParser.prototype.findCommand = function (command) {
        return this.supportedCommands.find(function (desc) { return string_utilities_1.caseInsensitiveAreEqual(desc.command, command); });
    };
    CommandLineParser.prototype.findOption = function (option) {
        return this.supportedOptions.find(function (desc) { return string_utilities_1.caseInsensitiveAreEqual(desc.name, option); });
    };
    Object.defineProperty(CommandLineParser.prototype, "multiInstanceOptions", {
        get: function () {
            return this.supportedOptions.filter(function (desc) { return desc.multiInstance; });
        },
        enumerable: true,
        configurable: true
    });
    CommandLineParser.prototype.emitWarning = function (message) {
        this._logger.writeWarning("" + ResourceStrings_1.ResourceStrings.warningMessagePrefix + message);
    };
    return CommandLineParser;
}());
exports.CommandLineParser = CommandLineParser;
//# sourceMappingURL=CommandLineParser.js.map