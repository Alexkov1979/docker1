/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../typings/globals/node/index.d.ts" />
"use strict";
var fs = require("fs");
var requires = require("../lib/requires");
var ConfigurationImpl = (function () {
    function ConfigurationImpl() {
    }
    ConfigurationImpl.prototype.setFromFile = function (configurationFilePath) {
        try {
            var configurationJson = fs.readFileSync(configurationFilePath, "utf8");
            this.setFromJson(configurationJson);
        }
        catch (error) {
            throw new Error(("The configuration file \"" + configurationFilePath + "\" could not be read ") +
                "as a valid configuration.");
        }
    };
    ConfigurationImpl.prototype.setFromJson = function (configurationJson) {
        var configurationFromJson = JSON.parse(configurationJson);
        requires.stringNotEmpty(configurationFromJson.VersionUrl, "configurationFromJson.VersionUrl");
        this.configuration = configurationFromJson;
    };
    Object.defineProperty(ConfigurationImpl.prototype, "versionUrl", {
        get: function () {
            return this.configuration.VersionUrl;
        },
        enumerable: true,
        configurable: true
    });
    return ConfigurationImpl;
}());
exports.configuration = new ConfigurationImpl();
//# sourceMappingURL=Configuration.js.map