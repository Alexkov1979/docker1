/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../typings/globals/es6-shim/index.d.ts" />
"use strict";
var electron_1 = require("electron");
var BrowserWindowFactory = (function () {
    function BrowserWindowFactory() {
    }
    BrowserWindowFactory.prototype.createWindow = function (windowOptions, windowPageUrl) {
        // create a window
        var window = new electron_1.BrowserWindow(windowOptions);
        // hide the menu bar
        window.setMenuBarVisibility(false);
        // load the main page of the app
        window.loadURL(windowPageUrl);
        // This prevents the title from being changed
        window.on("page-title-updated", function (e) {
            e.preventDefault();
        });
        // clean up when the window is closed. Don"t call quit()
        // since there might be other windows open.
        window.on("closed", function () {
            window = null;
        });
        return window;
    };
    BrowserWindowFactory.prototype.formatUrlWithQueryOptions = function (startPage, options, overrideQueryParameters) {
        var queryStringParts = Object.keys(options).map(function (key) {
            if (options[key] === undefined) {
                return undefined;
            }
            if (overrideQueryParameters && overrideQueryParameters.includes(key)) {
                return "";
            }
            if (!Array.isArray(options[key])) {
                return key + "=" + options[key];
            }
            var array = options[key];
            return key + "=" + array.join("%20");
        });
        if (overrideQueryParameters) {
            queryStringParts.push(overrideQueryParameters);
        }
        // construct the query string, omitting the undefined parts
        var queryString = queryStringParts.filter(function (part) { return !!part; }).join("&");
        return "file://" + startPage + "?" + queryString;
    };
    return BrowserWindowFactory;
}());
exports.BrowserWindowFactory = BrowserWindowFactory;
//# sourceMappingURL=browser-window-factory.js.map