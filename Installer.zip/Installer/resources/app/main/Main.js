/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../typings/globals/electron/github-electron/index.d.ts" />
/// <reference path="../typings/globals/es6-shim/index.d.ts" />
/// <reference path="../typings/globals/node/index.d.ts" />
/// <reference path="../typings/node-missing-declares.d.ts" />
/// <reference path="../typings/report-errors-electron-missing-declares.d.ts" />
"use strict";
var APPLICATION_START_TIME = Date.now();
var CONFIGURATION_FILE_NAME = "configuration.json";
var electron_1 = require("electron");
var fs = require("fs");
var path = require("path");
var ShutdownUtilities_1 = require("../lib/ShutdownUtilities");
var Request = require("../lib/Request");
var windowConstants = require("../lib/window-action-constants");
var leak_detector_1 = require("../lib/leak-detector");
var Relauncher_1 = require("./Relauncher");
var errors_1 = require("../lib/errors");
var package_1 = require("./package");
var appExeName = "vs_installer.exe";
var appExePath = electron_1.app.getPath("exe");
var Logger_1 = require("../lib/Logger");
var logger = Logger_1.getLogger();
var version = package_1.BRANCH_NAME ? package_1.EXE_VERSION + " : " + package_1.BRANCH_NAME : "" + package_1.EXE_VERSION;
logger.writeVerbose(package_1.APPLICATION_NAME + " (" + version + ") " + JSON.stringify(process.argv));
// watch for leaks in the main process
var captureHeapDumps = true;
var enableLeakLogging = false;
var leakDetector = new leak_detector_1.LeakDetector("Main", captureHeapDumps, enableLeakLogging);
leakDetector.on(leak_detector_1.LeakDetector.leakDetectedEvent, onLeakDetected);
function onLeakDetected(info) {
    function log(message) {
        // console.log(message);
        logger.writeVerbose(message);
    }
    log("Potential leak detected in " + info.processName + " process:");
    log("    Heap Size: " + info.heapSize.toLocaleString() + " bytes");
    log("    Average Leak Size: " + info.averageLeakSize.toLocaleString() + " bytes/GC");
    log("    \"Before\" snapshot name: " + (info.beforeSnapshotName || "(none)"));
    log("    \"After\"  snapshot name: " + (info.afterSnapshotName || "(none)"));
}
/**
 * The time we wait for telemetry to send before shutting down.
 */
var APPLICATION_SHUTDOWN_TIMEOUT_IN_MS = 60 * 1000; // one minute
// Hook https.request so modules which capture it on import
// get the hooked version
Request.hookHttpsRequest();
// extend Promise with finally
require("../lib/PromiseFinallyMixin");
// parse the command line
var CommandLineParser_1 = require("./command-line/CommandLineParser");
var command_line_error_handler_factory_1 = require("./command-line/command-line-error-handler-factory");
var CommandLine_1 = require("../lib/CommandLine");
var ConsoleLogger_1 = require("../lib/ConsoleLogger");
var isDevBuild = false;
var consoleLogger = new ConsoleLogger_1.ConsoleLogger();
// We do not want to show an error dialog in --passive or --quiet, since then it will block the
// user.
var showDialogOnError = !CommandLineParser_1.CommandLineParser.argsContainQuietOrPassive(process.argv);
var commandLineParser = new CommandLineParser_1.CommandLineParser(consoleLogger, showDialogOnError, new command_line_error_handler_factory_1.CommandLineErrorHandlerFactory());
function processArgs(args) {
    // we'll remove the first parameter (the executable name) from the args that
    // CommandLineParser.parse will deal with unless we're running via "electron out",
    // in which case we'll remove the first two parameters
    var sliceIndex = 1;
    if (args.length > 1) {
        isDevBuild = (args[0].toLowerCase().lastIndexOf("electron.exe") !== -1) && (args[1].toLowerCase() === "out");
        // To instantiate the feedback client, we call: <path-to-electron.exe> <path-to-app> reportaproblem
        // As a result, the isDevInstance case will fail, so we include this test for the feedback instance.
        var isFeedbackInstance = args[1] === electron_1.app.getAppPath();
        if (isDevBuild || isFeedbackInstance) {
            sliceIndex = 2;
        }
    }
    return commandLineParser.parse(args.slice(sliceIndex), isDevBuild);
}
function applicationInitializationDurationProperties() {
    return {
        applicationStartTime: APPLICATION_START_TIME,
        applicationRunTimeDuration: Date.now() - APPLICATION_START_TIME
    };
}
// Import and initialize Telemetry before other modules are loaded.
var vs_telemetry_api_1 = require("vs-telemetry-api");
var TelemetryEventNames = require("../lib/Telemetry/TelemetryEventNames");
var telemetry_factory_1 = require("./Telemetry/telemetry-factory");
var user_data_store_factory_1 = require("./user-data-store-factory");
var telemetryFactory = telemetry_factory_1.TelemetryFactory.getInstance();
var telemetry = telemetryFactory.startTelemetrySession();
var appRunOperation;
try {
    exports.argv = processArgs(process.argv);
    if (exports.argv.version) {
        console.log(electron_1.app.getVersion());
        electron_1.app.exit(0);
    }
    if (exports.argv.runOnce) {
        var timeout = 1000;
        var argsCopy = process.argv.slice();
        argsCopy.splice(0, 1); // Remove first argument as its the app path.
        var runOnceRelauncher = new Relauncher_1.RunOnceRelauncher(appExePath, argsCopy, timeout, commandLineParser);
        runOnceRelauncher.launch()
            .then(function () {
            // timeout called.
            logger.writeVerbose("This process is created due to a Windows restart relaunching setup " +
                "via the runOnce registry key. It has launched another Visual Studio Installer instance, " +
                "without the runOnce parameter to complete the requested operation " +
                "and will return so that Windows can continue with boot-up. " +
                "The child Visual Studio Installer process has not returned any errors " +
                "within the timeout period. " +
                "To examine the setup process, look for another log that is approximately one second newer " +
                "than this log file.");
            electron_1.app.exit(0);
        })
            .catch(function () {
            // Error was called before timeout
            logger.writeError("Failed to relaunch installer without RunOnce parameter");
            electron_1.app.exit(1);
        });
    }
    if (exports.argv.quiet) {
        logger.shouldWriteToConsole = true;
    }
    // log the campaign ID and the activity ID (if present) on all telemetry events
    if (exports.argv.campaign || exports.argv.activityId) {
        if (exports.argv.campaign) {
            telemetry.setCommonProperty(CommandLine_1.OptionNames.campaign, exports.argv.campaign);
        }
        if (exports.argv.activityId) {
            telemetry.setCommonProperty(CommandLine_1.OptionNames.activityId, exports.argv.activityId);
        }
    }
    // Log quiet and passive with all events
    telemetry.setCommonProperty(CommandLine_1.OptionNames.quiet, exports.argv.quiet ? "true" : "false");
    telemetry.setCommonProperty(CommandLine_1.OptionNames.passive, exports.argv.passive ? "true" : "false");
    // Add how we were started. If we have an activityId then we were indirectly started by some other exe (e.g. VS)
    // No activity ID indicates the user directly ran us, so start method is direct.
    telemetry.setCommonProperty("startMethod", exports.argv.activityId ? "indirect" : "direct");
    // Start app
    var properties = buildAppLaunchTelemetryProperties();
    appRunOperation = telemetry.startOperation(TelemetryEventNames.APPLICATION_RUN, properties);
    telemetry.postOperation(TelemetryEventNames.APPLICATION_INITIALIZE_PRE_TELEMETRY, vs_telemetry_api_1.TelemetryResult.Success, null, applicationInitializationDurationProperties());
}
catch (error) {
    logger.writeError(error);
    var event_1;
    // If the error is a parse error, do not post a fault event but post an operation event.
    if (error instanceof errors_1.CommandLineParseError) {
        event_1 = telemetry.postOperation(TelemetryEventNames.APPLICATION_PARSE_CMDLINE, vs_telemetry_api_1.TelemetryResult.UserFault, "Failed to parse the commnand line with error " + error.message);
    }
    else {
        event_1 = telemetry.postError(TelemetryEventNames.APPLICATION_CMDLINE_ERROR, error.message, error);
    }
    if (!appRunOperation) {
        appRunOperation = telemetry.startOperation(TelemetryEventNames.APPLICATION_RUN, null);
    }
    telemetry.postOperation(TelemetryEventNames.APPLICATION_INITIALIZE_PRE_TELEMETRY, vs_telemetry_api_1.TelemetryResult.Failure, null, applicationInitializationDurationProperties());
    appRunOperation.correlate(event_1);
    var errorProperties = { ResultDetails: error.message };
    appRunOperation.end(vs_telemetry_api_1.TelemetryResult.Failure, errorProperties);
    var telemetryFinalizePromise = telemetry.finalizeOperationsAndSendPendingData();
    var timeoutPromise = new Promise(function (resolve, reject) {
        var timeoutError = new Error("Timed out during application cleanup.");
        setTimeout(function () {
            logger.writeError(timeoutError.message);
            reject(timeoutError);
        }, APPLICATION_SHUTDOWN_TIMEOUT_IN_MS);
    });
    Promise.race([telemetryFinalizePromise, timeoutPromise]).finally(function () { return electron_1.app.exit(1); });
}
// Add Error Handling
// Allow Wer to handle native crashes
var enable_wer_windows_1 = require("enable-wer-windows");
var enableWerOperation = telemetry.startOperation(TelemetryEventNames.APPLICATION_ENABLE_WER, null);
enable_wer_windows_1.default();
enableWerOperation.end(vs_telemetry_api_1.TelemetryResult.Success);
var report_errors_electron_1 = require("report-errors-electron");
var report_errors_1 = require("report-errors");
var wer_reporter_1 = require("wer-reporter");
var StubMain_1 = require("./StubMain");
var errorHandler = new report_errors_electron_1.ErrorHandlerMain();
// print the raw stack to the console
errorHandler.addReportingChannel(new report_errors_1.ConsoleReporter());
if (!isDevBuild) {
    // report the failure to Watson, also resulting in a Watson crash dialog
    errorHandler.addReportingChannel(new wer_reporter_1.WatsonReporter());
}
// write the wer error log file to the default logging location
errorHandler.addReportingChannel(new report_errors_1.FileReporter(Logger_1.DEFAULT_LOGGER_DIRECTORY, "dd_client_" + Logger_1.getLogFileDateTime() + "_wer.log", true));
// Allows the program to react to reporting being finished or failing.
errorHandler.onReportingFinished(function (results) {
    logger.writeError("results: " + results);
});
errorHandler.onAsyncFailure(function (err) { logger.writeError("async rep failure: " + err.stack); });
errorHandler.onInternalError(function (int) { return console.log(int); });
// Once wer-reporter is running, stop the process for listening for uncaughtExceptions.
StubMain_1.removeExceptionHandler();
// add telemtry reporter
var TelemetryReporter_1 = require("../lib/TelemetryReporter");
if (!isDevBuild) {
    var telemReport = new TelemetryReporter_1.TelemetryReporter(telemetry, TelemetryEventNames.APPLICATION_CRASH, appRunOperation);
    errorHandler.addReportingChannel(telemReport);
}
// If running in electron prebuilt, set the ServiceHub controller executable path
// to this process module path.
// Note: this must be done before requiring ServiceHub modules.
if (appExePath.includes("electron")) {
    var serviceHubConfigPath = path.join(path.dirname(__dirname), "servicehub.config.json");
    /* tslint:disable */
    var serviceHubConfig = require(serviceHubConfigPath);
    /* tslint:enable */
    serviceHubConfig.controller.executable = appExePath;
    fs.writeFileSync(serviceHubConfigPath, JSON.stringify(serviceHubConfig, null, 2));
}
var SetupEngineAdapter_1 = require("../lib/Installer/Adapters/SetupEngineAdapter");
// localization
var ResourceStrings_1 = require("../lib/ResourceStrings");
var locale_handler_1 = require("../lib/locale-handler");
var browser_window_telemetry_1 = require("./Telemetry/browser-window-telemetry");
var BrowserWindowEventSenderAdapter_1 = require("../lib/EventSender/BrowserWindowEventSenderAdapter");
var Configuration_1 = require("./Configuration");
var HostUpdater_1 = require("./HostUpdater");
var HostUpdaterTelemetry_1 = require("./HostUpdaterTelemetry");
var HostUpdaterEvents_1 = require("./HostUpdaterEvents");
var HostUpdaterService_1 = require("./HostUpdaterService");
var InstallerServiceEvents_1 = require("./InstallerServiceEvents");
var windowManager = require("./WindowManager");
var HostInstaller = require("./WindowsInstaller");
var FeedbackManagerFactory_1 = require("./FeedbackManagerFactory");
var telemetry_filter_1 = require("../lib/Installer/telemetry/telemetry-filter");
var InstallerTelemetryDecorator_1 = require("../lib/Installer/InstallerTelemetryDecorator");
var InstallerService_1 = require("./Installer/InstallerService");
var TelemetryAssetManager_1 = require("../lib/Telemetry/TelemetryAssetManager");
var ipc_rpc_factory_1 = require("./ipc-rpc-factory");
var configurationError;
var installerTelemetryDecorator;
try {
    Configuration_1.configuration.setFromFile(path.join(__dirname, CONFIGURATION_FILE_NAME));
}
catch (error) {
    configurationError = error;
}
function createParametersForResumeFunction(isQuiet, isPassive, productKey) {
    return function (installPath, installSessionId) {
        return CommandLineParser_1.CommandLineParser.getParametersForResume(installPath, installSessionId, isQuiet, isPassive, productKey);
    };
}
function createSetupEngineAdapter(locale, serializedTelemetrySession, installerOperation, campaign) {
    // exeVersionForEngine is used to detect updates. During development,
    // checking for updates is undesired. Typically, a true release version
    // looks like "x.y.build.qfe", otherwise the version is "x.y.z".
    // Passing null for version skips checking for updates.
    var exeVersionParts = package_1.EXE_VERSION.split(".");
    var exeVersionForEngine = exeVersionParts.length > 3 ? package_1.EXE_VERSION : null;
    var isUninstallingHost = installerOperation === HostInstaller.InstallerOperation.Uninstalling;
    var setupEngineAdapter = new SetupEngineAdapter_1.SetupEngineAdapter(appExePath, exeVersionForEngine, exports.argv.channelUri, exports.argv.installChannelUri, exports.argv.installCatalogUri, locale, serializedTelemetrySession, campaign, createParametersForResumeFunction(exports.argv.quiet, exports.argv.passive, exports.argv.productKey), isUninstallingHost /* ignore updates when uninstalling the host */);
    // Update the setup engine policy if requested on the command line.
    var noWeb = undefined;
    if (exports.argv.noWeb) {
        telemetry.setCommonProperty("NoWeb", "true");
        noWeb = true;
    }
    var force = undefined;
    if (exports.argv.force) {
        telemetry.setCommonProperty("Force", "true");
        force = true;
    }
    var cache = undefined;
    if (exports.argv.cache) {
        cache = true;
    }
    else if (exports.argv.nocache) {
        cache = false;
    }
    if (typeof cache === "boolean" || typeof noWeb === "boolean" || typeof force === "boolean") {
        return setupEngineAdapter.getSettings()
            .then(function (settings) {
            if (typeof cache === "boolean") {
                settings.keepDownloadedPayloads = cache;
            }
            if (typeof noWeb === "boolean") {
                settings.noWeb = noWeb;
            }
            if (typeof force === "boolean") {
                settings.force = force;
            }
            return setupEngineAdapter.setSettings(settings);
        })
            .then(function () {
            return setupEngineAdapter;
        });
    }
    else {
        return Promise.resolve(setupEngineAdapter);
    }
}
function createInstallerService(sessionId, installer) {
    var installerWithTelemetry = new InstallerTelemetryDecorator_1.InstallerTelemetryDecorator(installer, telemetry_filter_1.getInstallerTelemetry(), sessionId, exports.argv.installSessionId);
    return {
        installer: installer,
        installerService: new InstallerService_1.InstallerService(installerWithTelemetry),
        installerTelemetryDecorator: installerWithTelemetry
    };
}
if (exports.argv && !exports.argv.runOnce) {
    HostInstaller.eventEmitter.on(HostInstaller.FINALIZE_INSTALL_FAILED, function (error) {
        var fault = telemetry.postError(TelemetryEventNames.APPLICATION_FINALIZE_FAILED, "finalize install failed", error, {}, vs_telemetry_api_1.TelemetrySeverity.High);
        appRunOperation.correlate(fault);
    });
    var installerOperation_1 = HostInstaller.processArguments(process.argv);
    (function startup() {
        // We cache the locale after ready for use with windowManager.handleIncomingArgs
        var locale;
        // Keep a list of arguments passed from other instances
        var incomingArgs = [];
        // callback will be called when a new instance attempts to start
        var isAnotherInstanceRunning = electron_1.app.makeSingleInstance(function (args, workingDirectory) {
            var otherInstanceIsUninstalling = HostInstaller.hasUninstallParameter(args);
            // don't focus this instance's main window if the other instance is performing an uninstall
            if (!otherInstanceIsUninstalling) {
                var processedArgs = processArgs(args);
                var mainWindow_1 = windowManager.mainWindow;
                incomingArgs.push(processedArgs);
                // If a second instance is opened while the first instance's window has not yet loaded,
                // ignore the input from the second instance and let the first instance load. The first
                // instance window must be loaded before we can handle the input of other instances, or
                // the installer will crash.
                if (!mainWindow_1) {
                    return;
                }
                // If the current client instance is uninstalling, warn the user.
                if (installerOperation_1 === HostInstaller.InstallerOperation.Uninstalling) {
                    electron_1.dialog.showErrorBox(ResourceStrings_1.ResourceStrings.installerRunning(package_1.APPLICATION_NAME), ResourceStrings_1.ResourceStrings.pleaseWaitUntilOperationFinished);
                }
                else {
                    if (processedArgs.command && processedArgs.queryParameters) {
                        windowManager.handleIncomingArgs(package_1.BRANCH_NAME, locale, processedArgs.queryParameters);
                        var message = "Relaunching the application with new commands. " +
                            ("Args: " + JSON.stringify(args));
                        logger.writeVerbose(message);
                        var properties = buildAppLaunchTelemetryProperties(processedArgs);
                        telemetry.postOperation(TelemetryEventNames.RELAUNCH_WINDOW, vs_telemetry_api_1.TelemetryResult.Success, message, properties);
                    }
                }
                if (mainWindow_1.isMinimized()) {
                    mainWindow_1.restore();
                }
                mainWindow_1.focus();
            }
        });
        // isAnotherInstanceRunning will be true if there is already a main instance running
        // close this instance unless uninstalling
        if (isAnotherInstanceRunning && (installerOperation_1 !== HostInstaller.InstallerOperation.Uninstalling)) {
            // Indicate that we've handed off this instances command line options to the main instance of Willow
            var properties = { ResultDetails: TelemetryEventNames.APPLICATION_SHUTDOWN_PARAMETERS_FORWARDED };
            EndAppRunTelemetryEvent(vs_telemetry_api_1.TelemetryResult.Success, properties);
            electron_1.app.quit();
            return;
        }
        // Normal app launch:
        var hostUpdater;
        var hostUpdaterService;
        var installerService;
        var mainWindow;
        var telemetryService = telemetryFactory.createRendererTelemetryListener();
        var appCleanupPromise;
        function appCleanup() {
            if (appCleanupPromise) {
                return appCleanupPromise;
            }
            // Hide all windows before cleaning up resources and flushing telemetry
            windowManager.hideAllWindows();
            // Release the single instance so other instances can start up while we clean up this instance
            electron_1.app.releaseSingleInstance();
            if (telemetryService) {
                telemetryService.dispose();
            }
            EndAppRunTelemetryEvent(vs_telemetry_api_1.TelemetryResult.None);
            var installerServiceDisposePromise = installerService ?
                installerService.dispose() :
                Promise.resolve();
            var telemetrySendPendingDataPromise = installerServiceDisposePromise
                .then(function () { return telemetry.finalizeOperationsAndSendPendingData(); });
            var timeoutPromise = new Promise(function (resolve, reject) {
                var timeoutError = new Error("Timed out during application cleanup.");
                setTimeout(function () { return reject(timeoutError); }, APPLICATION_SHUTDOWN_TIMEOUT_IN_MS);
            });
            appCleanupPromise = Promise.race([telemetrySendPendingDataPromise, timeoutPromise]);
            return appCleanupPromise;
        }
        electron_1.app.on("ready", function () {
            logger.writeVerbose("Received the application ready notification");
            electron_1.powerMonitor.on("suspend", function () {
                var message = "System is suspending";
                logger.writeVerbose(message);
                telemetry.postUserTask(TelemetryEventNames.SYSTEM_SUSPEND, vs_telemetry_api_1.TelemetryResult.Success, message, {} /* no properties */);
            });
            electron_1.powerMonitor.on("resume", function () {
                var message = "System is resuming";
                logger.writeVerbose(message);
                telemetry.postUserTask(TelemetryEventNames.SYSTEM_RESUME, vs_telemetry_api_1.TelemetryResult.Success, message, {} /* no properties */);
            });
            if (configurationError) {
                logger.writeError("Configuration error reported on application ready notification " +
                    ("[error: " + configurationError.message + "] at " + configurationError.stack));
                var err = telemetry.postError(TelemetryEventNames.APPLICATION_CONFIG_ERROR, "Configuration error reported on application ready notification", configurationError);
                appRunOperation.correlate(err);
                var errorProperties = { ResultDetails: configurationError };
                EndAppRunTelemetryEvent(vs_telemetry_api_1.TelemetryResult.Failure, errorProperties);
                electron_1.dialog.showMessageBox({
                    type: "error",
                    buttons: ["Close"],
                    title: package_1.APPLICATION_NAME,
                    message: configurationError.message
                });
                electron_1.app.quit();
                return;
            }
            telemetry.postOperation(TelemetryEventNames.APPLICATION_READY, vs_telemetry_api_1.TelemetryResult.Success, null, applicationInitializationDurationProperties());
            // fetch or create local user data
            // Note: This must be created after the "Ready" event.
            var userData = user_data_store_factory_1.getUserDataStore();
            // Overwrite default locale if locale is given as cmdline parameter.
            if (exports.argv.locale) {
                userData.storeLocale(locale_handler_1.LocaleHandler.getSupportedLocale(exports.argv.locale));
            }
            // Update campaign Id from argument.
            if (exports.argv.campaign) {
                userData.storeCampaign(exports.argv.campaign);
            }
            if (userData.campaign) {
                telemetry.setCommonProperty(CommandLine_1.OptionNames.campaign, userData.campaign);
            }
            // Initialize locale
            locale = userData.locale;
            // Set the shared property so locale is sent with every telemetry event
            var localeTelemetryPropertyName = "locale";
            telemetry.setCommonProperty(localeTelemetryPropertyName, locale);
            ResourceStrings_1.ResourceStrings.config(userData.locale, true);
            Promise.all([
                // Connect to ServiceHub Experiments
                ipc_rpc_factory_1.getExperimentsIpcService(package_1.EXE_NAME, package_1.EXE_VERSION),
                // Detect proxies before attempting any internet
                Request.detectHttpsProxySettings()
            ])
                .then(function () {
                var vsTelemetryListener = telemetryFactory.createVsTelemetryListener();
                return Promise.all([
                    vsTelemetryListener.sessionId(),
                    vsTelemetryListener.serializedSession(),
                ]);
            })
                .then(function (results) {
                var sessionId = results[0];
                var serializedTelemetrySession = results[1];
                logSessionId(sessionId);
                return createSetupEngineAdapter(userData.locale, serializedTelemetrySession, installerOperation_1, userData.campaign)
                    .then(function (setupEngineAdapter) {
                    return createInstallerService(sessionId, setupEngineAdapter);
                });
            })
                .then(function (installerServices) {
                installerTelemetryDecorator = installerServices.installerTelemetryDecorator;
                installerService = installerServices.installerService;
                var windowTelemetry = new browser_window_telemetry_1.BrowserWindowTelemetry(telemetry, logger);
                FeedbackManagerFactory_1.createFeedbackManager(telemetryFactory.createVsTelemetryListener(), installerServices.installer, package_1.EXE_NAME, package_1.EXE_VERSION, package_1.BRANCH_NAME, electron_1.app.getLocale(), userData.locale);
                ipc_rpc_factory_1.getFeedbackIpcRpcService(telemetryFactory.createVsTelemetryListener(), electron_1.app.getLocale(), userData.locale, package_1.BRANCH_NAME, package_1.EXE_NAME, package_1.EXE_VERSION);
                if (installerOperation_1 !== HostInstaller.InstallerOperation.Uninstalling) {
                    // start the Host Updater
                    var bootstrapperArguments = process.argv.slice(1); // do not include the program name
                    var setupEngineAdapter = installerServices.installer;
                    hostUpdater = HostUpdater_1.create(setupEngineAdapter, bootstrapperArguments, HostInstaller.getInstallerFinalizeInstallParameter());
                    /* tslint:disable:no-unused-expression */
                    new HostUpdaterTelemetry_1.HostUpdaterTelemetry(hostUpdater, telemetry);
                    /* tslint:enable */
                    // Create shortcuts
                    if (installerOperation_1 === HostInstaller.InstallerOperation.FinalizedInstall) {
                        var directoryPath = path.dirname(electron_1.app.getPath("exe"));
                        var targetPath = path.join(directoryPath, appExeName);
                        setupEngineAdapter.createStartMenuShortcut(package_1.APPLICATION_NAME, targetPath)
                            .catch(function (error) {
                            logger.writeError("Create shortcut failed: " + error.message);
                            var err = telemetry.postError(TelemetryEventNames.CREATE_SHORTCUT_FAILED, error.message, error, {}, vs_telemetry_api_1.TelemetrySeverity.High);
                            appRunOperation.correlate(err);
                        });
                    }
                    hostUpdater.on(HostUpdaterEvents_1.HostUpdaterEvents.UPDATE_STARTING, function (event) {
                        var properties = { ResultDetails: HostUpdaterEvents_1.HostUpdaterEvents.UPDATE_STARTING };
                        EndAppRunTelemetryEvent(vs_telemetry_api_1.TelemetryResult.Success, properties);
                        event.deferrals.push(appCleanup().catch(function (error) {
                            // failing to clean up the application must not block starting the update
                            logger.writeError("Failed cleaning up the application " +
                                ("[error.name: " + error.name + ", error.message: " + error.message + "]"));
                        }));
                    });
                    hostUpdater.on(HostUpdaterEvents_1.HostUpdaterEvents.UPDATE_STARTED, function () {
                        electron_1.app.quit();
                    });
                    // if user.json has debug=true and we don't already have argv.debug=true,
                    // set argv.debug=true and recompute the query string
                    if (userData.debug && !exports.argv.debug) {
                        exports.argv.debug = true;
                        commandLineParser.computeQueryString(exports.argv);
                    }
                    var queryOptions = windowManager.createQueryOptions(package_1.BRANCH_NAME, userData.locale, userData.showDownlevelSkus);
                    mainWindow = windowManager.init(queryOptions, exports.argv, windowTelemetry);
                    // Wire up the install manager
                    var eventSender = new BrowserWindowEventSenderAdapter_1.BrowserWindowEventSenderAdapter(electron_1.webContents);
                    installerService.init(eventSender);
                    if (hostUpdater != null) {
                        hostUpdaterService = new HostUpdaterService_1.HostUpdaterService(eventSender, hostUpdater);
                    }
                }
                else {
                    // we are Uninstalling xStation
                    telemetry.postUserTask(TelemetryEventNames.APPLICATION_UNINSTALL_SELF_REQUESTED, vs_telemetry_api_1.TelemetryResult.Success, "Beginning uninstallation");
                    electron_1.ipcMain.on(InstallerServiceEvents_1.InstallerServiceEvents.UNINSTALL_SELF_REQUEST, function (source) {
                        source.sender.send(InstallerServiceEvents_1.InstallerServiceEvents.UNINSTALL_SELF_STARTED);
                        telemetry.postOperation(TelemetryEventNames.APPLICATION_UNINSTALL_SELF, vs_telemetry_api_1.TelemetryResult.Success, "Beginning uninstallation");
                        installerServices.installer.deleteStartMenuShortcut(package_1.APPLICATION_NAME)
                            .catch(function (error) {
                            logger.writeError("Delete shortcut failed: " + error.message);
                            var err = telemetry.postError(TelemetryEventNames.DELETE_SHORTCUT_FAILED, error.message, error, {}, vs_telemetry_api_1.TelemetrySeverity.High);
                            appRunOperation.correlate(err);
                        });
                        installerServices.installerTelemetryDecorator
                            .uninstallAll().finally(function () { return HostInstaller.uninstall(!!exports.argv.quiet || !!exports.argv.passive); });
                        var properties = { ResultDetails: TelemetryEventNames.APPLICATION_UNINSTALL_SELF };
                        EndAppRunTelemetryEvent(vs_telemetry_api_1.TelemetryResult.Success, properties);
                        // forward uninstall failure back to renderer
                        HostInstaller.eventEmitter.on(HostInstaller.UNINSTALL_SELF_FAILED_EVENT, function (error) {
                            source.sender.send(InstallerServiceEvents_1.InstallerServiceEvents.UNINSTALL_SELF_FAILED);
                            var err = telemetry.postError(TelemetryEventNames.APPLICATION_UNINSTALL_SELF_FAILED, "Failed to uninstall the installer", error, {}, vs_telemetry_api_1.TelemetrySeverity.High);
                            appRunOperation.correlate(err);
                            var properties = { ResultDetails: InstallerServiceEvents_1.InstallerServiceEvents.UNINSTALL_SELF_FAILED };
                            EndAppRunTelemetryEvent(vs_telemetry_api_1.TelemetryResult.Failure, properties);
                        });
                    });
                    var queryOptions = windowManager.createQueryOptions(package_1.BRANCH_NAME, userData.locale, false, /* showDownlevelSkus */ isAnotherInstanceRunning);
                    mainWindow = windowManager.initUninstall(queryOptions, exports.argv, windowTelemetry);
                    // Wire up the install manager
                    var eventSender = new BrowserWindowEventSenderAdapter_1.BrowserWindowEventSenderAdapter(electron_1.webContents);
                    installerService.init(eventSender);
                    if (isAnotherInstanceRunning) {
                        setTimeout(checkIfSingletonAndReport, 1000);
                    }
                }
            })
                .catch(function (error) {
                logger.writeError("Failed to create the initialize the window. " +
                    ("[error: " + error.message + " at " + error.stack + "]"));
                appCleanup().finally(function () { return electron_1.app.exit(windowConstants.ERROR_INSTALL_FAILURE); });
            });
        });
        function checkIfSingletonAndReport() {
            if (isAnotherInstanceRunning) {
                isAnotherInstanceRunning = electron_1.app.makeSingleInstance(function () { return true; });
            }
            // send the is-singleton status to the renderer
            // it is important to check the webContents member before sending the message;
            // webContents becomes undefined if the user clicks 'cancel' in the uninstall window
            var eventSender = new BrowserWindowEventSenderAdapter_1.BrowserWindowEventSenderAdapter(electron_1.webContents);
            eventSender.trySend(InstallerServiceEvents_1.InstallerServiceEvents.UNINSTALL_SELF_IS_SINGLETON, !isAnotherInstanceRunning);
            if (isAnotherInstanceRunning) {
                setTimeout(checkIfSingletonAndReport, 1000);
            }
        }
        electron_1.ipcMain.on(windowConstants.MINIMIZE_WINDOW, function () {
            windowManager.minimize();
        });
        var quitting = false;
        electron_1.app.on("will-quit", function (event) {
            if (!quitting) {
                quitting = true;
                event.preventDefault();
                var appQuit_1 = electron_1.app.quit;
                electron_1.app.quit = function () { };
                appCleanup().finally(function () { return setImmediate(appQuit_1); });
            }
        });
        electron_1.ipcMain.on(windowConstants.MAXIMIZE_RESTORE_WINDOW, function () {
            windowManager.maximizeOrRestore();
        });
        electron_1.ipcMain.on(windowConstants.WINDOW_STATE_REQUEST, function (event) {
            event.sender.send(windowConstants.WINDOW_STATE_RESPONSE, { maximized: windowManager.mainWindow.isMaximized() });
        });
        electron_1.ipcMain.on(windowConstants.CLOSE_WINDOW, function (event, returnCode, errorMessage) {
            var result = (returnCode === 0 ? vs_telemetry_api_1.TelemetryResult.Success : vs_telemetry_api_1.TelemetryResult.Failure);
            if (errorMessage) {
                logger.writeError(errorMessage);
            }
            var properties = {
                ResultDetails: windowConstants.CLOSE_WINDOW,
                ReturnCode: returnCode,
                ErrorMessage: errorMessage
            };
            EndAppRunTelemetryEvent(result, properties);
            logger.writeVerbose("Closing installer. Return code: " + returnCode + ".");
            appCleanup().finally(function () {
                if (returnCode === windowConstants.EXIT_CODE_REBOOT_REQUESTED) {
                    logger.writeVerbose("Restarting the system after an installation operation.");
                    ShutdownUtilities_1.restartWindows();
                }
                electron_1.app.exit(returnCode);
            });
        });
        electron_1.ipcMain.on("browse-dialog", function (event, path) {
            var filenames = electron_1.dialog.showOpenDialog({
                defaultPath: path,
                properties: ["openDirectory", "createDirectory"]
            });
            if (!filenames) {
                filenames = [];
            }
            event.returnValue = filenames;
        });
        electron_1.ipcMain.on(leak_detector_1.LeakDetector.leakDetectedEvent, function (event, info) {
            onLeakDetected(info);
        });
        function EndAppRunTelemetryEvent(result, properties) {
            if (!properties) {
                properties = {};
            }
            // Build up the incoming arguments as properties
            incomingArgs.forEach(function (args, index) {
                var commandLineArgProps = buildAppLaunchTelemetryProperties(args);
                properties[("incomingArgs." + (index + 1))] = commandLineArgProps.commandLineArguments;
            });
            if (appRunOperation.isEnded === false) {
                try {
                    if (installerTelemetryDecorator) {
                        installerTelemetryDecorator.addProductAssetsToEventProperties(properties, TelemetryAssetManager_1.AssetTypes.All);
                    }
                    appRunOperation.end(result, properties);
                }
                catch (error) {
                    // failing to send telemetry must not block starting the update
                    logger.writeError("Failed ending application run operation telemetry " +
                        ("[error.name: " + error.name + ", error.message: " + error.message + "]"));
                }
            }
        }
    })();
}
function buildAppLaunchTelemetryProperties(argvOverride) {
    var argvInternal = (argvOverride ? argvOverride : exports.argv);
    var keysToOmit = ["_", "query", "queryParameters"];
    var argvWithoutArrays = {};
    // copy all of the properties of argv to argvWithoutArrays
    // (except those listed in keysToOmit), converting
    // arrays to strings of comma-separated array values
    Object.keys(argvInternal).forEach(function (key) {
        if (keysToOmit.indexOf(key) >= 0) {
            return;
        }
        if (Array.isArray(argvInternal[key])) {
            argvWithoutArrays[key] = argvInternal[key].join(";");
        }
        else {
            argvWithoutArrays[key] = argvInternal[key];
        }
    });
    var properties = {
        commandLineArguments: JSON.stringify(argvWithoutArrays),
    };
    return properties;
}
function logSessionId(sessionId) {
    logger.writeVerbose("Telemetry Session ID: " + sessionId);
}
//# sourceMappingURL=Main.js.map