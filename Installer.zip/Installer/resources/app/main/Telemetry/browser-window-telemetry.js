/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/globals/electron/github-electron/index.d.ts" />
"use strict";
var Telemetry_1 = require("../../lib/Telemetry/Telemetry");
var TelemetryEventNames_1 = require("../../lib/Telemetry/TelemetryEventNames");
var browser_window_1 = require("../browser-window");
var BrowserWindowTelemetry = (function () {
    function BrowserWindowTelemetry(telemetry, logger) {
        this._logger = logger;
        this._telemetry = telemetry;
    }
    Object.defineProperty(BrowserWindowTelemetry.prototype, "unresponsiveInfo", {
        get: function () {
            return this._unresponsiveInfo;
        },
        enumerable: true,
        configurable: true
    });
    BrowserWindowTelemetry.prototype.monitor = function (browserWindow) {
        this.monitorForResponsiveEvent(browserWindow);
        this.monitorForShow(browserWindow);
        this.monitorForUnresponsiveEvents(browserWindow);
    };
    BrowserWindowTelemetry.prototype.monitorForShow = function (browserWindow) {
        var _this = this;
        browserWindow.on(browser_window_1.SHOW_EVENT, function () {
            _this._logger.writeVerbose("Window showing");
            _this._telemetry.postOperation(TelemetryEventNames_1.BROWSER_WINDOW_SHOW, Telemetry_1.TelemetryResult.Success, "Window showing", {});
        });
    };
    BrowserWindowTelemetry.prototype.monitorForUnresponsiveEvents = function (browserWindow) {
        var _this = this;
        browserWindow.on(browser_window_1.UNRESPONSIVE_EVENT, function () {
            _this.setUnresponsiveInfo();
            _this._logger.writeWarning("Window unresponsive");
            _this._telemetry.postError(TelemetryEventNames_1.BROWSER_WINDOW_UNRESPONSIVE, "Browser window unresponsive");
        });
    };
    BrowserWindowTelemetry.prototype.monitorForResponsiveEvent = function (browserWindow) {
        var _this = this;
        browserWindow.on(browser_window_1.RESPONSIVE_EVENT, function () {
            var endTime = new Date(Date.now());
            var startTime = _this._unresponsiveInfo && _this._unresponsiveInfo.startTime;
            // Send 0 to signify that the responsive event was received without a "Unresponsive" event.
            var durationMs = startTime ? +endTime - +startTime : 0;
            _this._logger.writeVerbose("Window responsive, startTime=" + startTime + ",endTime=" + endTime + ", durationMs=" + durationMs);
            _this._telemetry.postError(TelemetryEventNames_1.BROWSER_WINDOW_RESPONSIVE, "Browser window responsive", undefined, {
                startTime: startTime ? startTime.toISOString() : "",
                endTime: endTime.toISOString(),
                durationMs: durationMs,
            });
            _this.clearUnresponsiveInfo();
        });
    };
    BrowserWindowTelemetry.prototype.setUnresponsiveInfo = function () {
        if (this._unresponsiveInfo) {
            return;
        }
        this._unresponsiveInfo = {
            startTime: new Date(Date.now()),
        };
    };
    BrowserWindowTelemetry.prototype.clearUnresponsiveInfo = function () {
        this._unresponsiveInfo = null;
    };
    return BrowserWindowTelemetry;
}());
exports.BrowserWindowTelemetry = BrowserWindowTelemetry;
//# sourceMappingURL=browser-window-telemetry.js.map