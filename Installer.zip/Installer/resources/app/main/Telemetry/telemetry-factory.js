/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/globals/es6-shim/index.d.ts" />
"use strict";
var path = require("path");
var TelemetryEventNames = require("../../lib/Telemetry/TelemetryEventNames");
var vs_telemetry_api_1 = require("vs-telemetry-api");
var vs_telemetry_1 = require("vs-telemetry");
var Logger_1 = require("../../lib/Logger");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var telemetry_processor_1 = require("../../lib/Telemetry/telemetry-processor");
var VSTelemetryListener_1 = require("../../lib/Telemetry/Listeners/VSTelemetryListener");
var window_options_1 = require("../../lib/window-options");
var browser_window_factory_1 = require("../browser-window-factory");
var json_file_store_1 = require("../../lib/json-file-store");
var vs_telemetry_survey_1 = require("../../lib/Telemetry/VsTelemetrySurvey/vs-telemetry-survey");
var package_1 = require("../package");
var Telemetry_1 = require("../../lib/Telemetry/Telemetry");
var ipc_rpc_factory_1 = require("../ipc-rpc-factory");
var TelemetryService_1 = require("../Telemetry/TelemetryService");
var logger = Logger_1.getLogger();
var telemetryRulesFileName = "telemetry-rules.json";
var telemetryRulesPath = path.join(__dirname, telemetryRulesFileName);
var surveyPromptFileName = "survey-prompt.html";
var mainDir = path.dirname(__dirname);
var rendererDir = path.join(path.dirname(mainDir), "renderer");
var surveyPromptPath = path.join(rendererDir, surveyPromptFileName);
var VS_TELEMETRY_PREFIX_PARTS = ["VS", "Willow"];
var window;
var TelemetryFactory = (function () {
    function TelemetryFactory(appName, appVersion, branch, browserWindowFactory, fileStore) {
        this._openSurveyCallbackBind = this.openSurveyCallback.bind(this);
        this._appName = appName;
        this._appVersion = appVersion;
        this._branch = branch;
        this._browserWindowFactory = browserWindowFactory || new browser_window_factory_1.BrowserWindowFactory();
        this._fileStore = fileStore || new json_file_store_1.JSONFileStore(telemetryRulesPath);
        this._callbackProcessed = false;
    }
    TelemetryFactory.getInstance = function () {
        return new TelemetryFactory(package_1.EXE_NAME, package_1.EXE_VERSION, package_1.BRANCH_NAME);
    };
    TelemetryFactory.prototype.createVsTelemetryListener = function (experiments, telemetry, telemetryProcessor) {
        if (this._vsTelemetryLister) {
            return this._vsTelemetryLister;
        }
        experiments = experiments ||
            ipc_rpc_factory_1.getExperimentsIpcService(this._appName, this._appVersion).then(function (service) { return service.experiments; });
        telemetry = telemetry || this.getDefaultTelemetrySession();
        telemetryProcessor = telemetryProcessor || new telemetry_processor_1.TelemetryProcessor(VS_TELEMETRY_PREFIX_PARTS);
        var survey = this.tryCreateSurvey(telemetry, experiments);
        this._vsTelemetryLister = new VSTelemetryListener_1.VSTelemetryListener(telemetry, telemetryProcessor, this._branch, survey);
        return this._vsTelemetryLister;
    };
    TelemetryFactory.prototype.getDefaultTelemetrySession = function () {
        return vs_telemetry_1.TelemetryService.getDefaultSession();
    };
    TelemetryFactory.prototype.startTelemetrySession = function () {
        var vsTelemetryListener = this.createVsTelemetryListener();
        Telemetry_1.telemetryConfiguration.addListener(vsTelemetryListener);
        return Telemetry_1.telemetryConfiguration;
    };
    TelemetryFactory.prototype.createRendererTelemetryListener = function () {
        if (!this._rendererTelemetryListener) {
            this._rendererTelemetryListener = new TelemetryService_1.TelemetryService(Telemetry_1.telemetryConfiguration);
        }
        return this._rendererTelemetryListener;
    };
    TelemetryFactory.prototype.openSurveyCallback = function (surveyRule) {
        var _this = this;
        if (this._callbackProcessed) {
            return;
        }
        var telemetrySession = this.getDefaultTelemetrySession();
        telemetrySession.sessionId()
            .then(function (sessionId) {
            var queryOptions = {
                appVersion: _this._appVersion,
                branch: _this._branch,
                locale: ResourceStrings_1.ResourceStrings.uiLocale(),
                surveyUrl: surveyRule.surveyUrl,
                sessionId: sessionId
            };
            var surveyWindowUrl = _this._browserWindowFactory.formatUrlWithQueryOptions(surveyPromptPath, queryOptions);
            window = _this._browserWindowFactory.createWindow(window_options_1.surveyPromptWindowOptions(), surveyWindowUrl);
        })
            .finally(function () {
            Telemetry_1.telemetryConfiguration.postOperation(TelemetryEventNames.SURVEY_PROMPT_SHOWN_TO_USER, vs_telemetry_api_1.TelemetryResult.Success, "User was prompted survey", {
                "Survey.eventName": surveyRule.eventName,
                "Survey.surveyUrl": surveyRule.surveyUrl,
                "Survey.accept": JSON.stringify(surveyRule.properties.accept),
                "Survey.reject": JSON.stringify(surveyRule.properties.reject),
            });
        });
        this._callbackProcessed = true;
    };
    TelemetryFactory.prototype.tryCreateSurvey = function (telemetrySession, experiments) {
        try {
            if (this._fileStore.exists()) {
                logger.writeVerbose("Creating VS Telemetry Survey");
                return new vs_telemetry_survey_1.VsTelemetrySurvey(this._fileStore.read(), telemetrySession, experiments, this._openSurveyCallbackBind);
            }
        }
        catch (error) {
            logger.writeError(("Failed to create VS Telemetry Survey from survey object at " + telemetryRulesPath + ".") +
                (" [error: " + error.message + " at " + error.stack + "]"));
        }
        return undefined;
    };
    return TelemetryFactory;
}());
exports.TelemetryFactory = TelemetryFactory;
//# sourceMappingURL=telemetry-factory.js.map