/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
// Report uncaught exceptions to the main process
var renderer_1 = require("report-errors-electron/renderer");
/* tslint:disable: no-unused-variable */
var errorHandler = new renderer_1.ErrorHandlerRenderer();
/* tslint:enable: no-unused-variable */
// Allow WER to handle native crashes.
var enable_wer_windows_1 = require("enable-wer-windows");
enable_wer_windows_1.default();
require("../lib/PromiseFinallyMixin");
var ResourceStrings_1 = require("../lib/ResourceStrings");
var experiments_actions_1 = require("./Actions/experiments-actions");
var highcontrastcolorprovider_1 = require("./highcontrastcolorprovider");
var KeyCodes_1 = require("./KeyCodes");
var querystring_1 = require("querystring");
require("./stores/factory");
experiments_actions_1.loadExperiments();
// initialize locale
var queryStringParts = querystring_1.parse(window.location.search.substr(1));
ResourceStrings_1.ResourceStrings.config(queryStringParts.locale, true);
// Enable high contrast theming for the app
var highContrastColorProviderService = new highcontrastcolorprovider_1.HighContrastColorProvider();
highContrastColorProviderService.enableHighContrastTheming();
// Enable high contrast theming when links that load a page in the window without navigating to it.
window.addEventListener("customDocumentLoad", function () {
    highContrastColorProviderService.enableHighContrastTheming();
}, false);
// Use a CSS class name to indicate if a keyboard focus or
// mouse focus visual should be shown.
var keyboardingFocusClassName = "keyboarding";
window.addEventListener("mousedown", function () {
    document.body.classList.remove(keyboardingFocusClassName);
});
window.addEventListener("keydown", function (ev) {
    if (ev.key === "Tab") {
        document.body.classList.add(keyboardingFocusClassName);
    }
});
// global helper to forward enter and space keypress to the click handler
window.keyPressToClickHelper = function (ev) {
    if ([KeyCodes_1.keyCodes.SPACE, KeyCodes_1.keyCodes.ENTER].indexOf(ev.keyCode) !== -1) {
        ev.target.onclick({});
    }
};
//# sourceMappingURL=common.js.map