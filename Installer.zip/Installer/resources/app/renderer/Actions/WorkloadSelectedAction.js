/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var dispatcher_1 = require("../dispatcher");
var WorkloadSelectedEvent_1 = require("../Events/WorkloadSelectedEvent");
var workload_selection_telemetry_proxy_1 = require("../Telemetry/workload-selection-telemetry-proxy");
/* istanbul ignore next */
function updateSelectedWorkloads(selectedWorkload, options) {
    dispatcher_1.dispatcher.dispatch(new WorkloadSelectedEvent_1.WorkloadSelectedEvent(selectedWorkload, options));
    workload_selection_telemetry_proxy_1.workloadSelectionTelemetryProxy.recordWorkloadSelection(selectedWorkload.id, selectedWorkload.name, options.checked);
}
exports.updateSelectedWorkloads = updateSelectedWorkloads;
//# sourceMappingURL=WorkloadSelectedAction.js.map