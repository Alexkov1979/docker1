/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var DetailsPageTelemetryProxy_1 = require("../Telemetry/DetailsPageTelemetryProxy");
var vs_telemetry_api_1 = require("vs-telemetry-api");
function startDetailsPageSession(mode, channelId, productId, productName, buildVersion, installationId) {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.startDetailsPageSession(mode, channelId, productId, productName, buildVersion, installationId);
}
exports.startDetailsPageSession = startDetailsPageSession;
function endDetailsPageSessionWithSuccess() {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.endDetailsPageSession(vs_telemetry_api_1.TelemetryResult.Success);
}
exports.endDetailsPageSessionWithSuccess = endDetailsPageSessionWithSuccess;
function endDetailsPageSessionWithFail() {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.endDetailsPageSession(vs_telemetry_api_1.TelemetryResult.Failure);
}
exports.endDetailsPageSessionWithFail = endDetailsPageSessionWithFail;
function endDetailsPageSessionWithNone() {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.endDetailsPageSession(vs_telemetry_api_1.TelemetryResult.None);
}
exports.endDetailsPageSessionWithNone = endDetailsPageSessionWithNone;
function endDetailsPageSessionWithUserCancel() {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.endDetailsPageSession(vs_telemetry_api_1.TelemetryResult.UserCancel);
}
exports.endDetailsPageSessionWithUserCancel = endDetailsPageSessionWithUserCancel;
function sendDiskSizeWarningShown() {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.sendDiskSizeWarningShown();
}
exports.sendDiskSizeWarningShown = sendDiskSizeWarningShown;
function sendDiskSizeWarningIgnored() {
    DetailsPageTelemetryProxy_1.detailsPageTelemetryProxy.sendDiskSizeWarningIgnored();
}
exports.sendDiskSizeWarningIgnored = sendDiskSizeWarningIgnored;
//# sourceMappingURL=DetailsPageActions.js.map