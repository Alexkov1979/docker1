/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var dispatcher_1 = require("../dispatcher");
var enum_1 = require("../../lib/enum");
var experiments_1 = require("../../lib/experiments/experiments");
var experiments_changed_event_1 = require("../Events/experiments-changed-event");
var experiments_factory_1 = require("../experiments-factory");
var proxy = experiments_factory_1.getExperiments();
var flightIds = enum_1.EnumExtensions.getNames(experiments_1.ExperimentName);
function loadExperiments() {
    var results = [];
    var fetchPromise = flightIds.map(function (id) {
        return proxy.isEnabled(id)
            .catch(function () { return false; })
            .then(function (isEnabled) {
            if (isEnabled) {
                results.push(id);
            }
        });
    });
    Promise.all(fetchPromise)
        .then(function () {
        dispatcher_1.dispatcher.dispatch(new experiments_changed_event_1.ExperimentsChangedEvent(results));
    });
}
exports.loadExperiments = loadExperiments;
//# sourceMappingURL=experiments-actions.js.map