/*---------------------------------------------------------
* Copyright (C) Microsoft Corporation. All rights reserved.
*--------------------------------------------------------*/
"use strict";
var error_message_response_1 = require("../interfaces/error-message-response");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var errorNames = require("../../lib/error-names");
var telemetryEventNames = require("../../lib/Telemetry/TelemetryEventNames");
var CancelInstallAction = (function () {
    function CancelInstallAction(telemetryProxy, errorStore, installActionsParam) {
        this._telemetryProxy = telemetryProxy;
        this._errorStore = errorStore;
        this._installerActions = installActionsParam;
    }
    CancelInstallAction.prototype.cancelInstallOperation = function (productSummary, telemetryContext) {
        var _this = this;
        var options = {
            title: ResourceStrings_1.ResourceStrings.cancelInstallWarningTitle,
            message: [
                ResourceStrings_1.ResourceStrings.cancelInstallWarningMessage
            ],
            allowCancel: true,
            isCancelDefault: true,
            okButtonText: ResourceStrings_1.ResourceStrings.yes,
            cancelButtonText: ResourceStrings_1.ResourceStrings.no,
            hideSupportLink: true,
            errorName: errorNames.CANCEL_INSTALL_CONFIRMATION_DIALOG,
        };
        this._errorStore.show(options)
            .then(function (result) {
            if (result.buttonType !== error_message_response_1.ButtonType.DEFAULT_SUBMIT) {
                _this._telemetryProxy.sendIpcAtomicEvent(telemetryEventNames.CANCEL_CONFIRMATION_DIALOG, true, {
                    CancelConfirmationAction: "Deferred_Cancel"
                });
                return;
            }
            _this._telemetryProxy.sendIpcAtomicEvent(telemetryEventNames.CANCEL_CONFIRMATION_DIALOG, true, {
                CancelConfirmationAction: "Confirmed_Cancel"
            });
            var operation = "cancel";
            telemetryContext.initiatedFromCommandLine = false; // Cancel is never called from the command line
            telemetryContext.userRequestedOperation = operation;
            _this._installerActions.cancelInstallOperation(productSummary, telemetryContext);
        });
    };
    return CancelInstallAction;
}());
exports.CancelInstallAction = CancelInstallAction;
//# sourceMappingURL=install-action-cancel.js.map