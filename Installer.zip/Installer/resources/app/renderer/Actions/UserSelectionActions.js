/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var dispatcher_1 = require("../dispatcher");
var installed_product_received_event_1 = require("../Events/installed-product-received-event");
var InstallerProxy_1 = require("../Installer/InstallerProxy");
var Product_1 = require("../../lib/Installer/Product");
var locale_handler_1 = require("../../lib/locale-handler");
var product_received_event_1 = require("../Events/product-received-event");
var ResetSelectionsEvent_1 = require("../Events/ResetSelectionsEvent");
/* istanbul ignore next */
function updateSelectedProduct(productSummary, languages, withUpdatePackages) {
    dispatcher_1.dispatcher.dispatch(new ResetSelectionsEvent_1.ResetSelectionsEvent());
    if (Product_1.isTypeOfInstalledProduct(productSummary)) {
        return InstallerProxy_1.installerProxy.getInstalledProduct(productSummary.installationPath, withUpdatePackages)
            .then(function (product) {
            // Select currently installed languages
            selectLanguages(product, product.installedLanguages, true);
            // Additionally unselect specified languages from command line
            selectLanguages(product, languages.languagesToRemove, false);
            // Additionally select specified languages from command line
            selectLanguages(product, languages.languagesToAdd, true);
            dispatcher_1.dispatcher.dispatch(new installed_product_received_event_1.InstalledProductReceivedEvent(product));
            return product;
        })
            .catch(function (e) {
            dispatcher_1.dispatcher.dispatch(new installed_product_received_event_1.InstalledProductReceivedEvent(undefined, e));
        });
    }
    else if (Product_1.isTypeOfProductSummary(productSummary)) {
        return InstallerProxy_1.installerProxy.getProduct(productSummary.channelId, productSummary.id)
            .then(function (product) {
            // Select specified languages or fallback to the app language
            if (languages.languagesToAdd.length > 0) {
                selectLanguages(product, languages.languagesToAdd, true);
            }
            else {
                selectLanguages(product, [languages.appLanguage], true);
            }
            dispatcher_1.dispatcher.dispatch(new product_received_event_1.ProductReceivedEvent(product));
            return product;
        })
            .catch(function (e) {
            dispatcher_1.dispatcher.dispatch(new product_received_event_1.ProductReceivedEvent(undefined, e));
        });
    }
    else {
        throw new Error("Type error: IProductSummaryBase was neither of type IProductSummary" +
            " nor of type IInstalledProductSummary.");
    }
}
exports.updateSelectedProduct = updateSelectedProduct;
/* istanbul ignore next */
function updateSelectedInstalledProductForPath(installationPath, withUpdatePackages) {
    dispatcher_1.dispatcher.dispatch(new ResetSelectionsEvent_1.ResetSelectionsEvent());
    return InstallerProxy_1.installerProxy.getInstalledProduct(installationPath, withUpdatePackages)
        .then(function (installedProduct) {
        dispatcher_1.dispatcher.dispatch(new installed_product_received_event_1.InstalledProductReceivedEvent(installedProduct));
        return installedProduct;
    })
        .catch(function (e) {
        dispatcher_1.dispatcher.dispatch(new installed_product_received_event_1.InstalledProductReceivedEvent(undefined, e));
        throw e;
    });
}
exports.updateSelectedInstalledProductForPath = updateSelectedInstalledProductForPath;
/* istanbul ignore next */
function selectLanguages(product, languages, select) {
    if (!languages) {
        return;
    }
    var needToFallback = true;
    languages.forEach(function (language) {
        var option = product.getLanguageOption(locale_handler_1.LocaleHandler.getSupportedLocale(language));
        if (option) {
            option.isSelected = select;
            needToFallback = false;
        }
    });
    if (needToFallback) {
        var fallbackLanguage = product.getLanguageOption(locale_handler_1.LocaleHandler.DEFAULT_LOCALE);
        if (fallbackLanguage) {
            fallbackLanguage.isSelected = select;
        }
    }
}
//# sourceMappingURL=UserSelectionActions.js.map