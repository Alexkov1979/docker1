/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var TabSwitchTelemetryProxy_1 = require("../Telemetry/TabSwitchTelemetryProxy");
var InstallerState_1 = require("../../lib/InstallerState");
function sendTabSwitchTelemetry(nextTab, installedProducts, installingProducts, uninstallingProducts, partialInstalls, state) {
    var installerState = new InstallerState_1.InstallerState(state, installedProducts, installingProducts, uninstallingProducts, partialInstalls);
    TabSwitchTelemetryProxy_1.tabSwitchTelemetryProxy.tabSwitched(nextTab, installerState);
}
exports.sendTabSwitchTelemetry = sendTabSwitchTelemetry;
function sendFocusGained(state) {
    TabSwitchTelemetryProxy_1.tabSwitchTelemetryProxy.focusGained(state);
}
exports.sendFocusGained = sendFocusGained;
function sendFocusLost(state) {
    TabSwitchTelemetryProxy_1.tabSwitchTelemetryProxy.focusLost(state);
}
exports.sendFocusLost = sendFocusLost;
//# sourceMappingURL=TabSwitchAction.js.map