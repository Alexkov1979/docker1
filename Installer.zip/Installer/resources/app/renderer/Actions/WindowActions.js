/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/globals/node/index.d.ts" />
/// <reference path="../../typings/globals/electron/github-electron/index.d.ts" />
"use strict";
var constants = require("../../lib/window-action-constants");
var dispatcher_1 = require("../dispatcher");
var electron_1 = require("electron");
var WindowStateChangedEvent_1 = require("../Events/WindowStateChangedEvent");
var window_close_request_event_1 = require("../Events/window-close-request-event");
var SUCCESS_RETURN_CODE = 0;
var ERROR_RETURN_CODE = 1;
var WindowActions = (function () {
    function WindowActions() {
        electron_1.ipcRenderer.on(constants.WINDOW_STATE_RESPONSE, function (event, state) {
            dispatcher_1.dispatcher.dispatch(new WindowStateChangedEvent_1.WindowStateChangedEvent(new WindowStateChangedEvent_1.WindowState(state.maximized)));
        });
    }
    /* istanbul ignore next */
    WindowActions.prototype.minimizeWindow = function () {
        electron_1.ipcRenderer.send(constants.MINIMIZE_WINDOW);
    };
    /* istanbul ignore next */
    WindowActions.prototype.maximizeOrRestoreWindow = function () {
        electron_1.ipcRenderer.send(constants.MAXIMIZE_RESTORE_WINDOW);
    };
    /* istanbul ignore next */
    WindowActions.prototype.requestWindowState = function () {
        electron_1.ipcRenderer.send(constants.WINDOW_STATE_REQUEST);
    };
    /* istanbul ignore next */
    WindowActions.prototype.quitApp = function (success, errorMessage, exitCode) {
        if (errorMessage === void 0) { errorMessage = null; }
        // don't want to override a specified exit code of 0, so
        // compare against undefined instead of doing a falsey check
        if (exitCode === undefined) {
            exitCode = success ? SUCCESS_RETURN_CODE : ERROR_RETURN_CODE;
        }
        electron_1.ipcRenderer.send(constants.CLOSE_WINDOW, exitCode, errorMessage);
    };
    /* istanbul ignore next */
    WindowActions.prototype.closeWindow = function (success, errorMessage, exitCode) {
        if (!this.isWindowCloseBlocked()) {
            this.quitApp(success, errorMessage, exitCode);
        }
    };
    /* istanbul ignore next */
    WindowActions.prototype.startListeningForWindowClose = function (window) {
        var _this = this;
        window.addEventListener("beforeunload", function (ev) { return _this.onBeforeUnload(ev); });
    };
    /* istanbul ignore next */
    WindowActions.prototype.stopListeningForWindowClose = function (window) {
        var _this = this;
        window.removeEventListener("beforeunload", function (ev) { return _this.onBeforeUnload(ev); });
    };
    /* istanbul ignore next */
    WindowActions.prototype.onBeforeUnload = function (ev) {
        if (this.isWindowCloseBlocked()) {
            ev.returnValue = false;
        }
    };
    /* istanbul ignore next */
    WindowActions.prototype.isWindowCloseBlocked = function () {
        var event = new window_close_request_event_1.WindowCloseRequestEvent();
        dispatcher_1.dispatcher.dispatch(event);
        return event.defaultPrevented;
    };
    return WindowActions;
}());
exports.windowActions = new WindowActions();
//# sourceMappingURL=WindowActions.js.map