/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/globals/node/index.d.ts" />
/// <reference path="../../typings/globals/electron/github-electron/index.d.ts" />
"use strict";
var electron_1 = require("electron");
function openFeedbackClient(channelIds, initialSearchText, initialReproText, additionalTags) {
    electron_1.ipcRenderer.send("open-feedback-client", channelIds, initialSearchText, initialReproText, additionalTags);
}
exports.openFeedbackClient = openFeedbackClient;
//# sourceMappingURL=open-feedback-client-action.js.map