/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
/**
 * Creates a {CSSStyleMap} to simplify setting styles of an {HTMLElement}
 * @return {CSSStyleMap} representation of CSS. Call toString() to use in a style attribute
 */
function createStyleMap(styles) {
    var div = document.createElement("div");
    // decorate style with a toString method
    div.style.toString = function () {
        return div.style.cssText;
    };
    if (styles) {
        Object.keys(styles).forEach(function (styleName) { return div.style[styleName] = styles[styleName]; });
    }
    return div.style;
}
exports.createStyleMap = createStyleMap;
//# sourceMappingURL=css-styles.js.map