/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
require("./common");
require("./Components/UninstallRoot");
// render the app
riot.mount("*");
//# sourceMappingURL=uninstall.js.map