/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../typings/globals/es6-shim/index.d.ts" />
/// <reference path="../typings/globals/node/index.d.ts" />
"use strict";
(function (InstallingState) {
    InstallingState[InstallingState["Installing"] = 0] = "Installing";
    InstallingState[InstallingState["NotInstalling"] = 1] = "NotInstalling";
    InstallingState[InstallingState["Repairing"] = 2] = "Repairing";
    InstallingState[InstallingState["Uninstalling"] = 3] = "Uninstalling";
    InstallingState[InstallingState["Updating"] = 4] = "Updating";
    InstallingState[InstallingState["Modifying"] = 5] = "Modifying";
    InstallingState[InstallingState["Cancelling"] = 6] = "Cancelling";
})(exports.InstallingState || (exports.InstallingState = {}));
var InstallingState = exports.InstallingState;
//# sourceMappingURL=InstallingState.js.map