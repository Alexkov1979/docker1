/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var ResetSelectionsEvent = (function () {
    function ResetSelectionsEvent() {
    }
    return ResetSelectionsEvent;
}());
exports.ResetSelectionsEvent = ResetSelectionsEvent;
//# sourceMappingURL=ResetSelectionsEvent.js.map