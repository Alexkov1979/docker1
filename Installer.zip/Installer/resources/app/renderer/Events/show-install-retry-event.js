/*---------------------------------------------------------
* Copyright (C) Microsoft Corporation. All rights reserved.
*--------------------------------------------------------*/
"use strict";
var ShowInstallRetryEvent = (function () {
    function ShowInstallRetryEvent(message, neutralMessage, retryAction) {
        this._retryAction = retryAction;
        this._neutralMessage = neutralMessage;
        this._message = message;
    }
    Object.defineProperty(ShowInstallRetryEvent.prototype, "retryAction", {
        get: function () {
            return this._retryAction;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowInstallRetryEvent.prototype, "message", {
        get: function () {
            return this._message;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowInstallRetryEvent.prototype, "neutralMessage", {
        get: function () {
            return this._neutralMessage;
        },
        enumerable: true,
        configurable: true
    });
    return ShowInstallRetryEvent;
}());
exports.ShowInstallRetryEvent = ShowInstallRetryEvent;
//# sourceMappingURL=show-install-retry-event.js.map