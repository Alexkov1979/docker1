/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var LaunchBannerClosedEvent = (function () {
    function LaunchBannerClosedEvent() {
    }
    return LaunchBannerClosedEvent;
}());
exports.LaunchBannerClosedEvent = LaunchBannerClosedEvent;
//# sourceMappingURL=launch-banner-closed-event.js.map