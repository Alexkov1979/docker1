/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var DeepCleanPreviewInstallationsStarted = (function () {
    function DeepCleanPreviewInstallationsStarted() {
    }
    return DeepCleanPreviewInstallationsStarted;
}());
exports.DeepCleanPreviewInstallationsStarted = DeepCleanPreviewInstallationsStarted;
var DeepCleanPreviewInstallationsCompleted = (function () {
    function DeepCleanPreviewInstallationsCompleted() {
    }
    return DeepCleanPreviewInstallationsCompleted;
}());
exports.DeepCleanPreviewInstallationsCompleted = DeepCleanPreviewInstallationsCompleted;
//# sourceMappingURL=deep-clean-preview-installations-events.js.map