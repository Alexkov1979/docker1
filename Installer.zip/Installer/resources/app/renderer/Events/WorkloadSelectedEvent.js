/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var requires = require("../../lib/requires");
var WorkloadSelectedEvent = (function () {
    function WorkloadSelectedEvent(selectedWorkload, options) {
        requires.notNullOrUndefined(selectedWorkload, "selectedWorkload");
        requires.notNullOrUndefined(options, "options");
        this._selectedWorkload = selectedWorkload;
        this._options = options;
    }
    Object.defineProperty(WorkloadSelectedEvent.prototype, "selectedWorkload", {
        get: function () {
            return this._selectedWorkload;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadSelectedEvent.prototype, "options", {
        get: function () {
            return this._options;
        },
        enumerable: true,
        configurable: true
    });
    return WorkloadSelectedEvent;
}());
exports.WorkloadSelectedEvent = WorkloadSelectedEvent;
//# sourceMappingURL=WorkloadSelectedEvent.js.map