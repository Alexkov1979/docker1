/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var ExperimentsChangedEvent = (function () {
    function ExperimentsChangedEvent(enabledExperiments) {
        this._enabledExperiments = enabledExperiments;
    }
    Object.defineProperty(ExperimentsChangedEvent.prototype, "enabledExperiments", {
        get: function () {
            return this._enabledExperiments;
        },
        enumerable: true,
        configurable: true
    });
    return ExperimentsChangedEvent;
}());
exports.ExperimentsChangedEvent = ExperimentsChangedEvent;
//# sourceMappingURL=experiments-changed-event.js.map