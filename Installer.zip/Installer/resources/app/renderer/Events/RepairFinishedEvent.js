/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/* istanbul ignore next */
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var operation_finished_event_1 = require("./operation-finished-event");
var reboot_timing_1 = require("../interfaces/reboot-timing");
var RepairFinishedEvent = (function (_super) {
    __extends(RepairFinishedEvent, _super);
    function RepairFinishedEvent(product, nickname, installationPath, success, log, rebootTiming) {
        if (success === void 0) { success = true; }
        if (log === void 0) { log = ""; }
        if (rebootTiming === void 0) { rebootTiming = reboot_timing_1.RebootTiming.None; }
        _super.call(this, product, nickname, installationPath, success, log, rebootTiming);
        this._product = product;
    }
    RepairFinishedEvent.prototype.getProduct = function () {
        return this._product;
    };
    return RepairFinishedEvent;
}(operation_finished_event_1.OperationFinishedEvent));
exports.RepairFinishedEvent = RepairFinishedEvent;
//# sourceMappingURL=RepairFinishedEvent.js.map