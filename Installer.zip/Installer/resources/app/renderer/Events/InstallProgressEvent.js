/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var InstallProgressEvent = (function () {
    function InstallProgressEvent(installationPath, type, progress, detail) {
        this.installationPath = installationPath;
        this.type = type;
        this.progress = progress;
        this.detail = detail;
    }
    return InstallProgressEvent;
}());
exports.InstallProgressEvent = InstallProgressEvent;
//# sourceMappingURL=InstallProgressEvent.js.map