/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var ElevationRequiredEvent = (function () {
    function ElevationRequiredEvent() {
    }
    return ElevationRequiredEvent;
}());
exports.ElevationRequiredEvent = ElevationRequiredEvent;
//# sourceMappingURL=ElevationRequiredEvent.js.map