/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/* istanbul ignore next */
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var operation_finished_event_1 = require("./operation-finished-event");
var reboot_timing_1 = require("../interfaces/reboot-timing");
var ModifyFinishedEvent = (function (_super) {
    __extends(ModifyFinishedEvent, _super);
    function ModifyFinishedEvent(product, nickname, installationPath, success, log, rebootTiming) {
        if (success === void 0) { success = true; }
        if (log === void 0) { log = ""; }
        if (rebootTiming === void 0) { rebootTiming = reboot_timing_1.RebootTiming.None; }
        _super.call(this, product, nickname, installationPath, success, log, rebootTiming);
        this._product = product;
    }
    ModifyFinishedEvent.prototype.getProduct = function () {
        return this._product;
    };
    return ModifyFinishedEvent;
}(operation_finished_event_1.OperationFinishedEvent));
exports.ModifyFinishedEvent = ModifyFinishedEvent;
//# sourceMappingURL=ModifyFinishedEvent.js.map