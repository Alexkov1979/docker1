/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var CompleteCommandLineOperationEvent = (function () {
    function CompleteCommandLineOperationEvent() {
    }
    return CompleteCommandLineOperationEvent;
}());
exports.CompleteCommandLineOperationEvent = CompleteCommandLineOperationEvent;
//# sourceMappingURL=complete-command-line-operation-event.js.map