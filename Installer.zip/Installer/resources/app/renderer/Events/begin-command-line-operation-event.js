/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var BeginCommandLineOperationEvent = (function () {
    function BeginCommandLineOperationEvent() {
    }
    return BeginCommandLineOperationEvent;
}());
exports.BeginCommandLineOperationEvent = BeginCommandLineOperationEvent;
//# sourceMappingURL=begin-command-line-operation-event.js.map