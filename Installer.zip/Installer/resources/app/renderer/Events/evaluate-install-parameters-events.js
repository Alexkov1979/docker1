/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var EvaluateInstallParametersStartedEvent = (function () {
    function EvaluateInstallParametersStartedEvent() {
    }
    return EvaluateInstallParametersStartedEvent;
}());
exports.EvaluateInstallParametersStartedEvent = EvaluateInstallParametersStartedEvent;
var EvaluateInstallParametersFinishedEvent = (function () {
    function EvaluateInstallParametersFinishedEvent(evaluation, failed) {
        if (failed === void 0) { failed = false; }
        this._evaluation = evaluation;
        this._failed = failed;
    }
    Object.defineProperty(EvaluateInstallParametersFinishedEvent.prototype, "evaluation", {
        get: function () {
            return this._evaluation;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(EvaluateInstallParametersFinishedEvent.prototype, "failed", {
        get: function () {
            return this._failed;
        },
        enumerable: true,
        configurable: true
    });
    return EvaluateInstallParametersFinishedEvent;
}());
exports.EvaluateInstallParametersFinishedEvent = EvaluateInstallParametersFinishedEvent;
//# sourceMappingURL=evaluate-install-parameters-events.js.map