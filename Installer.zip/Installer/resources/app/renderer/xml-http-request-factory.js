/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var RendererXMLHttpRequestFactory = (function () {
    function RendererXMLHttpRequestFactory() {
    }
    RendererXMLHttpRequestFactory.prototype.getInstance = function () {
        return new XMLHttpRequest();
    };
    return RendererXMLHttpRequestFactory;
}());
exports.RendererXMLHttpRequestFactory = RendererXMLHttpRequestFactory;
//# sourceMappingURL=xml-http-request-factory.js.map