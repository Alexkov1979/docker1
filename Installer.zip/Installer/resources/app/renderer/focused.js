/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
require("./common");
require("./Components/focused-window");
//# sourceMappingURL=focused.js.map