/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
require("./common");
require("./Components/survey-prompt-window");
//# sourceMappingURL=survey-prompt.js.map