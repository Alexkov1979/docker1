/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/globals/electron/github-electron/index.d.ts" />
/// <reference path="../../typings/globals/node/index.d.ts" />
"use strict";
var TelemetryProxy_1 = require("../Telemetry/TelemetryProxy");
var TelemetryEventNames = require("../../lib/Telemetry/TelemetryEventNames");
var Session_1 = require("../../lib/Session");
var TelemetryAssetManager_1 = require("../../lib/Telemetry/TelemetryAssetManager");
var DetailsPageTelemetryProxy = (function () {
    function DetailsPageTelemetryProxy() {
    }
    DetailsPageTelemetryProxy.prototype.startDetailsPageSession = function (mode, channelId, productId, productName, productVersion, installationId) {
        this._lastDetailsPageSessionId = this.createSessionId();
        var properties = {
            mode: mode,
            channelId: channelId,
            productId: productId,
            productName: productName,
            productVersion: productVersion
        };
        TelemetryProxy_1.telemetryProxy.sendIpcStartUserTask(TelemetryEventNames.DETAILS_PAGE_SESSION, this._lastDetailsPageSessionId, properties);
        var detailsPageProductId = TelemetryAssetManager_1.ProductTelemetryAssetInformation.makeUniqueKeyForProduct(channelId, productId, productVersion, installationId);
        TelemetryProxy_1.telemetryProxy.sendIpcAddProductsToEvent(this._lastDetailsPageSessionId, null, detailsPageProductId);
    };
    DetailsPageTelemetryProxy.prototype.endDetailsPageSession = function (result) {
        TelemetryProxy_1.telemetryProxy.sendIpcEndUserTask(TelemetryEventNames.DETAILS_PAGE_SESSION, this._lastDetailsPageSessionId, null, result);
        this._lastDetailsPageSessionId = null;
    };
    DetailsPageTelemetryProxy.prototype.sendDiskSizeWarningShown = function () {
        TelemetryProxy_1.telemetryProxy.sendIpcAtomicEvent(TelemetryEventNames.DISK_SIZE_WARNING_SHOWN_TO_USER, false, /* isUserTask */ null);
    };
    DetailsPageTelemetryProxy.prototype.sendDiskSizeWarningIgnored = function () {
        TelemetryProxy_1.telemetryProxy.sendIpcAtomicEvent(TelemetryEventNames.DISK_SIZE_WARNING_IGNORED_BY_USER, true, /* isUserTask */ null);
    };
    DetailsPageTelemetryProxy.prototype.createSessionId = function () {
        return Session_1.createSessionId();
    };
    return DetailsPageTelemetryProxy;
}());
exports.DetailsPageTelemetryProxy = DetailsPageTelemetryProxy;
exports.detailsPageTelemetryProxy = new DetailsPageTelemetryProxy();
//# sourceMappingURL=DetailsPageTelemetryProxy.js.map