/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/riot-ts-missing-declares.d.ts" />
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var css_styles_1 = require("../css-styles");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var open_external_actions_1 = require("../Actions/open-external-actions");
var Product_1 = require("../../lib/Installer/Product");
var factory_1 = require("../Actions/factory");
require("./product-status");
require("./product-view");
var InstalledProduct = (function (_super) {
    __extends(InstalledProduct, _super);
    function InstalledProduct() {
        _super.apply(this, arguments);
        this.openProblemsBind = this.openProblemsDialog.bind(this);
        this.releaseNotesClickedBind = this.releaseNotesClicked.bind(this);
    }
    Object.defineProperty(InstalledProduct.prototype, "releaseNotesText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.releaseNotes;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "title", {
        get: function () {
            return this.opts.product.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "product", {
        get: function () {
            return this.opts.product;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "canUpdate", {
        get: function () {
            return this.opts.canupdate;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "disableButtons", {
        get: function () {
            return this.opts.disablebuttons;
        },
        enumerable: true,
        configurable: true
    });
    InstalledProduct.prototype.modifyClicked = function () {
        this.opts.modifyclicked(this.opts.product);
    };
    InstalledProduct.prototype.uninstallClicked = function () {
        this.opts.uninstallclicked(this.opts.product);
    };
    InstalledProduct.prototype.launchClicked = function () {
        this.opts.launchclicked(this.opts.product);
    };
    InstalledProduct.prototype.updateClicked = function () {
        this.opts.updateclicked(this.opts.product);
    };
    InstalledProduct.prototype.repairClicked = function () {
        this.opts.repairclicked(this.opts.product);
    };
    Object.defineProperty(InstalledProduct.prototype, "launchButtonOptions", {
        get: function () {
            var _this = this;
            return {
                disabled: this.disableButtons,
                text: ResourceStrings_1.ResourceStrings.launch,
                onclick: function () { _this.launchClicked(); }
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "updateButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: ResourceStrings_1.ResourceStrings.update,
                onclick: function () { _this.updateClicked(); },
                tooltip: this.updateText,
                disabled: this.disableButtons,
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "modifyButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: ResourceStrings_1.ResourceStrings.modify,
                onclick: function () { _this.modifyClicked(); },
                disabled: this.disableButtons,
                name: "modify",
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "uninstallButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: this.isPreviewInstall ? ResourceStrings_1.ResourceStrings.uninstallPreview : ResourceStrings_1.ResourceStrings.uninstall,
                onclick: function () { _this.uninstallClicked(); },
                disabled: this.disableButtons,
                name: "uninstall",
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "repairButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: ResourceStrings_1.ResourceStrings.repair,
                onclick: function () { _this.repairClicked(); },
                disabled: this.disableButtons,
                name: "repair",
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "actionButtonOptions", {
        get: function () {
            if (this.isPreviewInstall) {
                return [this.uninstallButtonOptions];
            }
            var options = [this.canUpdate ? this.updateButtonOptions : this.modifyButtonOptions];
            options.push(this.launchButtonOptions);
            return options;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "dropdownOptions", {
        get: function () {
            if (this.isPreviewInstall) {
                return [];
            }
            var options = [
                this.repairButtonOptions,
                this.uninstallButtonOptions,
            ];
            if (this.canUpdate) {
                options.push(this.modifyButtonOptions);
            }
            return options;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "buttonOptions", {
        get: function () {
            return {
                actionbuttons: this.actionButtonOptions,
                actionmenubuttons: this.dropdownOptions,
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "updateText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.updateTo(this.product.latestVersion.display);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "linksDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignItems: "flex-end",
                display: "flex",
                margin: "1px 0px 4px",
                marginTop: "2px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "longDescriptionStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                height: "2.15rem",
                overflow: "hidden",
                // Multiline ellipsis
                display: "-webkit-box",
                webkitLineClamp: "2",
                webkitBoxOrient: "vertical",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "longDescriptionText", {
        get: function () {
            return this.product.longDescription || this.product.description;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "singleLineStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginRight: "5px",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "pipeStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                fontSize: ".7rem",
                margin: "0 4px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "spacerDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "1 0 auto",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "hasError", {
        get: function () {
            return this.product && this.product.hasErrors;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "errorString", {
        get: function () {
            if (this.hasError) {
                return ResourceStrings_1.ResourceStrings.setupCompletedWithWarnings;
            }
            return null;
        },
        enumerable: true,
        configurable: true
    });
    InstalledProduct.prototype.openProblemsDialog = function (event) {
        factory_1.viewProblemsActions.viewProblems(this.product, this.opts.log);
    };
    Object.defineProperty(InstalledProduct.prototype, "isPreviewInstall", {
        get: function () {
            // There is an issue with trying to modify or update preview installations,
            // so we will only allow uninstall.
            if (this.opts && this.opts.product) {
                return Product_1.isPreviewProduct(this.opts.product);
            }
            return false;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstalledProduct.prototype, "viewProblemsText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.viewProblems;
        },
        enumerable: true,
        configurable: true
    });
    InstalledProduct.prototype.releaseNotesClicked = function (ev) {
        open_external_actions_1.openReleaseNotesUrl(this.product.releaseNotes);
    };
    InstalledProduct = __decorate([
        template("\n<installed-product>\n    <product-view buttonoptions={this.buttonOptions}\n                  product={this.product}\n                  disablemenu={this.disableButtons}>\n\n        <!-- Warnings -->\n        <product-status if={this.parent.hasError}\n            iscritical={false}\n            errorstring={this.parent.errorString} />\n\n        <!-- Long description -->\n        <virtual if={!this.parent.errorString}>\n            <div class=\"product-description\"\n                 style={this.parent.longDescriptionStyle}\n                 tabindex=\"0\"\n                 aria-label={this.parent.longDescriptionText}>\n                {this.parent.longDescriptionText}\n            </div>\n        </virtual>\n\n        <div style={this.parent.linksDivStyle}>\n\n            <!-- \"Release notes\" link -->\n            <span style={this.parent.singleLineStyle}>\n                <a href=\"#\"\n                    class=\"clickable\"\n                    onClick={this.parent.releaseNotesClickedBind}\n                    onkeypress={keyPressToClickHelper}>\n                        {this.parent.releaseNotesText}\n                </a>\n                <span if={this.parent.hasError}\n                      class=\"disabled-text\"\n                      style={this.parent.pipeStyle}> | </span>\n                <a if={this.parent.hasError}\n                   onclick={this.parent.openProblemsBind}\n                   title={this.parent.viewProblemsText}\n                   onkeypress={keyPressToClickHelper}\n                   tabindex=\"0\">\n                    {this.parent.viewProblemsText}\n                </a>\n            </span>\n        </div>\n\n    </product-view>\n</installed-product>")
    ], InstalledProduct);
    return InstalledProduct;
}(Riot.Element));
//# sourceMappingURL=installed-product.js.map