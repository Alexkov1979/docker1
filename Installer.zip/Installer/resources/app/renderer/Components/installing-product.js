/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/riot-ts-missing-declares.d.ts" />
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var InstallingState_1 = require("../InstallingState");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
require("./progress-view");
require("./product-view");
var InstallingProductOpts = (function () {
    function InstallingProductOpts() {
    }
    return InstallingProductOpts;
}());
exports.InstallingProductOpts = InstallingProductOpts;
/* istanbul ignore next */
var InstallingProduct = (function (_super) {
    __extends(InstallingProduct, _super);
    function InstallingProduct() {
        _super.apply(this, arguments);
    }
    InstallingProduct.prototype.mounted = function () {
        var progressView = this.root.getElementsByTagName("progress-view").item(0);
        if (progressView) {
            progressView.focus();
        }
    };
    Object.defineProperty(InstallingProduct.prototype, "ariaOperationLabel", {
        /**
         * @returns {string} - The operation name concatenated with the product name,
         *      or only the product name if the operation is unknown or none exists.
         */
        get: function () {
            var resourceMethod;
            switch (this.opts.operation) {
                case InstallingState_1.InstallingState.Cancelling:
                    resourceMethod = ResourceStrings_1.ResourceStrings.cancelling;
                    break;
                case InstallingState_1.InstallingState.Installing:
                    resourceMethod = ResourceStrings_1.ResourceStrings.installing;
                    break;
                case InstallingState_1.InstallingState.Modifying:
                    resourceMethod = ResourceStrings_1.ResourceStrings.modifying;
                    break;
                case InstallingState_1.InstallingState.NotInstalling:
                    // Not used
                    break;
                case InstallingState_1.InstallingState.Repairing:
                    resourceMethod = ResourceStrings_1.ResourceStrings.repairing;
                    break;
                case InstallingState_1.InstallingState.Uninstalling:
                    resourceMethod = ResourceStrings_1.ResourceStrings.uninstalling;
                    break;
                case InstallingState_1.InstallingState.Updating:
                    resourceMethod = ResourceStrings_1.ResourceStrings.updating;
                    break;
                default:
                    console.log("Unrecognized InstallingState: " + this.opts.operation);
            }
            if (resourceMethod) {
                return resourceMethod(this.product.name);
            }
            return this.product.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "product", {
        get: function () {
            return this.opts.product.product;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "canCancel", {
        get: function () {
            return this.opts.cancancel;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "progressBar1", {
        get: function () {
            return this.opts.progressbar1;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "progressBar2", {
        get: function () {
            return this.opts.progressbar2;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "buttonOptions", {
        get: function () {
            return {
                actionbuttons: this.actionButtonOptions,
                actionmenubuttons: undefined,
                onCheckboxClicked: this.opts.onCheckboxClicked,
                checkboxState: this.opts.checkboxState,
                checkboxLabel: this.opts.checkboxLabel,
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "version", {
        get: function () {
            // On an update operation, we want to show the user what version they are updating too,
            // and not the version it is currently at.
            if (this.opts.operation === InstallingState_1.InstallingState.Updating) {
                var installedProduct = this.product;
                return installedProduct.latestVersion.display;
            }
            return this.product.version.display;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "isCancelled", {
        /* Private Methods */
        get: function () {
            return this.opts.operation === InstallingState_1.InstallingState.Cancelling;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "cancelButtonOptions", {
        get: function () {
            var _this = this;
            return {
                disabled: this.isCancelled,
                text: ResourceStrings_1.ResourceStrings.cancel,
                onclick: function () { _this.opts.cancelclicked(_this.product); }
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InstallingProduct.prototype, "actionButtonOptions", {
        get: function () {
            if (this.canCancel) {
                return [this.cancelButtonOptions];
            }
            else {
                return [];
            }
        },
        enumerable: true,
        configurable: true
    });
    InstallingProduct = __decorate([
        template("\n<installing-product>\n    <product-view buttonoptions={this.buttonOptions}\n                  product={this.product}\n                  hideversion={true}>\n        <progress-view progressbar1={this.parent.progressBar1}\n                       progressbar2={this.parent.progressBar2}\n                       tabindex=\"-1\"\n                       aria-label={this.parent.ariaOperationLabel} />\n    </product-view>\n</installing-product>")
    ], InstallingProduct);
    return InstallingProduct;
}(Riot.Element));
exports.InstallingProduct = InstallingProduct;
//# sourceMappingURL=installing-product.js.map