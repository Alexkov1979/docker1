/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <reference path="../../typings/riot-ts-missing-declares.d.ts" />
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
var factory_1 = require("../stores/factory");
var error_message_response_1 = require("../interfaces/error-message-response");
var css_styles_1 = require("../css-styles");
var experiments_1 = require("../../lib/experiments/experiments");
var Utilities_1 = require("../Utilities");
var Product_1 = require("../../lib/Installer/Product");
var InstallingState_1 = require("../InstallingState");
var progress_calculator_1 = require("../progress-calculator");
var InstallerActions_1 = require("../Actions/InstallerActions");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var router_1 = require("./router");
var WindowActions_1 = require("../Actions/WindowActions");
var window_action_constants_1 = require("../../lib/window-action-constants");
var TelemetryEventNames = require("../../lib/Telemetry/TelemetryEventNames");
var errorNames = require("../../lib/error-names");
var command_line_actions_1 = require("../Actions/command-line-actions");
var command_line_operation_state_1 = require("../interfaces/command-line-operation-state");
var factory_2 = require("../Actions/factory");
var checkbox_state_1 = require("../interfaces/checkbox-state");
var product_launch_state_1 = require("../interfaces/product-launch-state");
require("./available-product");
require("./information-pane-section");
require("./installed-product");
require("./installing-product");
require("./list-view");
require("./partial-product");
require("./channel-header");
require("./launch-banner");
require("./loading-view");
var factory_3 = require("../Actions/factory");
var TelemetryProxy_1 = require("../Telemetry/TelemetryProxy");
/* istanbul ignore next */
var ProductsPage = (function (_super) {
    __extends(ProductsPage, _super);
    function ProductsPage() {
        _super.apply(this, arguments);
        this.installClickedBind = this.installClicked.bind(this);
        this.modifyClickedBind = this.modifyClicked.bind(this);
        this.repairClickedBind = this.repairClicked.bind(this);
        this.restartClickedBind = this.restartClicked.bind(this);
        this.uninstallClickedBind = this.uninstallClicked.bind(this);
        this.updateClickedBind = this.updateClicked.bind(this);
        this.launchClickedBind = this.launchClicked.bind(this);
        this._informationPaneSections = [
            {
                header: ResourceStrings_1.ResourceStrings.welcomeTitle,
                content: [ResourceStrings_1.ResourceStrings.welcomeBody]
            }
        ];
        this._downloadProgressBars = new Map();
        this._installProgressBars = new Map();
        this._progressCalculator = new progress_calculator_1.ProgressCalculator(factory_1.appStore);
        this._handleReloadBind = this.handleReload.bind(this);
        this._displayedPreviewDetectedDialog = false;
    }
    ProductsPage.prototype.mounted = function () {
        this.hookEvents(true);
        this.handleReload();
        this.focusOnFirstProduct();
        if (ProductsPage._firstTimeShowing === true) {
            ProductsPage._firstTimeShowing = false;
            TelemetryProxy_1.telemetryProxy.sendIpcAtomicEvent(TelemetryEventNames.APPLICATION_INITIALIZE, false);
        }
        if (!this.hasPreviewInstallations) {
            this.handleCommandLineOperation();
        }
    };
    ProductsPage.prototype.unmounted = function () {
        this.hookEvents(false);
    };
    ProductsPage.prototype.handleReload = function () {
        if (!this.hasPreviewInstallations) {
            this.handleCommandLineOperation();
        }
        var productsToLaunch = factory_1.appStore.productsToLaunch;
        var telemetryContext = factory_1.appStore.createTelemetryContext("launch");
        factory_2.autolaunchActions.launchProducts(productsToLaunch, telemetryContext);
        this.update();
    };
    Object.defineProperty(ProductsPage.prototype, "availableHeader", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.availableHeader;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "installedHeader", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.installed;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "installedAndInstallingList", {
        get: function () {
            return factory_1.appStore.installedAndInstallingItems;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "firstInstalledProduct", {
        get: function () {
            return this.installedAndInstallingList.find(function (p) {
                return p.installingState === InstallingState_1.InstallingState.NotInstalling
                    && p.product.installState === Product_1.InstallState.Installed;
            });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "channels", {
        get: function () {
            return factory_1.appStore.getInstallableChannels().filter(function (c) { return c.visibleProducts.length > 0; });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "progressCalculator", {
        get: function () {
            return this._progressCalculator;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "informationPaneSections", {
        get: function () {
            return this._informationPaneSections;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "availableHeaderDivId", {
        get: function () {
            return "available-product-header";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "numberOfVisibleChannels", {
        get: function () {
            return factory_1.appStore.numberOfVisibleChannels;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "isLoading", {
        get: function () {
            return factory_1.appStore.isLoading || this.isCommandLineProductLoading;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "loadingScreenText", {
        get: function () {
            return factory_1.appStore.isLoading ? ResourceStrings_1.ResourceStrings.gettingThingsReady : ResourceStrings_1.ResourceStrings.almostThere;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "disableButtons", {
        get: function () {
            return factory_1.appStore.isOperationInProgress;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "appVersion", {
        get: function () {
            return factory_1.appStore.getAppVersion();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "branch", {
        get: function () {
            return factory_1.appStore.branch;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Focus on the first product product visible in the UI.
     * The order of focusing is:
     *     1. Installing Product
     *     2. Installed Product
     *     3. Available Product
     */
    ProductsPage.prototype.focusOnFirstProduct = function () {
        // Get the first installing product visible
        var elementToFocus = this.root.getElementsByTagName("installing-product").item(0);
        if (!elementToFocus) {
            var firstInstalledProduct = this.installedAndInstallingList[0];
            if (firstInstalledProduct) {
                if (this.isCompleteInstall(firstInstalledProduct)) {
                    elementToFocus = this.root.getElementsByTagName("installed-product").item(0);
                }
                else if (this.isPartialInstall(firstInstalledProduct)) {
                    elementToFocus = this.root.getElementsByTagName("partial-product").item(0);
                }
            }
            else {
                elementToFocus = this.root.getElementsByTagName("available-product").item(0);
            }
        }
        if (elementToFocus) {
            elementToFocus.focus();
        }
    };
    ProductsPage.prototype.productAndVersionText = function (product) {
        if (Product_1.isTypeOfInstalledProduct(product)) {
            return ResourceStrings_1.ResourceStrings.productNameWithVersionTitle(product.displayNameWithNickname, product.version.display);
        }
        return ResourceStrings_1.ResourceStrings.productNameWithVersionTitle(product.displayName, product.version.display);
    };
    ProductsPage.prototype.restartClicked = function (product) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        WindowActions_1.windowActions.closeWindow(true, null, window_action_constants_1.EXIT_CODE_REBOOT_REQUESTED);
    };
    ProductsPage.prototype.isPartialInstall = function (item) {
        return item.installingState === InstallingState_1.InstallingState.NotInstalling
            && item.product.installState === Product_1.InstallState.Partial;
    };
    ProductsPage.prototype.isCompleteInstall = function (item) {
        return item.installingState === InstallingState_1.InstallingState.NotInstalling
            && item.product.installState === Product_1.InstallState.Installed;
    };
    ProductsPage.prototype.isInstallOperationInProgress = function (item) {
        return item.installingState !== InstallingState_1.InstallingState.NotInstalling
            || item.product.installState === Product_1.InstallState.Unknown;
    };
    ProductsPage.prototype.installClicked = function (productSummary) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        // show the nickname field on the details page if we have at least one product
        var showNickname = (factory_1.appStore.installedAndInstallingItems.length > 0);
        var nickname = null;
        var resetSelections = true;
        router_1.Router.goInstall(productSummary, resetSelections, nickname, showNickname);
    };
    ProductsPage.prototype.modifyClicked = function (productSummary) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        router_1.Router.goModify(productSummary, true /* resetSelections */);
    };
    ProductsPage.prototype.launchClicked = function (productSummary) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        var asInstalled = productSummary;
        var operation = "launch";
        var telemetryContext = factory_1.appStore.createTelemetryContext(operation);
        telemetryContext.initiatedFromCommandLine = false;
        InstallerActions_1.launch(asInstalled, telemetryContext);
    };
    ProductsPage.prototype.cancelClicked = function (productSummary) {
        var asInstalled = productSummary;
        var operation = "cancel";
        var telemetryContext = factory_1.appStore.createTelemetryContext(operation);
        telemetryContext.initiatedFromCommandLine = false;
        factory_3.cancelInstallAction.cancelInstallOperation(asInstalled, telemetryContext);
    };
    ProductsPage.prototype.updateClicked = function (productSummary) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        var asInstalled = productSummary;
        var isQuietOrPassive = false;
        var operation = "update";
        var telemetryContext = factory_1.appStore.createTelemetryContext(operation);
        telemetryContext.initiatedFromCommandLine = false;
        InstallerActions_1.update(asInstalled, isQuietOrPassive, factory_1.appStore.argv.productKey, telemetryContext, null /* layoutPath */);
    };
    ProductsPage.prototype.repairClicked = function (productSummary) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        var asInstalled = productSummary;
        var isQuietOrPassive = false;
        var operation = "repair";
        var telemetryContext = factory_1.appStore.createTelemetryContext(operation);
        telemetryContext.initiatedFromCommandLine = false;
        var options = {
            title: ResourceStrings_1.ResourceStrings.repairWarningTitle,
            message: [
                ResourceStrings_1.ResourceStrings.repairWarningMessage
            ],
            allowCancel: true,
            isCancelDefault: false,
            errorName: errorNames.REPAIR_PROMPT_ERROR_NAME,
        };
        factory_1.errorStore.show(options)
            .then(function (response) {
            if (response.buttonType === error_message_response_1.ButtonType.DEFAULT_SUBMIT) {
                InstallerActions_1.repair(asInstalled, isQuietOrPassive, telemetryContext);
            }
        });
    };
    ProductsPage.prototype.uninstallClicked = function (productSummary) {
        if (this.failIfOperationIsRunning()) {
            return;
        }
        var asInstalled = productSummary;
        var targetedProduct = asInstalled.name;
        var installPath = asInstalled.installationPath;
        var isQuietOrPassive = false;
        var options = {
            title: ResourceStrings_1.ResourceStrings.uninstallWarningTitle,
            message: [
                ResourceStrings_1.ResourceStrings.uninstallWarningMessage,
                "",
                targetedProduct,
                installPath,
                "",
                ResourceStrings_1.ResourceStrings.clickOKToContinueMessage
            ],
            allowCancel: true,
            isCancelDefault: true,
            errorName: errorNames.UNINSTALL_PROMPT_ERROR_NAME,
        };
        var operation = "uninstall";
        var telemetryContext = factory_1.appStore.createTelemetryContext(operation);
        telemetryContext.initiatedFromCommandLine = false;
        factory_1.errorStore.show(options)
            .then(function (response) {
            if (response.buttonType !== error_message_response_1.ButtonType.DEFAULT_SUBMIT) {
                return;
            }
            if (Product_1.isPreviewProduct(asInstalled)) {
                InstallerActions_1.deepCleanPreviewInstallations();
            }
            else {
                InstallerActions_1.uninstall(asInstalled, isQuietOrPassive, telemetryContext);
            }
        });
    };
    ProductsPage.prototype.progressBar1 = function (item) {
        if (this.isUninstall(item)) {
            return this.progressBar(item.product, progress_calculator_1.ProgressDisplayType.Uninstall, this._installProgressBars);
        }
        if (item.installingState === InstallingState_1.InstallingState.Cancelling) {
            return this.progressBar(item.product, progress_calculator_1.ProgressDisplayType.CancellingDownload, this._downloadProgressBars);
        }
        if (item.product.installState === Product_1.InstallState.Unknown) {
            return {
                progress: 1,
                message: ResourceStrings_1.ResourceStrings.finishing,
                type: progress_calculator_1.ProgressDisplayType.Install,
            };
        }
        return this.progressBar(item.product, progress_calculator_1.ProgressDisplayType.Download, this._downloadProgressBars);
    };
    ProductsPage.prototype.progressBar2 = function (item) {
        if (this.isUninstall(item)
            || item.product.installState === Product_1.InstallState.Unknown) {
            return null;
        }
        if (item.installingState === InstallingState_1.InstallingState.Cancelling) {
            return this.progressBar(item.product, progress_calculator_1.ProgressDisplayType.CancellingInstall, this._installProgressBars);
        }
        return this.progressBar(item.product, progress_calculator_1.ProgressDisplayType.Install, this._installProgressBars);
    };
    /**
     * Only prevent cancel on uninstall
     */
    ProductsPage.prototype.installSupportsCancel = function (item) {
        return item.installingState !== InstallingState_1.InstallingState.Uninstalling
            && item.product.installState !== Product_1.InstallState.Unknown;
    };
    ProductsPage.prototype.showCheckbox = function (item) {
        // Do not show the checkbox when quiet or passive.
        if (factory_1.appStore.isQuietOrPassive) {
            return false;
        }
        // Do not show the checkbox for products that cannot autolaunch
        if (!factory_1.appStore.canProductAutolaunch(item.product)) {
            return false;
        }
        if (factory_1.experimentsStore.isExperimentEnabled(experiments_1.ExperimentName.VSWLaunchChkOff) ||
            factory_1.experimentsStore.isExperimentEnabled(experiments_1.ExperimentName.VSWLaunchChkOn)) {
            return true;
        }
        return false;
    };
    Object.defineProperty(ProductsPage.prototype, "checkboxLabel", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.startAfterInstallation;
        },
        enumerable: true,
        configurable: true
    });
    ProductsPage.prototype.checkboxState = function (item) {
        if (!item || item.installingState !== InstallingState_1.InstallingState.Installing) {
            return checkbox_state_1.CheckboxState.None;
        }
        if (!this.showCheckbox(item)) {
            return checkbox_state_1.CheckboxState.None;
        }
        var productLaunchState = factory_1.appStore.productLaunchState(item.product);
        if (productLaunchState === product_launch_state_1.ProductLaunchState.LaunchAfterInstall) {
            return checkbox_state_1.CheckboxState.Checked;
        }
        if (productLaunchState === product_launch_state_1.ProductLaunchState.None) {
            return checkbox_state_1.CheckboxState.Unchecked;
        }
        return checkbox_state_1.CheckboxState.None;
    };
    ProductsPage.prototype.onCheckboxClickedCallback = function (product) {
        var _this = this;
        return function (ev) {
            var isChecked = _this.checkboxState(product) === checkbox_state_1.CheckboxState.Checked ? true : false;
            // Toggle the state by sending !isChecked
            factory_2.autolaunchActions.updateProductLaunchState(product.product, !isChecked);
        };
    };
    /* tslint:disable:max-line-length */
    ProductsPage.prototype.progressBar = function (item, type, progressMap) {
        var progressBar = progressMap.get(item);
        if (!progressBar) {
            progressBar = {
                progress: this.progressCalculator.getProgress(item.installationPath, type),
                message: this.progressCalculator.getProgressMessage(item.installationPath, type),
                type: type,
            };
            progressMap.set(item, progressBar);
        }
        else {
            // Update the progress value and message
            progressBar.progress = this.progressCalculator.getProgress(item.installationPath, type);
            progressBar.message = this.progressCalculator.getProgressMessage(item.installationPath, type);
            progressBar.type = type;
        }
        return progressBar;
    };
    /* tslint:enable:max-line-length */
    ProductsPage.prototype.isUninstall = function (item) {
        return item.installingState === InstallingState_1.InstallingState.Uninstalling;
    };
    Object.defineProperty(ProductsPage.prototype, "installedProductsSectionStyle", {
        /* Styles */
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginTop: "36px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "onlineContentMainDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 1 100%",
                overflow: "auto",
                /* Components should position relative to this element */
                position: "relative",
                webkitPaddingEnd: "4px",
                width: "100%",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "centeredStackedDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignItems: "center",
                display: "flex",
                flex: "0 1 100%",
                flexDirection: "column",
                justifyContent: "center",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "launchBannerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginBottom: "36px",
                // +4px to stay under scrollbar
                width: "calc(100% + 4px)",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "productListStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "block",
                marginBottom: "8px",
                webkitMarginStart: "58px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "productViewStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "block",
                flex: "0 0 100%",
                height: "150px",
                marginBottom: "16px",
                maxWidth: "calc(100% - 75px)",
                padding: "5px",
                webkitMarginStart: "12px",
                webkitMarginEnd: "28px",
            });
            // Transition to multi-column layout.
            if (window.outerWidth > 1280) {
                style.width = "380px";
                style.flex = "0 0 auto";
            }
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "informationPaneStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 1 100%",
                padding: "34px 30px 0px",
                overflow: "auto",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "informationPaneSectionStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                margin: "4px 0px 20px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "availableListHeaderStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                fontSize: "1.33rem",
                marginBottom: "20px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "installedListHeaderStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                fontSize: "1.33rem",
                marginBottom: "30px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "listSubheaderStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "1 0 auto",
                fontSize: ".75rem",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "channelHeaderLayoutStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginBottom: "10px",
                webkitMarginStart: "17px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "nonClientButtonStyle", {
        get: function () {
            var buttonSize = "18px";
            var style = css_styles_1.createStyleMap({
                flex: "1 0 auto",
                height: buttonSize,
                marginTop: "-1px",
                padding: "0px",
                width: buttonSize,
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "reverseColumnStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexDirection: "column-reverse",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "footerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignItems: "center",
                display: "flex",
                justifyContent: "flex-end",
                height: "27px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "appVersionStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                cursor: "text",
                fontSize: ".75rem",
                margin: "0px 17px",
                webkitUserSelect: "text",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "informationPaneDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexDirection: "column",
                flex: "0 0 320px",
                justifyContent: "space-between",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "showLaunchBanner", {
        get: function () {
            if (factory_1.appStore.isOperationInProgress) {
                return false;
            }
            if (!this.firstInstalledProduct) {
                return false;
            }
            return factory_1.appStore.isFirstInstallExperience;
        },
        enumerable: true,
        configurable: true
    });
    ProductsPage.prototype.hookEvents = function (hook) {
        var _this = this;
        var hookMethod = Utilities_1.getEventHookMethodForEventEmitter(factory_1.appStore, hook);
        hookMethod(factory_1.appStore.CHANGED_EVENT, this._handleReloadBind);
        hookMethod = Utilities_1.getEventHookMethodForEventEmitter(factory_1.errorStore, hook);
        hookMethod(factory_1.errorStore.CHANGED_EVENT, this._handleReloadBind);
        hookMethod = Utilities_1.getEventHookMethodForEventEmitter(factory_1.productConfigurationStore, hook);
        hookMethod(factory_1.productConfigurationStore.CHANGED_EVENT, this._handleReloadBind);
        // Listen to resize for responsive styling.
        var windowHookMethod = Utilities_1.getEventHookMethodForTarget(window, hook);
        windowHookMethod("resize", function () { return _this.update(); });
    };
    Object.defineProperty(ProductsPage.prototype, "installBlocked", {
        get: function () {
            return factory_1.appStore.hasPreviewInstallations || this.disableButtons;
        },
        enumerable: true,
        configurable: true
    });
    ProductsPage.prototype.handleCommandLineOperation = function () {
        var argv = factory_1.appStore.argv;
        if (argv.quiet && factory_1.appStore.updateIsRequired) {
            WindowActions_1.windowActions.quitApp(false /* success */, ResourceStrings_1.ResourceStrings.installerUpdateRequired /* errorMessage */);
        }
        // We want to wait until after we've loaded because we
        // need to know what products (installed or available) we
        // have before trying to perform command line operations on
        // them.
        if (factory_1.appStore.isLoading || factory_1.appStore.updateIsRequired) {
            return;
        }
        // if we don't have a command line operation to process, bail
        if (factory_1.appStore.commandLineOperationState !== command_line_operation_state_1.CommandLineOperationState.Pending) {
            return;
        }
        // Currently, do not try to do simultaneous operations.
        if (this.failIfOperationIsRunning()) {
            return;
        }
        // show the nickname field on the details page if we have at least one product or
        // or if --nickname was specified on the command line
        var showNickname = (factory_1.appStore.installedAndInstallingItems.length > 0) || !!argv.nickname;
        var productSummary = factory_1.appStore.productSummaryFromCommandLineArgs;
        var operation = argv.command;
        command_line_actions_1.handleCommandLineOperation(argv, factory_1.appStore.appLocale, productSummary, showNickname, factory_1.appStore.createTelemetryContext(operation));
    };
    /**
     * @returns {boolean} true if an error was shown to the user.
     */
    ProductsPage.prototype.failIfOperationIsRunning = function () {
        if (factory_1.appStore.isOperationInProgress) {
            factory_1.errorStore.showOperationIsRunningError();
            return true;
        }
        return false;
    };
    Object.defineProperty(ProductsPage.prototype, "hasPreviewInstallations", {
        get: function () {
            var hasPreviewInstallations = factory_1.appStore.hasPreviewInstallations;
            if (hasPreviewInstallations) {
                if (this._displayedPreviewDetectedDialog !== true) {
                    this._displayedPreviewDetectedDialog = true;
                    var options = {
                        title: ResourceStrings_1.ResourceStrings.uninstallPreviewTitle,
                        message: ResourceStrings_1.ResourceStrings.uninstallPreviewMessage,
                        okButtonText: ResourceStrings_1.ResourceStrings.uninstallPreview,
                        allowCancel: true,
                        errorName: errorNames.HAS_PREVIEW_PRODUCT_INSTALLED_ERROR_NAME,
                    };
                    factory_1.errorStore.show(options)
                        .then(function (response) {
                        if (response.buttonType === error_message_response_1.ButtonType.DEFAULT_SUBMIT) {
                            InstallerActions_1.deepCleanPreviewInstallations();
                        }
                    });
                }
            }
            return hasPreviewInstallations;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProductsPage.prototype, "isCommandLineProductLoading", {
        /**
         * Gets a {Boolean} indicating if a product is loading and we have command line operation.
         */
        get: function () {
            return !factory_1.productConfigurationStore.isProductLoaded && factory_1.appStore.hasActiveCommandLineOperation;
        },
        enumerable: true,
        configurable: true
    });
    ProductsPage._firstTimeShowing = true;
    ProductsPage = __decorate([
        template("\n<products-page>\n    <div if={this.isLoading}\n         style={this.centeredStackedDivStyle}>\n        <div style={this.centeredStackedDivStyle}>\n            <loading-view loadingtext={this.loadingScreenText} />\n        </div>\n    </div>\n\n    <div if={!this.isLoading}\n         style={this.onlineContentMainDivStyle}>\n\n        <div each={this.showLaunchBanner ? [1] : []}\n            style={this.launchBannerStyle}>\n            <launch-banner\n                product={this.parent.firstInstalledProduct}></launch-banner>\n        </div>\n\n        <!-- Installed products -->\n        <div if={!this.showLaunchBanner}\n            style={this.installedProductsSectionStyle}>\n            <list-view if={this.installedAndInstallingList.length > 0}\n                       style={this.productListStyle}\n                       items={this.installedAndInstallingList}\n                       header={this.installedHeader}\n                       headerstyle={this.installedListHeaderStyle}\n                       listrole=\"group\">\n                <partial-product if={this.parent.parent.isPartialInstall(item)}\n                                 style={this.parent.parent.productViewStyle}\n                                 product={item.product}\n                                 log={item.log}\n                                 restartclicked={this.parent.parent.restartClickedBind}\n                                 modifyclicked={this.parent.parent.modifyClickedBind}\n                                 removeclicked={this.parent.parent.uninstallClickedBind}\n                                 tabindex=\"0\"\n                                 aria-label={this.parent.parent.productAndVersionText(item.product)}\n                                 disablebuttons={this.parent.parent.disableButtons} />\n                <installed-product if={this.parent.parent.isCompleteInstall(item)}\n                                   style={this.parent.parent.productViewStyle}\n                                   product={item.product}\n                                   log={item.log}\n                                   canupdate={item.product.isUpdateAvailable}\n                                   modifyclicked={this.parent.parent.modifyClickedBind}\n                                   uninstallclicked={this.parent.parent.uninstallClickedBind}\n                                   updateclicked={this.parent.parent.updateClickedBind}\n                                   launchclicked={this.parent.parent.launchClickedBind}\n                                   repairclicked={this.parent.parent.repairClickedBind}\n                                   tabindex=\"0\"\n                                   aria-label={this.parent.parent.productAndVersionText(item.product)}\n                                   disablebuttons={this.parent.parent.disableButtons} />\n                <installing-product if={this.parent.parent.isInstallOperationInProgress(item)}\n                                    style={this.parent.parent.productViewStyle}\n                                    product={item}\n                                    cancelclicked={this.parent.parent.cancelClicked}\n                                    cancancel={this.parent.parent.installSupportsCancel(item)}\n                                    progressbar1={this.parent.parent.progressBar1(item)}\n                                    progressbar2={this.parent.parent.progressBar2(item)}\n                                    operation={item.installingState}\n                                    tabindex=\"0\"\n                                    aria-label={this.parent.parent.productAndVersionText(item.product)}\n                                    checkbox-state={this.parent.parent.checkboxState(item)}\n                                    checkbox-label={this.parent.parent.checkboxLabel}\n                                    on-checkbox-clicked={this.parent.parent.onCheckboxClickedCallback(item)} />\n            </list-view>\n        </div>\n\n        <div style={this.productListStyle}>\n            <!-- Available header -->\n            <div if={this.channels.length > 0}\n                id={this.availableHeaderDivId}\n                style={this.availableListHeaderStyle}\n                role=\"heading\">\n                {this.availableHeader}\n            </div>\n\n            <!-- Channels -->\n            <div class=\"products-page-channels-list\"\n                each={channel in this.channels}\n                role=\"group\"\n                aria-labelledby={this.availableHeaderDivId}\n                no-reorder>\n\n                <div style={this.reverseColumnStyle}>\n                    <!-- NOTE: We put the channel-header after the list of products and then put them in a flex-box with\n                        order reverse-column. This is because we want the header to appear before the products in the\n                        channel, but we want the tab ordering to be such that we tab to the products first, then the\n                        channel-header. -->\n                    <list-view items={channel.visibleProducts}\n                            listrole=\"group\">\n                        <available-product style={this.parent.parent.productViewStyle}\n                                        product={item}\n                                        installblocked={this.parent.parent.installBlocked}\n                                        installclicked={this.parent.parent.installClickedBind}\n                                        tabindex=\"0\"\n                                        aria-label={this.parent.parent.productAndVersionText(item)}\n                                        disablebuttons={this.parent.parent.disableButtons} />\n                    </list-view>\n                    <div if={this.parent.numberOfVisibleChannels > 1}\n                        style={this.parent.channelHeaderLayoutStyle}>\n                        <channel-header channel={channel} />\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <!-- Information pane section -->\n    <div style={this.informationPaneDivStyle}\n         class=\"information-pane\">\n        <list-view style={this.informationPaneStyle}\n                   items={this.informationPaneSections}>\n            <div style={this.parent.informationPaneSectionStyle}>\n                <information-pane-section header={item.header}\n                                          content={item.content} />\n            </div>\n        </list-view>\n        <div style={this.footerStyle}>\n            <div style={this.appVersionStyle}\n                title={this.branch + \"@\" + this.appVersion}>\n                {this.appVersion}\n            </div>\n        </div>\n    </div>\n\n</products-page>")
    ], ProductsPage);
    return ProductsPage;
}(Riot.Element));
exports.ProductsPage = ProductsPage;
//# sourceMappingURL=products-page.js.map