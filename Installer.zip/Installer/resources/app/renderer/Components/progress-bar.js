/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/riot-ts-missing-declares.d.ts" />
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var css_styles_1 = require("../css-styles");
var progress_calculator_1 = require("../progress-calculator");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var ProgressBar = (function (_super) {
    __extends(ProgressBar, _super);
    function ProgressBar() {
        _super.apply(this, arguments);
    }
    Object.defineProperty(ProgressBar.prototype, "progressText", {
        get: function () {
            if (!this.opts.details) {
                return "";
            }
            return ResourceStrings_1.ResourceStrings.asPercentage("" + Math.floor(this.progress));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "progress", {
        get: function () {
            if (!this.opts.details) {
                return 0;
            }
            return this.opts.details.progress * 100;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "ariaProgressText", {
        get: function () {
            if (!this.opts.details) {
                return this.progressText;
            }
            switch (this.opts.details.type) {
                case progress_calculator_1.ProgressDisplayType.Install:
                case progress_calculator_1.ProgressDisplayType.Uninstall:
                case progress_calculator_1.ProgressDisplayType.CancellingInstall:
                    return ResourceStrings_1.ResourceStrings.appliedProgressLabel(this.progress);
                case progress_calculator_1.ProgressDisplayType.Download:
                case progress_calculator_1.ProgressDisplayType.CancellingDownload:
                    return ResourceStrings_1.ResourceStrings.acquiredProgressLabel(this.progress);
                default:
                    console.log("Unrecognized ProgressDisplayType: " + this.opts.details.type);
                    return this.progressText;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "message", {
        get: function () {
            if (this.opts.details && this.opts.details.message) {
                return this.opts.details.message;
            }
            // We still want this div to take up space, so we'll put a period
            // and make it hidden
            return ".";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "progressLayoutStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginTop: "6px",
                display: "flex",
                flexDirection: "column"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "messageStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 0 auto",
                fontSize: ".75rem",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
            });
            if (!this.opts.details || !this.opts.details.message) {
                style.visibility = "hidden";
            }
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "innerProgressLayoutStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                justifyContent: "flex-start",
                alignItems: "center"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "progressTextStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 0 40px",
                fontSize: ".75rem",
                webkitMarginEnd: "6px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProgressBar.prototype, "progressBarStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 0 280px",
                height: "8px",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    ProgressBar = __decorate([
        template("\n<progress-bar>\n    <div style={this.progressLayoutStyle}>\n        <div style={this.messageStyle}>\n            {this.message}\n        </div>\n        <div style={this.innerProgressLayoutStyle}>\n            <div id=\"progress-div\"\n                 style={this.progressTextStyle}\n                 aria-label={this.ariaProgressText}\n                 tabindex=\"0\">\n                    {this.progressText}\n            </div>\n            <progress style={this.progressBarStyle}\n                      value={this.progress}\n                      max=\"100\" />\n        </div>\n    </div>\n</progress-bar>")
    ], ProgressBar);
    return ProgressBar;
}(Riot.Element));
//# sourceMappingURL=progress-bar.js.map