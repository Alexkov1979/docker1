/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var apply_mixins_1 = require("../mixins/apply-mixins");
var change_emitter_1 = require("../mixins/change-emitter");
var array_utils_1 = require("../../lib/array-utils");
var css_styles_1 = require("../css-styles");
var Product_1 = require("../../lib/Installer/Product");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
require("./workload-card");
var WorkloadsPage = (function (_super) {
    __extends(WorkloadsPage, _super);
    function WorkloadsPage() {
        _super.apply(this, arguments);
        this._previousSelectedWorkloads = [];
    }
    WorkloadsPage.prototype.updated = function () {
        // Decide whether or not to emit a changed event.
        var selectedWorkloads = this.selectedWorkloads;
        if (!array_utils_1.containsSameElements(this._previousSelectedWorkloads, selectedWorkloads)) {
            this.emitChange(this.root);
            // store a shallow copy of the array
            this._previousSelectedWorkloads = selectedWorkloads.slice();
        }
    };
    WorkloadsPage.prototype.updating = function () {
        var _this = this;
        if (this._product !== this.opts.product) {
            this._product = this.opts.product;
            var categoryMap_1 = new Map();
            this.workloads.forEach(function (workload) {
                var category = workload.category ? workload.category : ResourceStrings_1.ResourceStrings.uncategorized;
                if (!categoryMap_1.has(category)) {
                    categoryMap_1.set(category, []);
                }
                categoryMap_1.get(category).push(workload);
            });
            this._categories = [];
            Array.from(categoryMap_1.keys()).forEach(function (categoryName) {
                _this._categories.push({
                    name: categoryName,
                    workloads: categoryMap_1.get(categoryName)
                });
            });
        }
    };
    Object.defineProperty(WorkloadsPage.prototype, "categories", {
        get: function () {
            return this._categories;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "channelId", {
        get: function () {
            return this.product.channelId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "isInstalledProduct", {
        get: function () {
            var asInstalledProduct = this.product;
            return asInstalledProduct && (asInstalledProduct.installState === Product_1.InstallState.Installed);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "product", {
        get: function () {
            return this._product;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "productId", {
        get: function () {
            return this.product.id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "selectedWorkloads", {
        get: function () {
            return this.opts.selectedworkloads || [];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "workloads", {
        get: function () {
            if (!this.product) {
                return [];
            }
            return this.product.workloads.filter(function (workload) { return !workload.required; });
        },
        enumerable: true,
        configurable: true
    });
    WorkloadsPage.prototype.categoryTitleId = function (index) {
        return "category-" + index + "-title";
    };
    WorkloadsPage.prototype.categoryString = function (workloadCategory) {
        var workloads = workloadCategory.workloads;
        return workloadCategory.name + (" (" + workloads.length + ")");
    };
    WorkloadsPage.prototype.isWorkloadChecked = function (workload) {
        return this.selectedWorkloads.some(function (w) { return w.id === workload.id; });
    };
    Object.defineProperty(WorkloadsPage.prototype, "categoryHeaderStyle", {
        /* Styles */
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "1 0 auto",
                fontFamily: "Segoe UI SemiBold",
                fontSize: ".75rem",
                margin: "0px 6px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "formatDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                width: "calc(100% - 6px)"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WorkloadsPage.prototype, "workloadsDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignContent: "flex-start",
                display: "flex",
                flexGrow: "1",
                flexWrap: "wrap",
                marginBottom: "15px",
                outline: "none",
                paddingRight: "6px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    WorkloadsPage.prototype.workloadCardStyle = function (workload) {
        var style = css_styles_1.createStyleMap({
            display: "block",
            height: "84px",
            margin: "6px",
            position: "relative",
            width: "405px"
        });
        if (workload && workload.required) {
            style.display = "none";
        }
        return style.toString();
    };
    WorkloadsPage = __decorate([
        template("\n<workloads-page>\n    <div style={this.workloadsDivStyle}\n         each={category, i in this.categories}\n         role=\"group\"\n         aria-labelledby={this.categoryTitleId(i)}>\n        <div style={this.formatDivStyle}>\n            <div class=\"workload-header\"\n                 style={this.categoryHeaderStyle}\n                 role=\"heading\"\n                 id={this.categoryTitleId(i)}>\n                {this.categoryString(category)}\n            </div>\n        </div>\n        <workload-card each={item in category.workloads}\n                       style={this.parent.workloadCardStyle(item)}\n                       workload={item}\n                       channelid={this.parent.channelId}\n                       productid={this.parent.productId}\n                       isinstalledproduct={this.parent.isInstalledProduct}\n                       ischecked={this.parent.isWorkloadChecked(item)} />\n    </div>\n</workloads-page>")
    ], WorkloadsPage);
    return WorkloadsPage;
}(Riot.Element));
apply_mixins_1.applyMixins(WorkloadsPage, [change_emitter_1.ChangeEmitter]);
//# sourceMappingURL=workloads-page.js.map