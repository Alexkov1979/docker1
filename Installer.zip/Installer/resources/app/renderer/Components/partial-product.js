/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/riot-ts-missing-declares.d.ts" />
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var css_styles_1 = require("../css-styles");
var factory_1 = require("../Actions/factory");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
require("./product-status");
require("./product-view");
var PartialProduct = (function (_super) {
    __extends(PartialProduct, _super);
    function PartialProduct() {
        _super.apply(this, arguments);
        this.openProblemsBind = this.openProblemsDialog.bind(this);
    }
    Object.defineProperty(PartialProduct.prototype, "errorString", {
        get: function () {
            if (this.hasPendingRestart) {
                return ResourceStrings_1.ResourceStrings.rebootRequiredMessage;
            }
            else {
                return ResourceStrings_1.ResourceStrings.partialProductErrorText;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "product", {
        get: function () {
            return this.opts.product;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "disableButtons", {
        get: function () {
            return this.opts.disablebuttons;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "restartButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: ResourceStrings_1.ResourceStrings.restart,
                onclick: function () { _this.restartClicked(); },
                disabled: this.disableButtons,
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "modifyButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: ResourceStrings_1.ResourceStrings.modify,
                onclick: function () { _this.modifyClicked(); },
                disabled: this.disableButtons,
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "removeButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: ResourceStrings_1.ResourceStrings.remove,
                onclick: function () { _this.removeClicked(); },
                disabled: this.disableButtons,
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "actionButtonOptions", {
        get: function () {
            var options = [];
            if (this.hasPendingRestart) {
                options.push(this.restartButtonOptions);
            }
            else {
                options.push(this.modifyButtonOptions);
                options.push(this.removeButtonOptions);
            }
            return options;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "buttonOptions", {
        get: function () {
            var options = {
                actionbuttons: this.actionButtonOptions,
                actionmenubuttons: null,
            };
            return options;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "hasPendingRestart", {
        get: function () {
            if (!this.product) {
                return false;
            }
            return this.product.hasPendingReboot;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "viewProblemsText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.viewProblems;
        },
        enumerable: true,
        configurable: true
    });
    PartialProduct.prototype.openProblemsDialog = function (event) {
        factory_1.viewProblemsActions.viewProblems(this.product, this.opts.log);
    };
    PartialProduct.prototype.restartClicked = function () {
        this.opts.restartclicked(this.product);
    };
    PartialProduct.prototype.modifyClicked = function () {
        this.opts.modifyclicked(this.product);
    };
    PartialProduct.prototype.removeClicked = function () {
        this.opts.removeclicked(this.product);
    };
    Object.defineProperty(PartialProduct.prototype, "linksDivStyle", {
        /* Styles */
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignItems: "flex-end",
                display: "flex",
                margin: "1px 0px 4px",
                marginTop: "2px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PartialProduct.prototype, "singleLineStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginRight: "5px",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    PartialProduct = __decorate([
        template("\n<partial-product>\n    <product-view buttonoptions={this.buttonOptions}\n                  product={this.product}>\n\n        <product-status iscritical={!this.parent.hasPendingRestart}\n                        errorstring={this.parent.errorString} />\n\n        <div style={this.parent.linksDivStyle}>\n            <span style={this.parent.singleLineStyle}>\n                <a onclick={this.parent.openProblemsBind}\n                   title={this.parent.viewProblemsText}\n                   onkeypress={keyPressToClickHelper}\n                   tabindex=\"0\">\n                    {this.parent.viewProblemsText}\n                </a>\n            </span>\n        </div>\n\n    </product-view>\n</partial-product>\n")
    ], PartialProduct);
    return PartialProduct;
}(Riot.Element));
//# sourceMappingURL=partial-product.js.map