/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/riot-ts-missing-declares.d.ts" />
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var css_styles_1 = require("../css-styles");
require("./product-button-layout");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var PenginRebootInstallOpts = (function () {
    function PenginRebootInstallOpts() {
    }
    return PenginRebootInstallOpts;
}());
exports.PenginRebootInstallOpts = PenginRebootInstallOpts;
var PendingRebootInstall = (function (_super) {
    __extends(PendingRebootInstall, _super);
    function PendingRebootInstall() {
        _super.apply(this, arguments);
        this.resourceStrings = ResourceStrings_1.ResourceStrings;
    }
    Object.defineProperty(PendingRebootInstall.prototype, "title", {
        get: function () {
            return this.opts.product.name;
        },
        enumerable: true,
        configurable: true
    });
    PendingRebootInstall.prototype.restartClicked = function () {
        this.opts.restartclicked(this.opts.product);
    };
    Object.defineProperty(PendingRebootInstall.prototype, "restartButtonOptions", {
        get: function () {
            var _this = this;
            return {
                text: this.resourceStrings.restart,
                onclick: function () { _this.restartClicked(); }
            };
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "actionButtonOptions", {
        get: function () {
            return [this.restartButtonOptions];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "dropdownOptions", {
        get: function () {
            return [];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "parentStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                height: "55px",
                justifyContent: "space-between"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "spacerDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                width: "20px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "textDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flex: "0 1 100%",
                height: "55px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "titleStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                marginTop: "6px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "subtitleStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                fontSize: ".75rem"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingRebootInstall.prototype, "productButtonLayoutStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                webkitMarginStart: "6px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    PendingRebootInstall = __decorate([
        template("\n<pending-reboot-install>\n    <div style={this.parentStyle}>\n        <div style={this.textDivStyle}>\n            <div style={this.spacerDivStyle}></div>\n            <div style={this.titleStyle}>\n                <div>{this.title}</div>\n                <div style={this.subtitleStyle}>\n                    {this.resourceStrings.rebootRequiredMessage}\n                </div>\n            </div>\n        </div>\n        <product-button-layout style={this.productButtonLayoutStyle}\n                               actionbuttons={this.actionButtonOptions}\n                               actionmenubuttons={this.dropdownOptions}\n                               ariatitleprefix={this.title} />\n    </div>\n</pending-reboot-install>\n")
    ], PendingRebootInstall);
    return PendingRebootInstall;
}(Riot.Element));
exports.PendingRebootInstall = PendingRebootInstall;
//# sourceMappingURL=pending-reboot-install.js.map