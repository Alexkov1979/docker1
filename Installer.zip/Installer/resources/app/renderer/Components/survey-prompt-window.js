/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
require("./error-dialog");
var factory_1 = require("../stores/factory");
var error_message_response_1 = require("../interfaces/error-message-response");
var css_styles_1 = require("../css-styles");
var KeyCodes_1 = require("../KeyCodes");
var Utilities_1 = require("../Utilities");
var open_external_1 = require("../../lib/open-external");
var querystring_1 = require("querystring");
var electron_1 = require("electron");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var Utilities_2 = require("../Utilities");
exports.PROMPT_FOR_SURVEY_KEY_NAME = "AppStore.promptForSurvey";
var SurveyPromptWindow = (function (_super) {
    __extends(SurveyPromptWindow, _super);
    function SurveyPromptWindow() {
        _super.apply(this, arguments);
        this._onErrorStoreUpdateBind = this.onErrorStoreUpdate.bind(this);
    }
    SurveyPromptWindow.prototype.mounted = function () {
        this.hookEvents(true);
        window.addEventListener("keyup", function (ev) {
            if (ev.keyCode === KeyCodes_1.keyCodes.F12) {
                // if we're in debug mode, open dev tools when F12 is pressed,
                // if we're not in debug mode, open dev tools when Ctrl+Alt+Shift+F12 is pressed
                if ((ev.ctrlKey && ev.altKey && ev.shiftKey)) {
                    Utilities_1.openDevTools();
                }
            }
        });
        var queryStringParts = querystring_1.parse(window.location.search.substr(1));
        this.promptForSurvey(queryStringParts.surveyUrl, queryStringParts.sessionId)
            .finally(function () {
            var window = electron_1.remote.getCurrentWindow();
            window.close();
        });
    };
    SurveyPromptWindow.prototype.unmounted = function () {
        this.hookEvents(false);
    };
    Object.defineProperty(SurveyPromptWindow.prototype, "acceptErrorCallback", {
        get: function () {
            return factory_1.errorStore.dismiss;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SurveyPromptWindow.prototype, "appVersion", {
        get: function () {
            return factory_1.appStore.getAppVersion();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SurveyPromptWindow.prototype, "branch", {
        get: function () {
            return factory_1.appStore.branch;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SurveyPromptWindow.prototype, "errorMessage", {
        get: function () {
            return factory_1.errorStore.currentMessageData;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SurveyPromptWindow.prototype, "isErrorVisible", {
        get: function () {
            return factory_1.errorStore.isErrorVisible;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SurveyPromptWindow.prototype, "accessibilityLogStrings", {
        get: function () {
            return factory_1.appStore.accessibilityLogStrings;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SurveyPromptWindow.prototype, "frameStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                borderStyle: "solid",
                borderWidth: "1px",
                boxShadow: "2px 2px 1px rgba(0, 0, 0, .2)",
                height: "calc(100% - 2px)",
                width: "calc(100% - 2px)"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    SurveyPromptWindow.prototype.onErrorStoreUpdate = function () {
        this.update();
    };
    SurveyPromptWindow.prototype.onAppStoreUpdate = function () {
        this.update();
    };
    SurveyPromptWindow.prototype.onProductConfigurationStoreUpdate = function () {
        this.update();
    };
    /**
     * Hooks or unhooks events for this component
     */
    SurveyPromptWindow.prototype.hookEvents = function (hook) {
        // (un)hook events on the window
        var hookMethod = Utilities_2.getEventHookMethodForTarget(window, hook);
        // (un)hook events on the error store
        hookMethod = Utilities_2.getEventHookMethodForEventEmitter(factory_1.errorStore, hook);
        hookMethod(factory_1.errorStore.CHANGED_EVENT, this._onErrorStoreUpdateBind);
    };
    /**
     * Prompts the user to take a survey
     *
     * @param {string} surveyUrl - the URL for the survey
     * @param {sessionId} sessionId - the telemetry session Id
     * @returns {Promise<boolean>} - true if the user chose to take the survey, false if he chose not to take the survey
     */
    SurveyPromptWindow.prototype.promptForSurvey = function (surveyUrl, sessionId) {
        var _this = this;
        // if user already clicked "don't show me again", bail out
        if (!this.canPromptForSurvey) {
            return Promise.resolve(false);
        }
        var surveyUrlWithSessionId = surveyUrl + "&sessionid=" + sessionId;
        var errorOptions = {
            title: ResourceStrings_1.ResourceStrings.surveyPromptTitle,
            message: ResourceStrings_1.ResourceStrings.surveyPrompt,
            okButtonText: ResourceStrings_1.ResourceStrings.yes,
            cancelButtonText: ResourceStrings_1.ResourceStrings.no,
            allowCancel: true,
            allowOptOut: true,
            hideSupportLink: true,
        };
        return factory_1.errorStore.show(errorOptions)
            .then(function (response) {
            open_external_1.openExternal(surveyUrlWithSessionId);
            _this.canPromptForSurvey = !response.isOptedOut;
            return response.buttonType === error_message_response_1.ButtonType.DEFAULT_SUBMIT;
        });
    };
    Object.defineProperty(SurveyPromptWindow.prototype, "canPromptForSurvey", {
        get: function () {
            var json = window.localStorage.getItem(exports.PROMPT_FOR_SURVEY_KEY_NAME);
            if (!json) {
                return true;
            }
            var settings = JSON.parse(json);
            return !settings.optedOut;
        },
        set: function (value) {
            var settings = { optedOut: !value };
            var json = JSON.stringify(settings);
            window.localStorage.setItem(exports.PROMPT_FOR_SURVEY_KEY_NAME, json);
        },
        enumerable: true,
        configurable: true
    });
    SurveyPromptWindow = __decorate([
        template("\n<survey-prompt-window>\n    <div class=\"survey-prompt-window-frame\"\n         style={this.frameStyle}>\n        <error-dialog if={this.isErrorVisible}\n                      error-message={this.errorMessage}\n                      onsubmit={this.acceptErrorCallback}\n                      fillparent={true} />\n    </div>\n</survey-prompt-window>")
    ], SurveyPromptWindow);
    return SurveyPromptWindow;
}(Riot.Element));
exports.SurveyPromptWindow = SurveyPromptWindow;
riot.mount("*");
//# sourceMappingURL=survey-prompt-window.js.map