/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../renderer/bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var factory_1 = require("../stores/factory");
var css_styles_1 = require("../css-styles");
var Utilities_1 = require("../Utilities");
var error_store_1 = require("../stores/error-store");
var node_list_iterator_1 = require("../node-list-iterator");
var InstallerActions_1 = require("../Actions/InstallerActions");
var open_external_1 = require("../../lib/open-external");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var factory_2 = require("../Actions/factory");
require("./x-glyph");
var ProblemsDialog = (function (_super) {
    __extends(ProblemsDialog, _super);
    function ProblemsDialog() {
        _super.apply(this, arguments);
        this.troubleshootingTipsClickedBind = this.troubleshootingTipsClicked.bind(this);
        this.openErrorLogBind = this.openErrorLog.bind(this);
        this.openFeedbackToolBind = this.openFeedbackTool.bind(this);
        this._resettingFocus = false;
        this._onKeyDownBind = this.onKeyDown.bind(this);
        this._onKeyUpBind = this.onKeyUp.bind(this);
    }
    ProblemsDialog.prototype.mounted = function () {
        this.hookEvents(true);
    };
    ProblemsDialog.prototype.unmounted = function () {
        this.hookEvents(false);
    };
    ProblemsDialog.prototype.updated = function () {
        if (!this.root.contains(document.activeElement)) {
            this.resetFocus(false);
        }
    };
    ProblemsDialog.prototype.close = function () {
        this.root.dispatchEvent(new CustomEvent("close"));
    };
    Object.defineProperty(ProblemsDialog.prototype, "canShowLog", {
        get: function () {
            return !!factory_1.productConfigurationStore.viewProblemsActiveLog;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "closeButtonText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.closeButtonTitle;
        },
        enumerable: true,
        configurable: true
    });
    ProblemsDialog.prototype.failedPackageActionWithId = function (action, id) {
        return ResourceStrings_1.ResourceStrings.failedPackageActionWithId(action.toLocaleLowerCase(), id);
    };
    ProblemsDialog.prototype.actionText = function (action) {
        return ResourceStrings_1.ResourceStrings.failedPackageAction(action.toLocaleLowerCase());
    };
    Object.defineProperty(ProblemsDialog.prototype, "topfailedPackages", {
        get: function () {
            return factory_1.productConfigurationStore.topFailedPackages;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "hasFailedPackages", {
        get: function () {
            return this.topfailedPackages.length !== 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "headerText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.somethingWentWrong;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "subHeaderText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.selectProblem;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "troubleshootingTipsText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.moreTroubleshootingTips;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "openLogText", {
        get: function () {
            if (this.hasFailedPackages) {
                return ResourceStrings_1.ResourceStrings.viewLog;
            }
            return ResourceStrings_1.ResourceStrings.openLog;
        },
        enumerable: true,
        configurable: true
    });
    ProblemsDialog.prototype.hookEvents = function (hook) {
        var hookMethod = Utilities_1.getEventHookMethodForTarget(this.root, hook);
        hookMethod("keydown", this._onKeyDownBind);
        hookMethod("keyup", this._onKeyUpBind);
    };
    ProblemsDialog.prototype.onKeyDown = function (ev) {
        var button;
        switch (ev.key) {
            case "Shift":
                this._shiftPressed = true;
                break;
            case "Tab":
                this.update();
                break;
            case "Escape":
                // find the "type=reset" button; if found, click it
                button = this.getButtonOfType("reset");
                if (button) {
                    button.click();
                }
                break;
        }
    };
    ProblemsDialog.prototype.onKeyUp = function (ev) {
        if (ev.key === "Shift") {
            this._shiftPressed = false;
        }
    };
    ProblemsDialog.prototype.getButtonOfType = function (type) {
        return this.root.querySelector("button[type=" + type + "]");
    };
    ProblemsDialog.prototype.resetFocus = function (fromEnd) {
        // Prevent re-entry
        if (this._resettingFocus) {
            return;
        }
        try {
            this._resettingFocus = true;
            // walk the children testing focus. Go in reverse if fromEnd is true
            var children = this.root.querySelectorAll("*");
            var list = new node_list_iterator_1.NodeListIterator(children, fromEnd);
            var current = list.begin();
            while (current) {
                current.focus();
                // Don't allow focus on elements with a negative tabindex since they are not in the taborder
                if (current === document.activeElement && current.tabIndex >= 0) {
                    break;
                }
                current = list.next();
            }
        }
        finally {
            this._resettingFocus = false;
        }
    };
    ProblemsDialog.prototype.troubleshootingTipsClicked = function (ev) {
        open_external_1.openExternal(error_store_1.TROUBLESHOOTING_KB_FWLINK);
    };
    ProblemsDialog.prototype.openFeedbackTool = function (event) {
        var errors = event.item.failedPackage;
        var channels = factory_1.appStore.allChannels;
        factory_2.viewProblemsActions.openFeedbackClient(errors, channels, errors.signature);
    };
    ProblemsDialog.prototype.openErrorLog = function (event) {
        InstallerActions_1.openLog(factory_1.productConfigurationStore.viewProblemsActiveLog);
    };
    Object.defineProperty(ProblemsDialog.prototype, "buttonStyle", {
        /* Styles */
        get: function () {
            var buttonSize = "16px";
            var style = css_styles_1.createStyleMap({
                flex: "0 0 auto",
                height: buttonSize,
                lineHeight: "8px",
                padding: "0px",
                width: buttonSize,
                position: "absolute",
                top: "8px",
                right: "8px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "closeButtonStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 0 0",
                minWidth: "80px",
                webkitMarginStart: "8px",
                position: "absolute",
                right: "20px",
                bottom: "20px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "footerDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexWrap: "wrap",
                justifyContent: "flex-end",
                paddingTop: "45px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "fullSizeStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexDirection: "column",
                width: "100%",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "linksStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexDirection: "row",
                width: "100%",
                justifyContent: "space-between",
                paddingBottom: "30px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "linksStyleManager", {
        get: function () {
            if (this.hasFailedPackages) {
                return this.linksStyle;
            }
            return this.fullSizeStyle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "problemsHeaderStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                margin: "40px 40px 30px 40px",
                fontSize: "28px",
                lineHeight: "33px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "pathStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                fill: "inherit"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "problemsDialogContentStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                borderStyle: "solid",
                borderWidth: "1px",
                display: "flex",
                position: "relative",
                minHeight: "239px",
                minWidth: "444px",
                maxHeight: "100%",
                maxWidth: "100%",
                flexWrap: "wrap",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "problemsDialogStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignItems: "center",
                display: "flex",
                height: "100%",
                justifyContent: "center",
                left: "0px",
                outline: "none",
                position: "absolute",
                top: "0",
                width: "100%",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "subHeaderStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                margin: "0px 40px 20px 40px",
                fontSize: "22px",
                lineHeight: "28px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "troubleshootingTipsStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                margin: "0px 40px 0px 40px",
                fontSize: "14px",
                height: "20px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "listItemStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                padding: "10px 20px",
                fontSize: "14px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "listStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flexGrow: "1",
                height: "100%",
                listStyle: "none",
                padding: "10px 0px 10px 0px",
                borderStyle: "solid",
                borderWidth: "1px",
                margin: "0px 40px 30px 40px",
                minWidth: "346px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "logStyleManager", {
        get: function () {
            if (this.hasFailedPackages) {
                return this.viewLogStyle;
            }
            return this.openLogStyle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "viewLogStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                margin: "0px 40px 0px 40px",
                fontSize: "14px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProblemsDialog.prototype, "openLogStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                margin: "0px 40px 30px 40px",
                fontSize: "22px",
                lineHeight: "28px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    ProblemsDialog = __decorate([
        template("\n<problems-dialog>\n   <div class=\"problems-dialog\"\n         style={this.problemsDialogStyle}>\n        <div class=\"problems-dialog-content\"\n             style={this.problemsDialogContentStyle}>\n\n            <div style={this.fullSizeStyle}>\n                <div style={this.problemsHeaderStyle}\n                     aria-label={this.headerText}\n                     tabindex=\"0\">\n                    {this.headerText}\n                </div>\n\n                <div if={this.hasFailedPackages}>\n                    <div style={this.subHeaderStyle}\n                         aria-label={this.subHeaderText}\n                         tabindex=\"0\">\n                        {this.subHeaderText}\n                     </div>\n\n                    <ul class=\"failed-packages-list\"\n                         style={this.listStyle}>\n                         <virtual each={failedPackage in this.topfailedPackages}>\n                            <li style={this.listItemStyle}\n                                title={this.failedPackageActionWithId(failedPackage.action, failedPackage.id)}\n                                aria-label={this.failedPackageActionWithId(failedPackage.action, failedPackage.id)}\n                                tabindex=\"0\">\n                                {this.actionText(failedPackage.action)}\n                                <a onClick={this.openFeedbackToolBind}\n                                   onkeypress={keyPressToClickHelper}\n                                   title={failedPackage.id}\n                                   aria-label={failedPackage.id}\n                                   tabindex=\"0\">\n                                    {failedPackage.id}\n                                </a>\n                             </li>\n                         </virtual>\n                     </ul>\n                </div>\n\n                <div style={this.linksStyleManager}>\n                    <a if={this.canShowLog}\n                        onClick={this.openErrorLogBind}\n                        onkeypress={keyPressToClickHelper}\n                        title={this.openLogText}\n                        style={this.logStyleManager}\n                        aria-label={this.openLogText}\n                        tabindex=\"0\">\n                        {this.openLogText}\n                    </a>\n\n                    <a href=\"#\"\n                        title={this.troubleshootingTipsText}\n                        style={this.troubleshootingTipsStyle}\n                        onClick={this.troubleshootingTipsClickedBind}\n                        onkeypress={keyPressToClickHelper}>\n                        {this.troubleshootingTipsText}\n                    </a>\n                </div>\n                <div id=\"footerDiv\"\n                     style={this.footerDivStyle}>\n                    <button class=\"close-button\"\n                            aria-label={this.closeButtonText}\n                            type=\"reset\"\n                            style={this.closeButtonStyle}\n                            onclick={close}\n                            title={this.closeButtonText}>\n                            {this.closeButtonText}\n                    </button>\n                </div>\n            </div>\n            <button class=\"close-dialog-glyph-button\"\n                aria-label={this.closeButtonText}\n                style={this.buttonStyle}\n                onClick={close}\n                type=\"reset\"\n                title={this.closeButtonText}>\n                <x-glyph></x-glyph>\n            </button>\n        </div>\n    </div>\n</problems-dialog>")
    ], ProblemsDialog);
    return ProblemsDialog;
}(Riot.Element));
//# sourceMappingURL=problems-dialog.js.map