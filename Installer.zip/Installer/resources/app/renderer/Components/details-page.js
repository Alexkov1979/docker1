/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../renderer/bower_components/riot-ts/riot-ts.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var factory_1 = require("../stores/factory");
var command_line_actions_1 = require("../Actions/command-line-actions");
var Product_1 = require("../../lib/Installer/Product");
var nickname_utilities_1 = require("../../lib/nickname-utilities");
var css_styles_1 = require("../css-styles");
var InstallerActions_1 = require("../Actions/InstallerActions");
var Utilities_1 = require("../Utilities");
var locale_handler_1 = require("../../lib/locale-handler");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var router_1 = require("./router");
var Tab_1 = require("../../lib/Tab");
var WindowActions_1 = require("../Actions/WindowActions");
var DetailsPageActions_1 = require("../Actions/DetailsPageActions");
require("./directory-picker");
require("./individual-components-page");
require("./install-size-breakdown");
require("./language-packs-page");
require("./license-terms-text");
require("./nickname-picker");
require("./product-install-summary");
require("./tab-control");
require("./workloads-page");
/* istanbul ignore next */
var DetailsPage = (function (_super) {
    __extends(DetailsPage, _super);
    function DetailsPage() {
        _super.call(this);
        this._tabs = new Tab_1.TabCollection();
        this._currentTab = null;
        this._tabSwitchedBind = this.tabSwitched.bind(this);
        this._handleReloadBind = this.handleReload.bind(this);
        this._handleErrorBind = this.handleError.bind(this);
        this._handleProductStoreChangeBind = this.handleProductStoreChange.bind(this);
        this._UILoaded = false;
        this._onChangeBind = this.onChange.bind(this);
        this._originalSelectedPackageIdsCaptured = false;
        this._originalSelectedComponentIds = [];
        this._originalSelectedWorkloadIds = [];
        this._selectedComponents = [];
        this._selectedWorkloads = [];
        this._installModifyStarted = false;
        this._existingNicknames = [];
        this._hasInsufficientDiskSpaceShown = false;
    }
    DetailsPage.prototype.mounted = function () {
        this.hookEvents(true);
        this.checkInstallParameters();
    };
    DetailsPage.prototype.updated = function () {
        // If the scrollbar is not present, set the border to be 2px to divide the summary pane from content
        var tabpanel = document.getElementById(this.tabPanelId);
        if (tabpanel) {
            if (tabpanel.scrollHeight === tabpanel.clientHeight) {
                tabpanel.style.borderRightWidth = "2px";
            }
            else {
                tabpanel.style.borderRightWidth = "0px";
            }
        }
    };
    DetailsPage.prototype.unmounted = function () {
        this.hookEvents(false);
    };
    DetailsPage.prototype.updating = function () {
        if (!this._UILoaded && this.selectedProduct) {
            this._UILoaded = true;
            if (this.selectedProduct.workloads.length > 1) {
                this._tabs.add(new Tab_1.Tab(ResourceStrings_1.ResourceStrings.workloadsHeader, this.workloadsTabId));
                this._currentTab = this.tabs.get(this.workloadsTabId);
            }
            if (Utilities_1.getDisplayedComponents(this.selectedProduct.allComponents).length > 0) {
                this._tabs.add(new Tab_1.Tab(ResourceStrings_1.ResourceStrings.individualComponentsHeader, this.componentsTabId));
                if (!this._currentTab) {
                    this._currentTab = this.tabs.get(this.componentsTabId);
                }
            }
            if (this.selectedProduct.availableLanguages.length > 1) {
                this._tabs.add(new Tab_1.Tab(ResourceStrings_1.ResourceStrings.languagePacksHeader, this.langPacksTabId));
                if (!this._currentTab) {
                    this._currentTab = this.tabs.get(this.langPacksTabId);
                }
            }
            // initialize the nickname only after we have a selected product
            this.initializeNickname();
        }
    };
    DetailsPage.prototype.handleProductStoreChange = function () {
        if (this.isReady) {
            this.captureOriginallySelectedPackageIds();
            this._selectedWorkloads = factory_1.productConfigurationStore.getSelectedWorkloadsOrdered();
            var selectedComponents = factory_1.productConfigurationStore.getSelectedComponents();
            this._selectedComponents = Array.from(selectedComponents.values());
            if (!this._installModifyStarted && !factory_1.errorStore.isErrorVisible && !this.isEvaluatingParameters) {
                // if we got --passive or --quiet on the command line, immediately begin the install/modify
                if (factory_1.appStore.hasActiveCommandLineOperation && (factory_1.appStore.argv.passive || factory_1.appStore.argv.quiet)) {
                    if (this.canInstall) {
                        this.doInstallModify();
                    }
                    else {
                        var success = false;
                        WindowActions_1.windowActions.closeWindow(success, this.errorMessage);
                    }
                }
            }
        }
        var evaluation = factory_1.productConfigurationStore.evaluation;
        // If the warning has not been shown before, send the shown telemetry.
        if (evaluation &&
            evaluation.systemDriveEvaluation &&
            !evaluation.systemDriveEvaluation.hasSufficientDiskSpace &&
            !this._hasInsufficientDiskSpaceShown) {
            this._hasInsufficientDiskSpaceShown = true;
            DetailsPageActions_1.sendDiskSizeWarningShown();
        }
        this.update();
    };
    DetailsPage.prototype.nicknameChanged = function (ev) {
        this._nickname = ev.detail.nickname;
        this.validateNickname(this._nickname);
    };
    DetailsPage.prototype.directoryChanged = function (ev) {
        // If the directory has changed since the details page was opened,
        // and if another instance of VS is running and blocking the install,
        // we will get a change event from the directory picker when the blocking
        // instance of VS is closed.  That change event is sent implicitly by the
        // DOM, not explicitly by the directory picker so it won't have a details
        // property.  We need to protect against that rare occurence here.
        if (ev.detail) {
            if (ev.detail.path && ev.detail.path.length > 0) {
                this._installDir = ev.detail.path;
            }
            else {
                this._installDir = this.defaultInstallDir;
            }
        }
    };
    DetailsPage.prototype.installModifyClicked = function (ev) {
        this.doInstallModify();
    };
    DetailsPage.prototype.isSelectedTab = function (tabId) {
        if (!this._currentTab) {
            return false;
        }
        return this._currentTab.tabID === tabId;
    };
    Object.defineProperty(DetailsPage.prototype, "locationText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.location;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "summaryText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.summary;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "tabs", {
        get: function () {
            return this._tabs;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "tabPanelId", {
        /**
         * @returns {string} an id used by tab-control for accessibility
         */
        get: function () {
            return "tabpanel";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "workloadsTabId", {
        get: function () {
            return "Workloads";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "componentsTabId", {
        get: function () {
            return "Individual Components";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "langPacksTabId", {
        get: function () {
            return "Language Packs";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "isEvaluatingParameters", {
        get: function () {
            return factory_1.productConfigurationStore.isEvaluatingInstallParameters;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "evaluation", {
        get: function () {
            return factory_1.productConfigurationStore.evaluation;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "supportedLanguageCodes", {
        get: function () {
            if (this.selectedProduct) {
                return this.selectedProduct.availableLanguages;
            }
            return [];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "selectedComponents", {
        get: function () {
            return this._selectedComponents;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "selectedIndividualComponents", {
        get: function () {
            if (this.selectedProduct) {
                return factory_1.productConfigurationStore.getVirtualWorkloadComponents();
            }
            return [];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "installedIndividualComponents", {
        get: function () {
            if (this.selectedProduct) {
                return factory_1.productConfigurationStore.getInstalledIndividualComponents();
            }
            return [];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "defaultTab", {
        get: function () {
            var tab = this.tabs.get(this.workloadsTabId);
            if (!tab) {
                tab = this.tabs.get(this.componentsTabId);
            }
            if (!tab) {
                tab = this.tabs.get(this.langPacksTabId);
            }
            return tab;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "selectedProduct", {
        get: function () {
            return factory_1.productConfigurationStore.getSelectedProduct();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "selectedWorkloads", {
        get: function () {
            return this._selectedWorkloads;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "isInstalledProduct", {
        get: function () {
            var product = this.selectedProduct;
            return product && (product.installState !== undefined);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "isModifyWithUpdate", {
        get: function () {
            return this.opts.showUpdate || false;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "installDir", {
        get: function () {
            if (this.isReady && this._installDir === undefined) {
                if (this.isInstallOperation) {
                    // if this is a new install, use the default install location
                    this._installDir = this.defaultInstallDir;
                }
                else if (this.selectedProduct) {
                    // if this is a modify install, get the actual install location
                    this._installDir = this.selectedProduct.installationPath;
                }
            }
            return this._installDir || "";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "isReady", {
        get: function () {
            return !!factory_1.productConfigurationStore.getSelectedProduct()
                && !factory_1.productConfigurationStore.isBatchSelectionInProgress;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "defaultInstallDir", {
        get: function () {
            // if we're processing a command line install, use the --installPath from the command line
            if (factory_1.appStore.hasActiveCommandLineOperation && factory_1.appStore.argv.installPath) {
                return factory_1.appStore.argv.installPath;
            }
            if (this.selectedProduct) {
                // use the recommended install location
                var selectedProduct = this.selectedProduct;
                return selectedProduct.defaultInstallDirectory;
            }
            return "";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "installModifyText", {
        get: function () {
            if (this.isInstallOperation) {
                return ResourceStrings_1.ResourceStrings.install;
            }
            else if (this.isModifyWithUpdate) {
                return ResourceStrings_1.ResourceStrings.update;
            }
            else if (this.isRequestedProductChanged) {
                return ResourceStrings_1.ResourceStrings.modify;
            }
            else {
                return ResourceStrings_1.ResourceStrings.closeButtonTitle;
            }
        },
        enumerable: true,
        configurable: true
    });
    DetailsPage.prototype.tabSwitched = function (event) {
        this._currentTab = event.detail.tab;
        event.stopPropagation();
        this.update();
    };
    Object.defineProperty(DetailsPage.prototype, "cancelText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.cancel;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "acceptText", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.accept;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "detailsPageDivStyle", {
        /* Styles */
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexDirection: "column",
                height: "100%",
                justifyContent: "center"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "mainContentContainerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                boxSizing: "border-box",
                flex: "1 0 0",
                width: "100%"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "mainContentSpacerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 0 8px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "summaryPaneContentStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                boxSizing: "border-box",
                display: "block",
                height: "100%",
                webkitMarginStart: "20px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "summaryPaneStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "1 0 0",
                overflow: "hidden",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "titleStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                fontSize: "0.75rem",
                padding: "5px 15px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "tabDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                borderRightStyle: "solid",
                borderTopStyle: "solid",
                borderTopWidth: "1px",
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "column",
                flex: "1 0 auto",
                overflow: "auto",
                width: "0"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "tabControlContainerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                fontFamily: "Segoe UI SemiBold",
                fontSize: ".9167rem",
                margin: "8px 16px 0px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "workloadsTabStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                height: "100%",
                marginTop: "8px",
                webkitPaddingStart: "8px",
                // reserve space for scrollbar
                width: "calc(100% - 18px)"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "installLocationStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                borderStyle: "solid",
                borderWidth: "1px 0px 0px 0px",
                display: "flex",
                flexDirection: "row",
                minHeight: "95px",
                padding: "5px 10px 10px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "nickname", {
        get: function () {
            return this._nickname;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "directoryPickerDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                marginBottom: "5px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "controlContainerDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flex: "2 3 775px",
                flexDirection: "column",
                justifyContent: "space-between",
                webkitMarginEnd: "14px",
                webkitMarginBefore: "5px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "directoryPickerAndFolderModeToggleDivStyle", {
        // The style for the "location" label, textbox, and checkbox for separate folder mode.
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flex: "0 1 100%",
                flexDirection: "column",
                justifyContent: "space-between",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "directoryPickerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "individualComponentsStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flexGrow: "1",
                marginTop: "8px",
                height: "0px",
                webkitMarginStart: "15px",
                // reserve space for scrollbar and margin
                width: "calc(100% - 33px)"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "installDivStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                alignItems: "flex-end",
                display: "flex",
                flex: "1 1 300px",
                flexDirection: "column",
                justifyContent: "space-between",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "summaryPaneWithLicenseStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                display: "flex",
                flex: "0 0 370px",
                flexDirection: "column",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "errorAlertImageStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                height: "100%",
                marginTop: "1px",
                webkitMarginEnd: "4px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "imageStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                height: "14px",
                width: "14px"
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "errorMessageStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                borderTopStyle: "solid",
                borderTopWidth: "1px",
                display: "flex",
                fontSize: ".67rem",
                lineHeight: "1.35",
                webkitMarginAfter: "7px",
                webkitMarginBefore: "12px",
                webkitMarginEnd: "20px",
                webkitMarginStart: "20px",
                webkitPaddingBefore: "10px",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "nicknamePickerStyle", {
        get: function () {
            var style = css_styles_1.createStyleMap({
                flex: "0 0 auto",
            });
            return style.toString();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "showNickname", {
        get: function () {
            // if we have a nickname (this may be true if we're modifying), show the nickname field
            if (this.nickname) {
                return true;
            }
            // if we're configured to show the nickname field, show it
            if (this.opts.shownickname) {
                return true;
            }
            // if we get this far, don't show the nickname field
            return false;
        },
        enumerable: true,
        configurable: true
    });
    DetailsPage.prototype.onChange = function (ev) {
        this.checkInstallParameters();
    };
    DetailsPage.prototype.hookEvents = function (hook) {
        var hookMethod = Utilities_1.getEventHookMethodForTarget(this.root, hook);
        hookMethod("tabclick", this._tabSwitchedBind);
        hookMethod("change", this._onChangeBind);
        hookMethod = Utilities_1.getEventHookMethodForEventEmitter(factory_1.appStore, hook);
        hookMethod(factory_1.appStore.CHANGED_EVENT, this._handleReloadBind);
        hookMethod = Utilities_1.getEventHookMethodForEventEmitter(factory_1.productConfigurationStore, hook);
        hookMethod(factory_1.productConfigurationStore.CHANGED_EVENT, this._handleProductStoreChangeBind);
        hookMethod(factory_1.productConfigurationStore.FATAL_ERROR_EVENT, this._handleErrorBind);
    };
    DetailsPage.prototype.captureOriginallySelectedPackageIds = function () {
        if (this._originalSelectedPackageIdsCaptured) {
            return;
        }
        this._originalSelectedWorkloadIds = factory_1.productConfigurationStore.getSelectedWorkloadsOrdered()
            .map(function (workload) { return workload.id.toLowerCase(); });
        this._originalSelectedComponentIds = Array.from(factory_1.productConfigurationStore.getSelectedComponents().values())
            .map(function (component) { return component.id.toLowerCase(); });
        this._originalSelectedPackageIdsCaptured = true;
    };
    DetailsPage.prototype.handleReload = function () {
        // Check if we were just notified due to an install starting.
        if (factory_1.appStore.isOperationInProgress) {
            var initiatedFromCommandLine = factory_1.appStore.hasActiveCommandLineOperation;
            if (initiatedFromCommandLine) {
                command_line_actions_1.completeCommandLineOperation();
            }
            // If the last evaluation showed invalid disk space, send ignored telemetry.
            var evaluation = factory_1.productConfigurationStore.evaluation;
            if (evaluation &&
                evaluation.systemDriveEvaluation &&
                !evaluation.systemDriveEvaluation.hasSufficientDiskSpace) {
                DetailsPageActions_1.sendDiskSizeWarningIgnored();
            }
            DetailsPageActions_1.endDetailsPageSessionWithSuccess();
            // No need to continue updating after goHome was just called.
            router_1.Router.goHome();
            return;
        }
        this.update();
    };
    DetailsPage.prototype.handleError = function () {
        DetailsPageActions_1.endDetailsPageSessionWithFail();
        // If we got an error and we're quiet or passive, quit the app
        if (factory_1.appStore.argv.quiet || factory_1.appStore.argv.passive) {
            var success = false;
            WindowActions_1.windowActions.closeWindow(success, this.errorMessage);
        }
        // if we got an error, close the pane
        router_1.Router.goHome();
    };
    Object.defineProperty(DetailsPage.prototype, "isInstallOperation", {
        get: function () {
            return !this.isInstalledProduct;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "isModifyOperation", {
        get: function () {
            return !this.isInstallOperation;
        },
        enumerable: true,
        configurable: true
    });
    DetailsPage.prototype.doInstallModify = function () {
        if (this._installModifyStarted) {
            return;
        }
        var argv = factory_1.appStore.argv;
        var isQuietOrPassive = argv.quiet || argv.passive;
        this._installModifyStarted = true;
        if (isQuietOrPassive && factory_1.productConfigurationStore.hasArtifactSelectionWarnings) {
            var success = false;
            var errorMessage = factory_1.productConfigurationStore.artifactSelectionWarningMessage;
            WindowActions_1.windowActions.closeWindow(success, errorMessage);
            router_1.Router.goHome();
            return;
        }
        if (this.isInstallOperation) {
            var operation = "install";
            InstallerActions_1.install(this.selectedProduct, this.nickname, this.installDir, factory_1.appStore.argv.layoutPath, isQuietOrPassive, argv.productKey, factory_1.appStore.createTelemetryContext(operation));
        }
        else {
            var installedProduct = this.selectedProduct;
            if (this.isRequestedProductChanged || installedProduct.hasUpdatePackages) {
                var operation = "modify";
                InstallerActions_1.modify(installedProduct, isQuietOrPassive, factory_1.appStore.createTelemetryContext(operation));
            }
            else {
                // If we are quiet or passive, quit with nothing to do.
                if (factory_1.appStore.argv.quiet || factory_1.appStore.argv.passive) {
                    var success = true;
                    WindowActions_1.windowActions.closeWindow(success);
                }
                // Nothing to do, just close the dialog.
                router_1.Router.goHome();
            }
        }
    };
    DetailsPage.prototype.checkInstallParameters = function () {
        // if we don't have a selected product or we've already started the install/modify, no need to check
        if (!this.selectedProduct || this._installModifyStarted) {
            return;
        }
        var isQuietOrPassive = factory_1.appStore.isQuietOrPassive;
        if (isQuietOrPassive && factory_1.productConfigurationStore.hasArtifactSelectionWarnings) {
            return;
        }
        var initiatedFromCommandLine = factory_1.appStore.hasActiveCommandLineOperation;
        if (this.isInstalledProduct) {
            InstallerActions_1.evaluateModifyParameters(this.selectedProduct, initiatedFromCommandLine, false /* updateOnModify */);
        }
        else {
            var nickname = this.nickname;
            var installationPath = this.installDir;
            InstallerActions_1.evaluateInstallParameters(this.selectedProduct, nickname, installationPath, factory_1.appStore.argv.layoutPath, initiatedFromCommandLine);
        }
    };
    Object.defineProperty(DetailsPage.prototype, "evaluationErrorMessage", {
        get: function () {
            if (!factory_1.productConfigurationStore.evaluation) {
                return "";
            }
            return factory_1.productConfigurationStore.evaluation.errorMessage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "hasErrorMessage", {
        get: function () {
            return !!this.errorMessage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "errorMessageImageSrc", {
        get: function () {
            return "images/StatusCriticalError.svg";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "hasCriticalError", {
        // A critical error is either an evaluation error message, local error message, or installer error message.
        // If an evaluation is in process and the previous error message was critical, we return true to prevent
        // the error image from changing.
        get: function () {
            var evaluationHasError = !!this.evaluationErrorMessage;
            var installerStatusHasError = !!this.installerStatusErrorMessage;
            var hasLocalError = !!this._localErrorMessage;
            return evaluationHasError ||
                installerStatusHasError ||
                hasLocalError;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "errorMessage", {
        // Any warning messages must be at the end so we show blocking messages first
        get: function () {
            return this._localErrorMessage ||
                this.evaluationErrorMessage ||
                this.installerStatusErrorMessage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "installerStatusErrorMessage", {
        get: function () {
            // Bug 378908: We don't want to verify that there are no blocking processes until the
            // user clicks Install or Modify (so we don't have to poll on GetStatus).  We'll ignored
            // blocking processes at this point.
            var includeBlockingProcessErrors = false;
            return factory_1.appStore.installerStatus.getErrorMessage(includeBlockingProcessErrors);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "isRequestedProductChanged", {
        /**
         * @returns true if the selectedProduct is a new install or the user
         *          has made selections that would change the selectedProduct
         */
        get: function () {
            var _this = this;
            // Enable the close button while waiting for the product record to load in case the user
            // chooses to cancel the operation.
            if (!this.selectedProduct) {
                return true;
            }
            // An uninstalled product is always a change request due to the implicit product and required package
            // selections.
            if (!this.isInstalledProduct) {
                return true;
            }
            // The installed product is always a change request when the desired installation is partial.
            var installedProduct = this.selectedProduct;
            if (installedProduct.installState === Product_1.InstallState.Partial) {
                return true;
            }
            // The installed product has a change request when the UI selected workloads doesn't match the originally
            // selected workloads.
            var workloadIds = this.selectedWorkloads.map(function (workload) { return workload.id.toLowerCase(); });
            if (workloadIds.length !== this._originalSelectedWorkloadIds.length ||
                workloadIds.some(function (id) { return _this._originalSelectedWorkloadIds.indexOf(id) === -1; })) {
                return true;
            }
            // The installed product has a change request when the UI selected components doesn't match the originally
            // components workloads.
            var componentIds = this.selectedComponents.map(function (component) { return component.id.toLowerCase(); });
            if (componentIds.length !== this._originalSelectedComponentIds.length ||
                componentIds.some(function (id) { return _this._originalSelectedComponentIds.indexOf(id) === -1; })) {
                return true;
            }
            // The installed product has a change request when the UI selected workloads are not currently installed.
            var installedWorkloadIds = this.selectedProduct.workloads
                .filter(function (workload) { return workload.installState === Product_1.InstallState.Installed; })
                .map(function (workload) { return workload.id.toLowerCase(); });
            if (workloadIds.length !== installedWorkloadIds.length ||
                workloadIds.some(function (id) { return installedWorkloadIds.indexOf(id) === -1; })) {
                return true;
            }
            // The installed product has a change request when the UI selected components are not currently installed.
            var installedComponentIds = this.selectedProduct.allComponents
                .filter(function (component) { return component.installState === Product_1.InstallState.Installed; })
                .map(function (component) { return component.id.toLowerCase(); });
            if (componentIds.length !== installedComponentIds.length ||
                componentIds.some(function (id) { return installedComponentIds.indexOf(id) === -1; })) {
                return true;
            }
            // The installed product has a change request when the selected languages are not currently installed.
            var selectedLanguages = installedProduct.selectedLanguages;
            var installedLanguages = installedProduct.installedLanguages
                .map(function (language) { return locale_handler_1.LocaleHandler.getSupportedLocale(language); });
            if (selectedLanguages.length !== installedLanguages.length ||
                !selectedLanguages.every(function (locale) {
                    return installedLanguages.findIndex(function (language) { return locale === language; }) !== -1;
                })) {
                return true;
            }
            return false;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DetailsPage.prototype, "canInstall", {
        get: function () {
            return !this.isEvaluatingParameters && !this.hasCriticalError && !this._installModifyStarted;
        },
        enumerable: true,
        configurable: true
    });
    DetailsPage.prototype.initializeNickname = function () {
        var _this = this;
        if (this.isInstalledProduct) {
            // init the nickname field from the installed product's nickname
            this._nickname = this.selectedProduct.nickname;
        }
        else {
            // build up our collection of existing nicknames so we can ensure uniqueness later
            factory_1.appStore.installedAndInstallingItems.forEach(function (item) {
                var nickname = item.product.nickname;
                if (nickname) {
                    _this._existingNicknames.push(nickname);
                }
                else {
                    _this._productWithoutNicknameExists = true;
                }
            });
            // if we were given a requested nickname, use it; otherwise,
            // if we already have a product without a nickname, suggest a
            // nickname that doesn't conflict with an existing nickname
            if (this.opts.requestednickname) {
                this._nickname = this.opts.requestednickname;
            }
            else if (this._productWithoutNicknameExists) {
                this._nickname = nickname_utilities_1.suggestNickname(this._existingNicknames);
            }
            this.validateNickname(this._nickname);
        }
    };
    DetailsPage.prototype.validateNickname = function (nickname) {
        // make sure it is valid
        if (!nickname_utilities_1.isValidNickname(nickname)) {
            this._localErrorMessage = ResourceStrings_1.ResourceStrings.invalidNickname;
            return false;
        }
        // make sure a nickname is provided if we already have an install without a nickname
        if (this._productWithoutNicknameExists && !nickname) {
            this._localErrorMessage = ResourceStrings_1.ResourceStrings.nicknameRequired;
            return false;
        }
        // make sure it's unique
        if (this._existingNicknames.indexOf(nickname) !== -1) {
            this._localErrorMessage = ResourceStrings_1.ResourceStrings.nicknameNotUnique(nickname);
            return false;
        }
        this._localErrorMessage = null;
        return true;
    };
    DetailsPage = __decorate([
        template("\n<details-page>\n    <div style={this.detailsPageDivStyle}>\n        <div style={this.tabControlContainerStyle}>\n            <tab-control if={this.tabs.length > 0}\n                         tabs={this.tabs}\n                         defaulttab={this.defaultTab}\n                         tabpanelid={this.tabPanelId} />\n        </div>\n        <div style={this.mainContentContainerStyle}>\n            <div class=\"details-page-tab-container\"\n                 style={this.tabDivStyle}\n                 id={this.tabPanelId}\n                 role=\"tabpanel\">\n                <!-- Workloads Tab -->\n                <workloads-page if={this.isSelectedTab(this.workloadsTabId)}\n                                style={this.workloadsTabStyle}\n                                product={this.selectedProduct}\n                                selectedworkloads={this.selectedWorkloads} />\n\n                <!-- Components Tab -->\n                <individual-components-page if={this.isSelectedTab(this.componentsTabId)}\n                                            style={individualComponentsStyle}\n                                            product={this.selectedProduct}\n                                            selectedcomponents={this.selectedComponents} />\n\n                <!-- Languages Tab -->\n                <language-packs-page if={this.isSelectedTab(this.langPacksTabId)}\n                                     style={individualComponentsStyle}\n                                     product={this.selectedProduct} />\n            </div>\n            <div style={this.summaryPaneWithLicenseStyle}>\n                <div style={this.summaryPaneStyle}\n                     role=\"log\"\n                     aria-relevant=\"additions removals\"\n                     aria-label={summaryText}>\n                    <product-install-summary class=\"install-summary-pane\"\n                                             style={summaryPaneContentStyle}\n                                             product={this.selectedProduct}\n                                             selectedworkloads={this.selectedWorkloads}\n                                             installed-individual-components={this.installedIndividualComponents}\n                                             individualcomponents={this.selectedIndividualComponents} />\n                </div>\n\n                <!-- error message -->\n                <div class=\"summary-footer\"\n                     if={this.hasErrorMessage}\n                     role=\"alert\"\n                     aria-atomic=\"true\"\n                     aria-live=\"polite\"\n                     style=\"{this.errorMessageStyle}\">\n                    <div style={this.errorAlertImageStyle}>\n                        <img src={this.errorMessageImageSrc} />\n                    </div>\n                    <div tabindex=\"0\"\n                         role=\"note\"\n                         class=\"error-text\"\n                         aria-label={this.errorMessage}>\n                        {this.errorMessage}\n                    </div>\n                </div>\n\n            </div>\n        </div>\n\n        <div class=\"install-location\"\n                style={this.installLocationStyle}>\n\n            <!-- container for directory/nickname pickers and error message -->\n            <div style={this.controlContainerDivStyle}>\n                <div style={this.directoryPickerDivStyle}>\n                    <!-- directory picker -->\n                    <div style={this.directoryPickerAndFolderModeToggleDivStyle}>\n                        <directory-picker style={this.directoryPickerStyle}\n                                          label={locationText}\n                                          isreadonly={this.isInstalledProduct}\n                                          value={this.installDir}\n                                          onChange={this.directoryChanged} />\n                    </div>\n\n                    <nickname-picker if={this.showNickname}\n                                     style={this.nicknamePickerStyle}\n                                     isreadonly={this.isInstalledProduct}\n                                     initialnickname={this.nickname}\n                                     onChange={this.nicknameChanged} />\n                </div>\n\n                <license-terms-text />\n            </div>\n\n            <!-- install size, button -->\n            <div style={this.installDivStyle}>\n                <install-size-breakdown is-evaluating-parameters={this.isEvaluatingParameters}\n                                       evaluation={this.evaluation}\n                                       can-install={this.canInstall} />\n\n                <button onClick={this.installModifyClicked}\n                        id=\"installModifyButton\"\n                        type=\"submit\"\n                        disabled={!this.canInstall}>\n                    {this.installModifyText}\n                </button>\n            </div>\n        </div>\n    </div>\n</details-page>")
    ], DetailsPage);
    return DetailsPage;
}(Riot.Element));
exports.DetailsPage = DetailsPage;
//# sourceMappingURL=details-page.js.map