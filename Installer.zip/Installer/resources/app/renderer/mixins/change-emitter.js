/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var ChangeEmitter = (function () {
    function ChangeEmitter() {
    }
    /**
     * Emits a standard DOM "change" event.
     */
    ChangeEmitter.prototype.emitChange = function (element, detail) {
        if (detail === void 0) { detail = {}; }
        var changedEvent = new CustomEvent("change", {
            bubbles: true,
            cancelable: true,
            detail: detail,
        });
        return element.dispatchEvent(changedEvent);
    };
    return ChangeEmitter;
}());
exports.ChangeEmitter = ChangeEmitter;
//# sourceMappingURL=change-emitter.js.map