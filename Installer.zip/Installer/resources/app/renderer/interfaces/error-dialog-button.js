/*---------------------------------------------------------
* Copyright (C) Microsoft Corporation. All rights reserved.
*--------------------------------------------------------*/
"use strict";
var ButtonIds;
(function (ButtonIds) {
    "use strict";
    ButtonIds.DEFAULT_CANCEL = "DEFAULT_CANCEL";
    ButtonIds.DEFAULT_SUBMIT = "DEFAULT_SUBMIT";
})(ButtonIds = exports.ButtonIds || (exports.ButtonIds = {}));
//# sourceMappingURL=error-dialog-button.js.map