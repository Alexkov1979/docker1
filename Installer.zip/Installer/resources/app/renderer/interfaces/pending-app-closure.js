/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var window_action_constants_1 = require("../../lib/window-action-constants");
var PendingAppClosure = (function () {
    function PendingAppClosure(success, isAppClosurePending, exitCode) {
        if (success === void 0) { success = true; }
        if (isAppClosurePending === void 0) { isAppClosurePending = false; }
        this._success = success;
        this._isAppClosurePending = isAppClosurePending;
        this._exitCode = exitCode;
    }
    Object.defineProperty(PendingAppClosure, "exitCodeRebootRequested", {
        get: function () {
            return window_action_constants_1.EXIT_CODE_REBOOT_REQUESTED;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingAppClosure, "exitCodeRebootRequired", {
        get: function () {
            return window_action_constants_1.EXIT_CODE_REBOOT_REQUIRED;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingAppClosure.prototype, "success", {
        get: function () {
            return this._success;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingAppClosure.prototype, "isAppClosurePending", {
        get: function () {
            return this._isAppClosurePending;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PendingAppClosure.prototype, "exitCode", {
        get: function () {
            return this._exitCode;
        },
        enumerable: true,
        configurable: true
    });
    return PendingAppClosure;
}());
exports.PendingAppClosure = PendingAppClosure;
//# sourceMappingURL=pending-app-closure.js.map