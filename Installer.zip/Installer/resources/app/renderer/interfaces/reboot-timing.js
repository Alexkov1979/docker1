/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
(function (RebootTiming) {
    RebootTiming[RebootTiming["None"] = 0] = "None";
    RebootTiming[RebootTiming["DuringInstall"] = 1] = "DuringInstall";
    RebootTiming[RebootTiming["AfterInstall"] = 2] = "AfterInstall";
})(exports.RebootTiming || (exports.RebootTiming = {}));
var RebootTiming = exports.RebootTiming;
//# sourceMappingURL=reboot-timing.js.map