/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
(function (ButtonType) {
    ButtonType[ButtonType["DEFAULT_SUBMIT"] = 0] = "DEFAULT_SUBMIT";
    ButtonType[ButtonType["DEFAULT_CANCEL"] = 1] = "DEFAULT_CANCEL";
    ButtonType[ButtonType["CUSTOM"] = 2] = "CUSTOM";
})(exports.ButtonType || (exports.ButtonType = {}));
var ButtonType = exports.ButtonType;
//# sourceMappingURL=error-message-response.js.map