/*---------------------------------------------------------
* Copyright (C) Microsoft Corporation. All rights reserved.
*--------------------------------------------------------*/
"use strict";
(function (CheckboxState) {
    /**
     * There is no checkbox.
     */
    CheckboxState[CheckboxState["None"] = 0] = "None";
    /**
     * The checkbox is unchecked.
     */
    CheckboxState[CheckboxState["Unchecked"] = 1] = "Unchecked";
    /**
     * The checkbox is checked.
     */
    CheckboxState[CheckboxState["Checked"] = 2] = "Checked";
})(exports.CheckboxState || (exports.CheckboxState = {}));
var CheckboxState = exports.CheckboxState;
//# sourceMappingURL=checkbox-state.js.map