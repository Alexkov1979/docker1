/*---------------------------------------------------------
* Copyright (C) Microsoft Corporation. All rights reserved.
*--------------------------------------------------------*/
"use strict";
/**
 * Describes whether a product should be launched or not.
 */
(function (ProductLaunchState) {
    /**
     * The normal state of an installed product. Will not launch after an operation.
     */
    ProductLaunchState[ProductLaunchState["None"] = 0] = "None";
    /**
     * The state for a product that should be launched when installation completes.
     */
    ProductLaunchState[ProductLaunchState["LaunchAfterInstall"] = 1] = "LaunchAfterInstall";
    /**
     * The state for a product that is ready to be launched.
     */
    ProductLaunchState[ProductLaunchState["Pending"] = 2] = "Pending";
})(exports.ProductLaunchState || (exports.ProductLaunchState = {}));
var ProductLaunchState = exports.ProductLaunchState;
//# sourceMappingURL=product-launch-state.js.map