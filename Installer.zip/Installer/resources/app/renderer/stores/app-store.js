/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../typings/globals/es6-shim/index.d.ts" />
/// <reference path="../../typings/globals/node/index.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var error_message_response_1 = require("../interfaces/error-message-response");
var string_utilities_1 = require("../../lib/string-utilities");
var cancel_requested_event_1 = require("../Events/cancel-requested-event");
var CommandLine_1 = require("../../lib/CommandLine");
var debounce_1 = require("../../lib/debounce");
var deep_clean_preview_installations_events_1 = require("../Events/deep-clean-preview-installations-events");
var FileSystem_1 = require("../../lib/FileSystem");
var begin_command_line_operation_event_1 = require("../Events/begin-command-line-operation-event");
var channel_1 = require("./channel");
var get_channel_info_finished_event_1 = require("../Events/get-channel-info-finished-event");
var get_summaries_finished_event_1 = require("../Events/get-summaries-finished-event");
var installed_product_received_event_1 = require("../Events/installed-product-received-event");
var complete_command_line_operation_event_1 = require("../Events/complete-command-line-operation-event");
var command_line_args_1 = require("../interfaces/command-line-args");
var command_line_operation_state_1 = require("../interfaces/command-line-operation-state");
var Product_1 = require("../../lib/Installer/Product");
var installed_product_errors_1 = require("../../lib/Installer/installed-product-errors");
var dispatcher_1 = require("../dispatcher");
var ElevationRequiredEvent_1 = require("../Events/ElevationRequiredEvent");
var KeyCodes_1 = require("../KeyCodes");
var error_dialog_mode_1 = require("../interfaces/error-dialog-mode");
var events_1 = require("events");
var HostUpdaterStatusChangedEvent_1 = require("../Events/HostUpdaterStatusChangedEvent");
var installed_or_installing_product_1 = require("../interfaces/installed-or-installing-product");
var installer_status_changed_event_1 = require("../Events/installer-status-changed-event");
var installer_notification_received_event_1 = require("../Events/installer-notification-received-event");
var InstallFinishedEvent_1 = require("../Events/InstallFinishedEvent");
var InstallingState_1 = require("../InstallingState");
var InstallerState_1 = require("../../lib/InstallerState");
var InstallProgressEvent_1 = require("../Events/InstallProgressEvent");
var InstallStartedEvent_1 = require("../Events/InstallStartedEvent");
var locale_handler_1 = require("../../lib/locale-handler");
var ModifyFinishedEvent_1 = require("../Events/ModifyFinishedEvent");
var ModifyStartedEvent_1 = require("../Events/ModifyStartedEvent");
var OperationFailedEvent_1 = require("../Events/OperationFailedEvent");
var launch_banner_closed_event_1 = require("../Events/launch-banner-closed-event");
var querystring_1 = require("querystring");
var pending_app_closure_1 = require("../interfaces/pending-app-closure");
var reboot_timing_1 = require("../interfaces/reboot-timing");
var remove_channel_finished_event_1 = require("../Events/remove-channel-finished-event");
var remove_channel_started_event_1 = require("../Events/remove-channel-started-event");
var RepairFinishedEvent_1 = require("../Events/RepairFinishedEvent");
var RepairStartedEvent_1 = require("../Events/RepairStartedEvent");
var ResourceStrings_1 = require("../../lib/ResourceStrings");
var show_product_event_1 = require("../Events/show-product-event");
var UninstallFinishedEvent_1 = require("../Events/UninstallFinishedEvent");
var UninstallSelfStatusChangedEvent_1 = require("../Events/UninstallSelfStatusChangedEvent");
var UninstallStartedEvent_1 = require("../Events/UninstallStartedEvent");
var update_finished_event_1 = require("../Events/update-finished-event");
var update_started_event_1 = require("../Events/update-started-event");
var window_close_request_event_1 = require("../Events/window-close-request-event");
var WindowStateChangedEvent_1 = require("../Events/WindowStateChangedEvent");
var errorNames = require("../../lib/error-names");
var product_launch_state_changed_event_1 = require("../Events/product-launch-state-changed-event");
var product_launch_state_1 = require("../interfaces/product-launch-state");
var experiments_1 = require("../../lib/experiments/experiments");
(function (HostInstallState) {
    HostInstallState[HostInstallState["Installed"] = 0] = "Installed";
    HostInstallState[HostInstallState["Uninstalling"] = 1] = "Uninstalling";
    HostInstallState[HostInstallState["UninstallFailed"] = 2] = "UninstallFailed";
    HostInstallState[HostInstallState["UninstallBlockedByRunningInstance"] = 3] = "UninstallBlockedByRunningInstance";
})(exports.HostInstallState || (exports.HostInstallState = {}));
var HostInstallState = exports.HostInstallState;
exports.ACCESSIBILITY_LOG_STRING_LIMIT = 20;
exports.UNINSTALL_SELF_PRODUCT_PROGRESS_KEY = "uninstall-self-product-progress";
var noAppClosure = new pending_app_closure_1.PendingAppClosure();
/**
 * App Store: Contains state for the app
 */
var AppStore = (function (_super) {
    __extends(AppStore, _super);
    function AppStore(window, errorStore, utilities, channelProductFilterFactory, experiments) {
        var _this = this;
        _super.call(this);
        this._appVersion = "";
        this._branch = "";
        this._channels = [];
        this._addDownloadProgress = debounce_1.debounce(function (message) { return _this.addMessageToAccessibilityLog(message); }, 20000);
        this._addInstallProgress = debounce_1.debounce(function (message) { return _this.addMessageToAccessibilityLog(message); }, 20000);
        this._firstInstallExperienceSeen = false;
        this._isFirstInstallExperience = false;
        this._productsParseFailReason = null;
        this._channelDownloadFailed = false;
        this._productsReceived = false;
        this._downloadProgressByInstallationPath = new Map();
        this._installationsReceived = false;
        this._channelInfoReceived = false;
        this._installProgressByInstallationPath = new Map();
        this._locale = "";
        this._showReleaseNotesLink = false;
        this._pendingAppClosure = noAppClosure;
        this._pendingInstallerNotifications = new Map();
        this._installedOrInstallingList = [];
        this._accessibilityLog = [];
        this._isDeepCleaningPreviewInstallations = false;
        this._installerStatus = installer_status_changed_event_1.InstallerStatus.pending;
        this._productLaunchStates = new Map();
        /* tslint:disable:member-ordering */
        // Backing field. Use property instead.
        this._hostUpdaterStatusEvent = new HostUpdaterStatusChangedEvent_1.HostUpdaterStatusChangedEvent(HostUpdaterStatusChangedEvent_1.HostUpdaterStatus.UpdateNotAvailable, false);
        this._experiments = experiments;
        this._errorStore = errorStore;
        this._channelProductFilterFactory = channelProductFilterFactory;
        this.windowState = new WindowStateChangedEvent_1.WindowState();
        // fetch version from window.location
        var queryString = window.location.search.substr(1);
        var queryStringParts = querystring_1.parse(queryString);
        var queryOptions = this.queryOptionsFromQueryStringParts(queryStringParts, utilities);
        this._appVersion = queryOptions.appVersion;
        this._branch = queryOptions.branch;
        this._locale = locale_handler_1.LocaleHandler.getSupportedLocale(queryOptions.locale);
        this._argv = new command_line_args_1.CommandLineArgs(queryOptions);
        this._showDownlevelSkus = !!queryOptions.showDownlevelSkus;
        this._commandLineOperationState = (this._argv.command)
            ? command_line_operation_state_1.CommandLineOperationState.Pending
            : command_line_operation_state_1.CommandLineOperationState.Unspecified;
        if (this._argv.quiet || this._argv.passive) {
            this._errorStore.setErrorsToQuiet();
        }
        /* istanbul ignore next */
        window.addEventListener("keyup", function (ev) {
            if (ev.keyCode === KeyCodes_1.keyCodes.F12) {
                // if we're in debug mode, open dev tools when F12 is pressed,
                // if we're not in debug mode, open dev tools when Ctrl+Alt+Shift+F12 is pressed
                if (_this._argv.debug || (ev.ctrlKey && ev.altKey && ev.shiftKey)) {
                    utilities.openDevTools();
                }
            }
        });
        // when uninstalling, this value could be set to true to
        // notify us of another running instance
        /* istanbul ignore next */
        if (queryOptions.isAnotherInstanceRunning) {
            this._hostInstallState = HostInstallState.UninstallBlockedByRunningInstance;
        }
        else {
            this._hostInstallState = HostInstallState.Installed;
        }
        this._eventHandlers = [
            { event: get_summaries_finished_event_1.GetSummariesFinishedEvent, callback: this.onGetSummariesFinished.bind(this) },
            { event: installed_product_received_event_1.InstalledProductReceivedEvent, callback: this.onInstalledProductReceived.bind(this) },
            { event: HostUpdaterStatusChangedEvent_1.HostUpdaterStatusChangedEvent, callback: this.onHostUpdaterStatusChanged.bind(this) },
            { event: InstallProgressEvent_1.InstallProgressEvent, callback: this.onInstallProgressChanged.bind(this) },
            { event: OperationFailedEvent_1.OperationFailedEvent, callback: this.onOperationFailed.bind(this) },
            { event: UninstallSelfStatusChangedEvent_1.UninstallSelfStatusChangedEvent, callback: this.onUninstallSelfStatusChanged.bind(this) },
            { event: installer_notification_received_event_1.InstallerNotificationReceivedEvent, callback: this.onInstallerNotificationReceived.bind(this) },
            { event: InstallFinishedEvent_1.InstallFinishedEvent, callback: this.onInstallFinished.bind(this) },
            { event: InstallStartedEvent_1.InstallStartedEvent, callback: this.onInstallStarted.bind(this) },
            { event: ModifyFinishedEvent_1.ModifyFinishedEvent, callback: this.onModifyFinished.bind(this) },
            { event: ModifyStartedEvent_1.ModifyStartedEvent, callback: this.onModifyStarted.bind(this) },
            { event: update_finished_event_1.UpdateFinishedEvent, callback: this.onUpdateFinished.bind(this) },
            { event: update_started_event_1.UpdateStartedEvent, callback: this.onUpdateStarted.bind(this) },
            { event: begin_command_line_operation_event_1.BeginCommandLineOperationEvent, callback: this.beginCommandLineOperation.bind(this) },
            { event: complete_command_line_operation_event_1.CompleteCommandLineOperationEvent, callback: this.completeCommandLineOperation.bind(this) },
            { event: launch_banner_closed_event_1.LaunchBannerClosedEvent, callback: this.launchBannerClosed.bind(this) },
            { event: show_product_event_1.ShowProductEvent, callback: this.showProduct.bind(this) },
            { event: UninstallFinishedEvent_1.UninstallFinishedEvent, callback: this.onUninstallFinished.bind(this) },
            { event: UninstallStartedEvent_1.UninstallStartedEvent, callback: this.onUninstallStarted.bind(this) },
            { event: WindowStateChangedEvent_1.WindowStateChangedEvent, callback: this.onWindowStateChangedEvent.bind(this) },
            { event: RepairFinishedEvent_1.RepairFinishedEvent, callback: this.onRepairFinished.bind(this) },
            { event: RepairStartedEvent_1.RepairStartedEvent, callback: this.onRepairStarted.bind(this) },
            { event: get_channel_info_finished_event_1.GetChannelInfoFinishedEvent, callback: this.onGetChannelInfoFinished.bind(this) },
            { event: window_close_request_event_1.WindowCloseRequestEvent, callback: this.onWindowCloseRequest.bind(this) },
            { event: ElevationRequiredEvent_1.ElevationRequiredEvent, callback: this.onElevationRequired.bind(this) },
            {
                event: deep_clean_preview_installations_events_1.DeepCleanPreviewInstallationsCompleted,
                callback: this.onDeepCleanPreviewInstallationsCompleted.bind(this)
            },
            {
                event: deep_clean_preview_installations_events_1.DeepCleanPreviewInstallationsStarted,
                callback: this.onDeepCleanPreviewInstallationsStarted.bind(this)
            },
            {
                event: installer_status_changed_event_1.InstallerStatusChangedEvent,
                callback: this.onInstallerStatusChangedEvent.bind(this)
            },
            {
                event: remove_channel_finished_event_1.RemoveChannelFinishedEvent,
                callback: this.onRemoveChannelFinishedEvent.bind(this)
            },
            {
                event: remove_channel_started_event_1.RemoveChannelStartedEvent,
                callback: this.onRemoveChannelStartedEvent.bind(this)
            },
            {
                event: cancel_requested_event_1.CancelRequestedEvent,
                callback: this.onCancelRequestedEvent.bind(this)
            },
            {
                event: product_launch_state_changed_event_1.ProductLaunchStateChangedEvent,
                callback: this.onProductLaunchStateChangedEvent.bind(this)
            },
        ];
        this.registerEvents();
    }
    AppStore.makeProductFirstInChannels = function (channels, channelId, productId) {
        if (!channelId || !productId || !channels || channels.length === 0) {
            return;
        }
        // move the specified channel to the beginning of the list of channels
        channels.sort(AppStore.makeItemFirst(channelId));
        // if the first channel is the specified channel, move the specified product to the
        // beginning of its list of products
        if (string_utilities_1.caseInsensitiveAreEqual(channels[0].id, channelId)) {
            channels[0].products.sort(AppStore.makeItemFirst(productId));
        }
    };
    AppStore.makeItemFirst = function (id) {
        return function (a, b) {
            if (string_utilities_1.caseInsensitiveAreEqual(a.id, id)) {
                return -1;
            }
            else if (string_utilities_1.caseInsensitiveAreEqual(b.id, id)) {
                return 1;
            }
            return 0;
        };
    };
    Object.defineProperty(AppStore.prototype, "CHANGED_EVENT", {
        get: function () {
            return "CHANGED";
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.dispose = function () {
        this._accessibilityLog = [];
        this.unregisterEvents();
    };
    Object.defineProperty(AppStore.prototype, "argv", {
        get: function () {
            return this._argv;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "commandLineOperationState", {
        get: function () {
            return this._commandLineOperationState;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "hasActiveCommandLineOperation", {
        /**
         * Returns true if there is an active command line operation (i.e. if
         * the command line operation state is not Unspecified or Complete).
         */
        get: function () {
            switch (this._commandLineOperationState) {
                case command_line_operation_state_1.CommandLineOperationState.Unspecified:
                case command_line_operation_state_1.CommandLineOperationState.Complete:
                    return false;
                default:
                    return true;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isFirstInstallExperience", {
        get: function () {
            return this._isFirstInstallExperience;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "pendingAppClosure", {
        get: function () {
            return this._pendingAppClosure;
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.clearPendingAppClosure = function () {
        if (this._pendingAppClosure !== noAppClosure) {
            this._pendingAppClosure = noAppClosure;
            this.emitChangedEvent();
        }
    };
    Object.defineProperty(AppStore.prototype, "loadFailed", {
        get: function () {
            return !!this._productsParseFailReason && !this._channelDownloadFailed;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "loadFailReason", {
        get: function () {
            return this._productsParseFailReason || ResourceStrings_1.ResourceStrings.notConnected;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "showReleaseNotesLink", {
        get: function () {
            return this._showReleaseNotesLink;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isLoading", {
        /**
         * Show the loading screen while one of the following is true:
         *  * The installations have not been received.
         *  * Installations received, but 0 installations and no channels received.
         *  * Host updater is still checking for updates.
         */
        get: function () {
            return !this.loadFailed
                && (!this._installationsReceived
                    || (this._installationsReceived && this._installations.length === 0 && !this._productsReceived)
                    || this.hostUpdaterStatus === HostUpdaterStatusChangedEvent_1.HostUpdaterStatus.Pending);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "appName", {
        get: function () {
            return ResourceStrings_1.ResourceStrings.appWindowTitle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "hostInstallState", {
        get: function () {
            return this._hostInstallState;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "maximized", {
        get: function () {
            return this.windowState.maximized;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "branch", {
        get: function () {
            return this._branch;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "appLocale", {
        get: function () {
            return this._locale;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "installedAndInstallingItems", {
        get: function () {
            return this._installedOrInstallingList;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "productSummaryFromCommandLineArgs", {
        /**
         * Gets the matching IProductSummary or IInstalledProductSummary
         * for command line handling.
         */
        get: function () {
            // If no command line args are specified, return null.
            if (this._commandLineOperationState === command_line_operation_state_1.CommandLineOperationState.Unspecified) {
                return null;
            }
            var channelId = this._argv.channelId;
            var productId = this._argv.productId;
            var installPath = this._argv.installPath;
            var fromInstalledProducts = true;
            switch (this._argv.command) {
                case CommandLine_1.CommandNames.install:
                    // See if a matching product is already installed. If it is, return the installed summary,
                    // otherwise try to see if the product is available to install.
                    var productSummary = installPath
                        ? this.findInstalledProductSummary(installPath)
                        : this.findProductSummary(channelId, productId, fromInstalledProducts);
                    if (!productSummary) {
                        return this.findProductSummary(channelId, productId, !fromInstalledProducts);
                    }
                    return productSummary;
                case CommandLine_1.CommandNames.modify:
                case CommandLine_1.CommandNames.repair:
                case CommandLine_1.CommandNames.resume:
                case CommandLine_1.CommandNames.uninstall:
                case CommandLine_1.CommandNames.update:
                    // locate the installed product that we're going to operate on
                    // (--installPath takes precedence over --channelId/--productId)
                    return installPath
                        ? this.findInstalledProductSummary(installPath)
                        : this.findProductSummary(channelId, productId, fromInstalledProducts);
                default:
                    return null;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isQuietOrPassive", {
        get: function () {
            return this.argv.quiet || this.argv.passive;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @returns {IProductSummaryBase} for the supplied parameters. null if the item is not found
     */
    AppStore.prototype.findProductSummary = function (channelId, id, fromInstalledProducts) {
        if (fromInstalledProducts) {
            return this._installations.find(function (installedProductSummary) {
                return string_utilities_1.caseInsensitiveAreEqual(installedProductSummary.channelId, channelId)
                    && string_utilities_1.caseInsensitiveAreEqual(installedProductSummary.id, id);
            });
        }
        var channel = this._channels.find(function (c) { return string_utilities_1.caseInsensitiveAreEqual(c.id, channelId); });
        if (channel) {
            return channel.products.find(function (productSummary) {
                return string_utilities_1.caseInsensitiveAreEqual(productSummary.channelId, channelId)
                    && string_utilities_1.caseInsensitiveAreEqual(productSummary.id, id);
            });
        }
        return null;
    };
    /**
     * @returns {IInstalledProductSummary} for the supplied path. null if the item is not found
     */
    AppStore.prototype.findInstalledProductSummary = function (installPath) {
        return this._installations.find(function (installedProductSummary) {
            return FileSystem_1.arePathsEqual(installPath, installedProductSummary.installationPath);
        });
    };
    AppStore.prototype.getAppVersion = function () {
        return this._appVersion;
    };
    AppStore.prototype.getInstallProgressByInstallationPath = function (installationPath) {
        return this._installProgressByInstallationPath.get(installationPath);
    };
    AppStore.prototype.getDownloadProgressByInstallationPath = function (installationPath) {
        return this._downloadProgressByInstallationPath.get(installationPath);
    };
    Object.defineProperty(AppStore.prototype, "numberOfVisibleChannels", {
        /**
         * Gets the number of channels with visible products.
         */
        get: function () {
            return this._channels.filter(function (channel) { return channel.visibleProducts.length !== 0; }).length;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "allChannels", {
        /**
         * Gets all the channels without any filtering
         */
        get: function () {
            return this._channels;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Gets the channels with installable products.
     */
    AppStore.prototype.getInstallableChannels = function () {
        var channelProductFilter = this.createChannelFilter();
        var filteredChannels = channelProductFilter.filter(this._channels);
        // Sort the products within the filtered channels.
        this.sortChannelProducts(filteredChannels);
        return filteredChannels;
    };
    /**
     * Get all known installations, including ones that are in progress.
     */
    AppStore.prototype.getInstalledItems = function () {
        return this._installedOrInstallingList.map(function (item) { return item.product; });
    };
    Object.defineProperty(AppStore.prototype, "installingStatus", {
        get: function () {
            var state;
            if (this.isInstallInProgress) {
                state = InstallerState_1.InstallingStatus.Installing;
            }
            else if (this.isUninstallInProgress) {
                state = InstallerState_1.InstallingStatus.Uninstalling;
            }
            else if (this.isModifyInProgress) {
                state = InstallerState_1.InstallingStatus.Modifying;
            }
            else if (this.isRepairInProgress) {
                state = InstallerState_1.InstallingStatus.Repairing;
            }
            else if (this.isUpdateInProgress) {
                state = InstallerState_1.InstallingStatus.Updating;
            }
            else {
                state = InstallerState_1.InstallingStatus.Noop;
            }
            return state;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "uninstallAllProgress", {
        get: function () {
            return this._uninstallAllProgress;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "hostUpdaterStatus", {
        get: function () {
            return this.hostUpdaterStatusEvent.status;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "hostUpdaterStatusDownloadFailedMessage", {
        get: function () {
            if (this.hostUpdaterStatusEvent.status === HostUpdaterStatusChangedEvent_1.HostUpdaterStatus.UpdateDownloadFailed) {
                if (this.hostUpdaterStatusEvent.error) {
                    return this.hostUpdaterStatusEvent.error.message;
                }
            }
            return "";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "updateIsRequired", {
        get: function () {
            return !!this.hostUpdaterStatusEvent.isRequired;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isInstallInProgress", {
        get: function () {
            return this.isOperationInProgressWithState(InstallingState_1.InstallingState.Installing);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isUninstallInProgress", {
        get: function () {
            return this.isOperationInProgressWithState(InstallingState_1.InstallingState.Uninstalling);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isModifyInProgress", {
        get: function () {
            return this.isOperationInProgressWithState(InstallingState_1.InstallingState.Modifying);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isUpdateInProgress", {
        get: function () {
            return this.isOperationInProgressWithState(InstallingState_1.InstallingState.Updating);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "isRepairInProgress", {
        get: function () {
            return this.isOperationInProgressWithState(InstallingState_1.InstallingState.Repairing);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "accessibilityLogStrings", {
        get: function () {
            return this._accessibilityLog;
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.getProductInstallingStatus = function (product, installationPath) {
        var item = this._installedOrInstallingList
            .find(function (storedProduct) { return storedProduct.equals(product, installationPath); });
        if (item) {
            return item.installingState;
        }
        return InstallingState_1.InstallingState.NotInstalling;
    };
    Object.defineProperty(AppStore.prototype, "isOperationInProgress", {
        get: function () {
            return this._installedOrInstallingList
                .some(function (product) { return product.installingState !== InstallingState_1.InstallingState.NotInstalling; });
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.onWindowCloseRequest = function (event) {
        if (this.isOperationInProgress || this.hostInstallState === HostInstallState.Uninstalling) {
            var errorOptions = {
                allowCancel: false,
                cancelButtonText: "",
                errorLink: undefined,
                okButtonText: ResourceStrings_1.ResourceStrings.ok,
                message: [
                    ResourceStrings_1.ResourceStrings.cannotPerformOperationWhileInstalling,
                    "",
                    ResourceStrings_1.ResourceStrings.pleaseWaitUntilOperationFinished
                ],
                title: "",
                errorName: errorNames.WINDOW_CLOSE_ERROR_NAME,
            };
            this._errorStore.show(errorOptions);
            event.preventDefault();
        }
    };
    Object.defineProperty(AppStore.prototype, "isDeepCleaningPreviewInstallations", {
        get: function () {
            return this._isDeepCleaningPreviewInstallations;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "hasPreviewInstallations", {
        get: function () {
            return this._installations.some(Product_1.isPreviewProduct);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "installerStatus", {
        get: function () {
            return this._installerStatus;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppStore.prototype, "productsToLaunch", {
        /**
         * Gets a list of the products that have ProductLaunchState.Pending and are fully installed.
         */
        get: function () {
            var installations = this._installations;
            // Filter to products with pending launch state, and find the product in the installations array.
            return Array.from(this._productLaunchStates.entries())
                .filter(function (entry) { return entry[1] === product_launch_state_1.ProductLaunchState.Pending; })
                .map(function (entry) { return installations.find(function (product) {
                var installPath = entry[0];
                return string_utilities_1.caseInsensitiveAreEqual(product.installationPath, installPath);
            }); })
                .filter(function (product) { return product && product.installState === Product_1.InstallState.Installed; });
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Gets the launch state of a product. Returns ProductLaunchState.None if the launch state is not set.
     * @param product The product to get the launch state of
     */
    AppStore.prototype.productLaunchState = function (product) {
        if (!product) {
            return product_launch_state_1.ProductLaunchState.None;
        }
        var productLaunchState = this._productLaunchStates.get(product.installationPath);
        if (productLaunchState !== null && productLaunchState !== undefined) {
            return productLaunchState;
        }
        return product_launch_state_1.ProductLaunchState.None;
    };
    AppStore.prototype.installedProductsForChannel = function (channelId) {
        return this.installedAndInstallingItems
            .filter(function (product) { return string_utilities_1.caseInsensitiveAreEqual(channelId, product.product.channelId); })
            .map(function (product) { return product.product; });
    };
    AppStore.prototype.createTelemetryContext = function (userRequestedOperation) {
        return {
            initiatedFromCommandLine: this.hasActiveCommandLineOperation,
            numberOfInstalls: this.installedAndInstallingItems.length,
            isFirstInstallExperience: this.isFirstInstallExperience,
            userRequestedOperation: userRequestedOperation,
        };
    };
    /**
     * Determines if the input product matches the conditions to allow auto-launching.
     *
     * @param product The product
     * @returns {boolean} true if the product can be autolaunched.
     */
    AppStore.prototype.canProductAutolaunch = function (product) {
        var validProducts = new Set([
            "Microsoft.VisualStudio.Product.Community",
            "Microsoft.VisualStudio.Product.Professional",
            "Microsoft.VisualStudio.Product.Enterprise",
            "Microsoft.VisualStudio.Product.SQL",
            "Microsoft.VisualStudio.Product.TeamExplorer",
            "Microsoft.VisualStudio.Product.WDExpress",
        ]);
        return product && validProducts.has(product.id);
    };
    AppStore.prototype.launchBannerClosed = function (event) {
        this._isFirstInstallExperience = false;
        this.emitChangedEvent();
    };
    AppStore.prototype.showProduct = function (event) {
        var fromInstalledProducts = true;
        var product = this.findProductSummary(event.channelId, event.productId, fromInstalledProducts) ||
            this.findProductSummary(event.channelId, event.productId, !fromInstalledProducts);
        // only emit the changed event if the product is currently hidden
        if (product && product.hidden) {
            product.hidden = false;
            this.emitChangedEvent();
        }
    };
    AppStore.prototype.isOperationInProgressWithState = function (installingState) {
        return this._installedOrInstallingList
            .some(function (item) { return item.installingState === installingState; });
    };
    AppStore.prototype.registerEvents = function () {
        var register = true;
        this.registerOrUnregisterEvents(register);
    };
    AppStore.prototype.unregisterEvents = function () {
        var unregister = false;
        this.registerOrUnregisterEvents(unregister);
    };
    AppStore.prototype.registerOrUnregisterEvents = function (register) {
        var registerFunction = register
            ? dispatcher_1.dispatcher.register
            : dispatcher_1.dispatcher.unregister;
        this._eventHandlers.forEach(function (handler) {
            registerFunction.call(dispatcher_1.dispatcher, handler.event, handler.callback);
        });
    };
    AppStore.prototype.onProductLaunchStateChangedEvent = function (event) {
        if (!event.product) {
            return;
        }
        this._productLaunchStates.set(event.product.installationPath, event.launchState);
        this.emitChangedEvent();
    };
    AppStore.prototype.onInstallFinished = function (event) {
        var product = event.getProduct();
        var installation = product;
        // Create a cloned install product
        if (!Product_1.isTypeOfInstalledProduct(installation)) {
            installation = new Product_1.InstalledProductSummary(product.id, product.installerId, product.channel, product.name, product.description, product.longDescription, product.version, null, /* installationId */ event.installationPath, event.nickname, event.success ? Product_1.InstallState.Installed : Product_1.InstallState.Unknown, false /* isUpdateAvailable */, product.version, product.icon, product.hidden, event.isRebootRequired, new installed_product_errors_1.InstalledProductErrors([], [], !event.success, event.log), product.releaseNotes);
        }
        // Set the end state for launching the product.
        this.setFinalAutolaunchState(event);
        this.handleOperationFinished(installation, event, ResourceStrings_1.ResourceStrings.installFinished);
    };
    AppStore.prototype.onInstallStarted = function (event) {
        // Only set isFirstInstallExperience on the first install.
        if (!this._firstInstallExperienceSeen
            && this._installedOrInstallingList.length === 0) {
            this._isFirstInstallExperience = true;
            this._firstInstallExperienceSeen = true;
        }
        else {
            this._isFirstInstallExperience = false;
        }
        var product = event.product;
        var installation = new Product_1.InstalledProductSummary(product.id, product.installerId, product.channel, product.name, product.description, product.longDescription, product.version, null, /* installationId */ event.installationPath, event.nickname, Product_1.InstallState.NotInstalled, false /* isUpdateAvailable */, product.version, product.icon, product.hidden, false /* hasPendingReboot */, new installed_product_errors_1.InstalledProductErrors([], [], false, ""), product.releaseNotes);
        if (this._experiments.isExperimentEnabled(experiments_1.ExperimentName.VSWLaunchChkOn)) {
            this._productLaunchStates.set(event.installationPath, product_launch_state_1.ProductLaunchState.LaunchAfterInstall);
        }
        else if (this._experiments.isExperimentEnabled(experiments_1.ExperimentName.VSWLaunchChkOff)) {
            this._productLaunchStates.set(event.installationPath, product_launch_state_1.ProductLaunchState.None);
        }
        this.handleOperationStarted(installation, InstallingState_1.InstallingState.Installing, ResourceStrings_1.ResourceStrings.installing);
    };
    AppStore.prototype.onModifyFinished = function (event) {
        this.handleOperationFinished(event.getProduct(), event, ResourceStrings_1.ResourceStrings.modifyFinished);
    };
    AppStore.prototype.onModifyStarted = function (event) {
        this.handleOperationStarted(event.product, InstallingState_1.InstallingState.Modifying, ResourceStrings_1.ResourceStrings.modifying);
    };
    AppStore.prototype.onUpdateFinished = function (event) {
        this.handleOperationFinished(event.getProduct(), event, ResourceStrings_1.ResourceStrings.updateFinished);
    };
    AppStore.prototype.onUpdateStarted = function (event) {
        this.handleOperationStarted(event.product, InstallingState_1.InstallingState.Updating, ResourceStrings_1.ResourceStrings.updating);
    };
    AppStore.prototype.onRepairFinished = function (event) {
        this.handleOperationFinished(event.getProduct(), event, ResourceStrings_1.ResourceStrings.repairFinished);
    };
    AppStore.prototype.onRepairStarted = function (event) {
        this.handleOperationStarted(event.product, InstallingState_1.InstallingState.Repairing, ResourceStrings_1.ResourceStrings.repairing);
    };
    AppStore.prototype.onUninstallFinished = function (event) {
        this.handleOperationFinished(event.getProduct(), event, ResourceStrings_1.ResourceStrings.uninstallFinished, event.success);
    };
    AppStore.prototype.onUninstallStarted = function (event) {
        this.handleOperationStarted(event.product, InstallingState_1.InstallingState.Uninstalling, ResourceStrings_1.ResourceStrings.uninstalling);
    };
    AppStore.prototype.handleOperationStarted = function (product, installingState, messageToAddSelector) {
        this.setInstallingState(product, installingState, null);
        this.addMessageToAccessibilityLog(messageToAddSelector(product.name));
        this.emitChangedEvent();
    };
    AppStore.prototype.handleOperationFinished = function (product, event, messageToAddSelector, removeInstallation) {
        if (removeInstallation === void 0) { removeInstallation = false; }
        this.clearProgressEvents(event.installationPath);
        this.addMessageToAccessibilityLog(messageToAddSelector(product.name));
        if (removeInstallation) {
            this.removeInstallation(product, event.installationPath);
        }
        else {
            this.setInstallingState(product, InstallingState_1.InstallingState.NotInstalling, event.log);
        }
        if (!this.handleRebootRequired(event)) {
            this.closeIfQuiet(event.success);
        }
        this.emitChangedEvent();
    };
    AppStore.prototype.onCancelRequestedEvent = function (event) {
        var itemIndex = this._installedOrInstallingList.findIndex(function (item) {
            return string_utilities_1.caseInsensitiveAreEqual(item.product.installationPath, event.installationPath);
        });
        var previous = this._installedOrInstallingList[itemIndex];
        this._installedOrInstallingList[itemIndex] = new installed_or_installing_product_1.InstalledOrInstallingProduct(previous.product, InstallingState_1.InstallingState.Cancelling, previous.log);
        this._productLaunchStates.set(event.installationPath, product_launch_state_1.ProductLaunchState.None);
        this.emitChangedEvent();
    };
    AppStore.prototype.closeIfQuiet = function (success) {
        if (success === void 0) { success = true; }
        if (this._argv.quiet || this._argv.passive) {
            var isAppClosurePending = true;
            this._pendingAppClosure = new pending_app_closure_1.PendingAppClosure(success, isAppClosurePending);
        }
    };
    AppStore.prototype.onGetSummariesFinished = function (event) {
        var _this = this;
        if (Array.isArray(event.products)) {
            this.processProductSummaries(event.products);
        }
        if (Array.isArray(event.installations)) {
            this._installationsReceived = true;
            // Update the list
            event.installations.forEach(function (install) {
                _this.setInstallingState(install, null, install.errorDetails.logFilePath);
            });
            // Remove the ones that are no longer supposed to be in the list
            this._installedOrInstallingList = this._installedOrInstallingList.filter(function (record) {
                return event.installations.some(function (installation) {
                    return record.equals(installation, installation.installationPath);
                });
            });
            // Disable first install experience if there are any installations:
            if (event.installations.length > 0) {
                this._firstInstallExperienceSeen = true;
            }
        }
        this._productsParseFailReason = event.channelsParseFailReason;
        this._showReleaseNotesLink = !event.timedOut;
        this.emitChangedEvent();
    };
    AppStore.prototype.processProductSummaries = function (productSummaries) {
        // Create grouped list of ChannelMetadata from ProductSummaryBase:
        this._productsReceived = true;
        var channels = [];
        var tempMap = new Map();
        productSummaries.forEach(function (product) {
            var channelId = product.channelId;
            if (tempMap.has(channelId)) {
                var channel = tempMap.get(channelId);
                channel.products.push(product);
            }
            else {
                var channelInfo = product.channel;
                var channel = new channel_1.Channel(channelInfo, [product]);
                tempMap.set(channelId, channel);
                // also add to channels array
                channels.push(channel);
            }
        });
        // Sort channels so prerelease is last
        this._channels = channels.sort(function (lhs, rhs) {
            if (lhs.isPrerelease === rhs.isPrerelease) {
                return string_utilities_1.caseInsensitiveCompare(lhs.name, rhs.name);
            }
            if (lhs.isPrerelease) {
                return 1;
            }
            if (rhs.isPrerelease) {
                return -1;
            }
            return 0;
        });
        this.sortChannelProducts(this._channels);
    };
    AppStore.prototype.sortChannelProducts = function (channels) {
        // If a product has been targeted on the command line, ensure that it is the first
        // in the list of channel products.
        if (this.commandLineOperationState !== command_line_operation_state_1.CommandLineOperationState.Unspecified) {
            AppStore.makeProductFirstInChannels(channels, this.argv.channelId, this.argv.productId);
        }
    };
    AppStore.prototype.onInstalledProductReceived = function (event) {
        if (event.installedProduct) {
            var install = event.installedProduct;
            this.setInstallingState(install, null, install.errorDetails.logFilePath);
        }
    };
    Object.defineProperty(AppStore.prototype, "_installations", {
        get: function () {
            return this._installedOrInstallingList
                .filter(function (item) { return item.installingState === InstallingState_1.InstallingState.NotInstalling; })
                .map(function (item) { return item.product; });
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.onGetChannelInfoFinished = function (event) {
        var _this = this;
        if (event.channelInfoList) {
            this._channelInfoMap = new Map();
            event.channelInfoList.forEach(function (channelInfo) { return _this._channelInfoMap.set(channelInfo.id, channelInfo); });
            if (this._productsReceived) {
                this._channels.forEach(function (channel) {
                    var channelInfo = _this._channelInfoMap.get(channel.id);
                    if (channelInfo) {
                        channel.setInfo(channelInfo);
                    }
                });
            }
        }
        this._channelInfoReceived = true;
        this.emitChangedEvent();
    };
    AppStore.prototype.handleRebootRequired = function (event) {
        var _this = this;
        if (!event || !event.isRebootRequired) {
            return false;
        }
        var options = {
            title: ResourceStrings_1.ResourceStrings.rebootRequiredTitle,
            message: "",
            allowCancel: true,
            okButtonText: ResourceStrings_1.ResourceStrings.restart,
            errorName: errorNames.REBOOT_REQUIRED_ERROR_NAME,
        };
        switch (event.rebootTiming) {
            case reboot_timing_1.RebootTiming.AfterInstall:
                options.message = ResourceStrings_1.ResourceStrings.postInstallRebootMessage(event.productName);
                options.cancelButtonText = ResourceStrings_1.ResourceStrings.notNow;
                break;
            case reboot_timing_1.RebootTiming.DuringInstall:
                options.message = ResourceStrings_1.ResourceStrings.rebootRequiredMessage;
                options.cancelButtonText = ResourceStrings_1.ResourceStrings.notNow;
                break;
        }
        this._errorStore.show(options)
            .then(function (response) {
            if (response.buttonType === error_message_response_1.ButtonType.DEFAULT_SUBMIT) {
                _this.restart();
            }
        });
        return true;
    };
    AppStore.prototype.onElevationRequired = function (event) {
        var options = {
            title: ResourceStrings_1.ResourceStrings.elevationRequiredTitle,
            message: ResourceStrings_1.ResourceStrings.elevationRequiredMessage,
            allowCancel: false,
            hideSupportLink: true,
            errorName: errorNames.ELEVATION_REQUIRED_ERROR_NAME,
        };
        this._errorStore.show(options);
        this.emitChangedEvent();
    };
    AppStore.prototype.onDeepCleanPreviewInstallationsCompleted = function (event) {
        this._installedOrInstallingList.splice(0);
        this._isDeepCleaningPreviewInstallations = false;
        this.emitChangedEvent();
    };
    AppStore.prototype.onDeepCleanPreviewInstallationsStarted = function (event) {
        this._isDeepCleaningPreviewInstallations = true;
        this.emitChangedEvent();
    };
    AppStore.prototype.onInstallerStatusChangedEvent = function (event) {
        this._installerStatus = event.status;
        this.emitChangedEvent();
    };
    AppStore.prototype.onRemoveChannelStartedEvent = function (event) {
        if (event.channelId) {
            this._channels = this._channels.filter((function (channel) { return channel.id !== event.channelId; }));
        }
        this.emitChangedEvent();
    };
    AppStore.prototype.onRemoveChannelFinishedEvent = function (event) {
        if (Array.isArray(event.products)) {
            this.processProductSummaries(event.products);
        }
        else if (event.channelsParseFailReason) {
            this._productsParseFailReason = event.channelsParseFailReason;
            this._showReleaseNotesLink = !event.timedOut;
        }
        this.emitChangedEvent();
    };
    AppStore.prototype.restart = function () {
        var exitCode;
        if (this.argv.noRestart) {
            exitCode = pending_app_closure_1.PendingAppClosure.exitCodeRebootRequired;
        }
        else {
            exitCode = pending_app_closure_1.PendingAppClosure.exitCodeRebootRequested;
        }
        this._pendingAppClosure = new pending_app_closure_1.PendingAppClosure(true, true, exitCode);
        this.emitChangedEvent();
    };
    AppStore.prototype.onInstallProgressChanged = function (event) {
        /* istanbul ignore next */
        if (event.type === Product_1.ProgressType.Unknown) {
            return;
        }
        var map;
        if (event.type === Product_1.ProgressType.Install) {
            map = this._installProgressByInstallationPath;
        }
        else if (event.type === Product_1.ProgressType.Download) {
            map = this._downloadProgressByInstallationPath;
        }
        if (map) {
            // undefined progress and detail means to forget about progress for this item
            if (!isNaN(event.progress) && event.detail) {
                var key = event.installationPath;
                // If we are uninstalling ourselves the progress isn't for a product,
                // so set the UNINSTALL_SELF_PRODUCT_PROGRESS_KEY value.
                if (this._hostInstallState === HostInstallState.Uninstalling) {
                    key = exports.UNINSTALL_SELF_PRODUCT_PROGRESS_KEY;
                }
                map.set(key, event);
                this.addProgressToAccessibilityLog(event);
            }
            else {
                /* istanbul ignore next */
                if (this._hostInstallState === HostInstallState.Uninstalling) {
                    map.delete(exports.UNINSTALL_SELF_PRODUCT_PROGRESS_KEY);
                }
                else {
                    /* istanbul ignore next */
                    map.delete(event.installationPath);
                }
            }
        }
        else if (event.type === Product_1.ProgressType.UninstallAll) {
            this._uninstallAllProgress = event;
            this.addProgressToAccessibilityLog(event);
        }
        this.emitChangedEvent();
    };
    AppStore.prototype.onOperationFailed = function (event) {
        if (event.error) {
            var options = {
                title: event.title || ResourceStrings_1.ResourceStrings.setupOperationFailed,
                message: [event.error],
                // tslint:disable-next-line: no-bitwise
                allowCancel: (event.dialogMode & error_dialog_mode_1.ErrorDialogMode.Cancel) !== 0,
                errorLink: event.errorLink,
                errorName: event.errorName,
            };
            // if there's OK text, use it
            if (event.okText) {
                options.okButtonText = event.okText;
            }
            this._errorStore.show(options)
                .then(function (response) {
                if (response.buttonType !== error_message_response_1.ButtonType.DEFAULT_SUBMIT) {
                    return;
                }
                // if there's an OK action, invoke it
                if (event.okAction) {
                    event.okAction();
                }
            });
            this.emitChangedEvent();
        }
    };
    AppStore.prototype.onUninstallSelfStatusChanged = function (event) {
        var newHostInstallState;
        if (event.status === UninstallSelfStatusChangedEvent_1.UninstallSelfStatusChangedEvent.INSTALLED_STATUS) {
            /* istanbul ignore next */
            newHostInstallState = HostInstallState.Installed;
        }
        else if (event.status === UninstallSelfStatusChangedEvent_1.UninstallSelfStatusChangedEvent.FAILED_STATUS) {
            newHostInstallState = HostInstallState.UninstallFailed;
        }
        else if (event.status === UninstallSelfStatusChangedEvent_1.UninstallSelfStatusChangedEvent.UNINSTALLING_STATUS) {
            newHostInstallState = HostInstallState.Uninstalling;
        }
        else if (event.status === UninstallSelfStatusChangedEvent_1.UninstallSelfStatusChangedEvent.BLOCKED_BY_RUNNING_INSTANCE_STATUS) {
            newHostInstallState = HostInstallState.UninstallBlockedByRunningInstance;
        }
        this._hostInstallState = newHostInstallState;
    };
    AppStore.prototype.onInstallerNotificationReceived = function (event) {
        this._pendingInstallerNotifications.set(event.installPath, event.message);
        console.log("InstallerNotificationReceivedEvent: " + event.message);
    };
    Object.defineProperty(AppStore.prototype, "_hostInstallState", {
        /* tslint:enable */
        get: function () {
            return this.__hostInstallState;
        },
        set: function (value) {
            if (this.__hostInstallState !== value) {
                this.__hostInstallState = value;
                this.emitChangedEvent();
            }
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.onHostUpdaterStatusChanged = function (event) {
        // Only change the updater state if we are checking for updates.
        if (this.shouldCheckForHostUpdates()) {
            this.hostUpdaterStatusEvent = event;
        }
    };
    Object.defineProperty(AppStore.prototype, "hostUpdaterStatusEvent", {
        /* tslint:enable */
        get: function () {
            return this._hostUpdaterStatusEvent;
        },
        set: function (value) {
            if (!this._hostUpdaterStatusEvent || !this._hostUpdaterStatusEvent.equals(value)) {
                this._hostUpdaterStatusEvent = value;
                this.emitChangedEvent();
            }
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.onWindowStateChangedEvent = function (event) {
        this.windowState = event.windowState;
    };
    Object.defineProperty(AppStore.prototype, "windowState", {
        /* tslint:enable */
        get: function () {
            return this._windowState;
        },
        set: function (value) {
            if (!this._windowState || !this._windowState.equals(value)) {
                this._windowState = value;
                this.emitChangedEvent();
            }
        },
        enumerable: true,
        configurable: true
    });
    AppStore.prototype.beginCommandLineOperation = function () {
        // TODO:  This validation breaks unit tests that raise events.  The problem is that the
        // singleton AppStore created by this module isn't necessarily in the state expected by
        // the unit test, but it will receive events raised by the unit tests.
        //
        // We should refactor AppStore into an Impl class (in a separate module) and write all
        // unit tests against the impl.  When that's done, this module will do nothing but
        // create the singleton.
        //
        // if (this._commandLineOperationState !== CommandLineOperationState.Pending) {
        //     const currentStateName = CommandLineOperationState[this._commandLineOperationState];
        //     throw new Error(`Cannot begin a command line operation if the current operation state is not Pending.` +
        //                     ` The current operation state is ${currentStateName}.`);
        // }
        this._commandLineOperationState = command_line_operation_state_1.CommandLineOperationState.InProgress;
    };
    AppStore.prototype.completeCommandLineOperation = function () {
        // TODO:  This validation breaks unit tests that raise events.  The problem is that the
        // singleton AppStore created by this module isn't necessarily in the state expected by
        // the unit test, but it will receive events raised by the unit tests.
        //
        // We should refactor AppStore into an Impl class (in a separate module) and write all
        // unit tests against the impl.  When that's done, this module will do nothing but
        // create the singleton.
        //
        // if (this._commandLineOperationState !== CommandLineOperationState.InProgress) {
        //     const currentStateName = CommandLineOperationState[this._commandLineOperationState];
        //     throw new Error(`Cannot end a command line operation if the current operation state is not InProgress.` +
        //                     ` The current operation state is ${currentStateName}.`);
        // }
        this._commandLineOperationState = command_line_operation_state_1.CommandLineOperationState.Complete;
    };
    AppStore.prototype.clearProgressEvents = function (installationPath) {
        this._installProgressByInstallationPath.delete(installationPath);
        this._downloadProgressByInstallationPath.delete(installationPath);
    };
    AppStore.prototype.emitChangedEvent = function () {
        this.emit(this.CHANGED_EVENT);
    };
    /**
     * Updates the record in the list matching the install. The properties will be updated with
     * corresponding values from the install.
     * @param {IInstalledProductSummary} install - Used to update the matching record.
     * @param {InstallingState} installingState - The desired installState. If null, then the existing value is kept.
     * @param {string} log - The desired log file path.
     */
    AppStore.prototype.setInstallingState = function (install, installingState, log) {
        var index = this._installedOrInstallingList.findIndex(function (item) { return item.equals(install, install.installationPath); });
        // The item should stay in the list, but the installingState should be updated.
        if (index > -1) {
            var previousItem = this._installedOrInstallingList[index];
            // Checking against null because enum values can fail the falsey check.
            if (installingState === null) {
                installingState = previousItem.installingState;
            }
            var state = new installed_or_installing_product_1.InstalledOrInstallingProduct(install, installingState, log);
            this._installedOrInstallingList[index] = state;
        }
        else {
            // Checking against null because enum values can fail the falsey check.
            if (installingState === null) {
                installingState = InstallingState_1.InstallingState.NotInstalling;
            }
            var state = new installed_or_installing_product_1.InstalledOrInstallingProduct(install, installingState, log);
            this._installedOrInstallingList.push(state);
        }
    };
    AppStore.prototype.addProgressToAccessibilityLog = function (current) {
        var progressText;
        switch (current.type) {
            case Product_1.ProgressType.Download:
                progressText = ResourceStrings_1.ResourceStrings.acquiredProgressWithPackage(current.detail, Math.floor(current.progress * 100));
                this._addDownloadProgress(progressText);
                break;
            case Product_1.ProgressType.Install:
            case Product_1.ProgressType.UninstallAll:
                progressText = ResourceStrings_1.ResourceStrings.appliedProgressWithPackage(current.detail, Math.floor(current.progress * 100));
                this._addInstallProgress(progressText);
                break;
            case Product_1.ProgressType.Unknown:
                console.log("Unhandled ProgressType.Unknown");
                break;
        }
    };
    AppStore.prototype.addMessageToAccessibilityLog = function (message) {
        if (message) {
            this._accessibilityLog.push(message);
            this.emitChangedEvent();
        }
    };
    AppStore.prototype.removeInstallation = function (product, installationPath) {
        var index = this._installedOrInstallingList.findIndex(function (item) { return item.equals(product, installationPath); });
        if (index === -1) {
            return;
        }
        this._installedOrInstallingList.splice(index, 1);
    };
    /**
     * queryStringParser returns all strings. This method will convert strings to their proper types.
     * When a new non-string value is added to the query string add the case in this method to convert it.
     */
    AppStore.prototype.queryOptionsFromQueryStringParts = function (queryStringParts, utilities) {
        var queryOptions = queryStringParts;
        queryOptions.isAnotherInstanceRunning = utilities.ensureBoolean(queryOptions.isAnotherInstanceRunning);
        queryOptions.showDownlevelSkus = utilities.ensureBoolean(queryOptions.showDownlevelSkus);
        return queryOptions;
    };
    AppStore.prototype.createChannelFilter = function () {
        var installedAndInstallingItems = this.getInstalledItems();
        var excludedProducts = [];
        // The user specified a command line operation
        if (this.commandLineOperationState !== command_line_operation_state_1.CommandLineOperationState.Unspecified) {
            var commandLineProduct = this.productSummaryFromCommandLineArgs;
            if (commandLineProduct) {
                // Do not filter out a command line product.
                excludedProducts.push(commandLineProduct);
            }
        }
        if (this._showDownlevelSkus) {
            return this._channelProductFilterFactory.createShowDownlevelFilter(installedAndInstallingItems);
        }
        var applyCrossChannel = true;
        if (applyCrossChannel) {
            return this._channelProductFilterFactory.createCrossChannelFilter(installedAndInstallingItems, excludedProducts);
        }
        return this._channelProductFilterFactory.createPerChannelFilter(installedAndInstallingItems, excludedProducts);
    };
    /**
     * Determines whether we should allow updating the installer.
     *
     * Bug 386763: Silent modifications of an installed product can fail if we detect
     * that an engine update is required.  We don't need to update the engine to modify
     * a product that's already installed, so we can ignore updates.
     *
     */
    AppStore.prototype.shouldCheckForHostUpdates = function () {
        // Always show updates if we are not quiet or passive.
        if (!this._argv.quiet && !this._argv.passive) {
            return true;
        }
        switch (this._argv.command) {
            // don't update for modify, repair, resume or uninstall
            case CommandLine_1.CommandNames.modify:
            case CommandLine_1.CommandNames.repair:
            case CommandLine_1.CommandNames.resume:
            case CommandLine_1.CommandNames.uninstall:
                return false;
            // check for updates for any other command (or for no command)
            default:
                return true;
        }
    };
    /**
     * Sets the final autolaunch state for a product when an install completes.
     *
     * @param event The event received when the install finished, specifying how to transition state.
     */
    AppStore.prototype.setFinalAutolaunchState = function (event) {
        var product = event.getProduct();
        var installationPath = event.installationPath;
        var productLaunchState = this._productLaunchStates.get(installationPath);
        // We transition on 4 conditions. If any of the below are false, we will not launch.
        // 1. The product can autolaunch.
        // 2. The launch state for the product when installation completes is LaunchAfterInstall
        // 3. The install was successful
        // 4. The application is not running quiet or passive
        if (this.canProductAutolaunch(product) &&
            productLaunchState === product_launch_state_1.ProductLaunchState.LaunchAfterInstall &&
            event.success &&
            !this.isQuietOrPassive) {
            this._productLaunchStates.set(installationPath, product_launch_state_1.ProductLaunchState.Pending);
        }
        else {
            this._productLaunchStates.set(installationPath, product_launch_state_1.ProductLaunchState.None);
        }
    };
    return AppStore;
}(events_1.EventEmitter));
exports.AppStore = AppStore;
//# sourceMappingURL=app-store.js.map