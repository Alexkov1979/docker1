/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var events_1 = require("events");
var dispatcher_1 = require("../dispatcher");
var experiments_1 = require("../../lib/experiments/experiments");
var experiments_changed_event_1 = require("../Events/experiments-changed-event");
var ExperimentsStore = (function (_super) {
    __extends(ExperimentsStore, _super);
    function ExperimentsStore() {
        _super.call(this);
        this._experimentIds = [];
        this._experimentsLoaded = false;
        this._events = [
            { event: experiments_changed_event_1.ExperimentsChangedEvent, callback: this.onExperimentsChanged.bind(this) },
        ];
        this.hookEvents();
    }
    Object.defineProperty(ExperimentsStore, "CHANGED_EVENT", {
        get: function () {
            return "CHANGED";
        },
        enumerable: true,
        configurable: true
    });
    ExperimentsStore.prototype.dispose = function () {
        this.hookEvents(true);
    };
    Object.defineProperty(ExperimentsStore.prototype, "experimentsLoaded", {
        get: function () {
            return this._experimentsLoaded;
        },
        enumerable: true,
        configurable: true
    });
    ExperimentsStore.prototype.isExperimentEnabled = function (experiment) {
        return this._experimentIds.indexOf(experiments_1.ExperimentName[experiment]) > -1;
    };
    ExperimentsStore.prototype.onExperimentsChanged = function (ev) {
        this._experimentsLoaded = true;
        this._experimentIds = ev.enabledExperiments;
        this.emit(ExperimentsStore.CHANGED_EVENT);
    };
    ExperimentsStore.prototype.hookEvents = function (unhook) {
        if (unhook === void 0) { unhook = false; }
        var hookMethod;
        if (unhook) {
            hookMethod = dispatcher_1.dispatcher.unregister.bind(dispatcher_1.dispatcher);
        }
        else {
            hookMethod = dispatcher_1.dispatcher.register.bind(dispatcher_1.dispatcher);
        }
        this._events.forEach(function (descriptor) {
            hookMethod(descriptor.event, descriptor.callback);
        });
    };
    return ExperimentsStore;
}(events_1.EventEmitter));
exports.ExperimentsStore = ExperimentsStore;
//# sourceMappingURL=experiments-store.js.map