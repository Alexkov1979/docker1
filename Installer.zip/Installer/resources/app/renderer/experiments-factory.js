/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";
var electron_1 = require("electron");
var experiments_proxy_1 = require("../lib/experiments/ipc/experiments-proxy");
var experiments_ipc_rpc_service_1 = require("../lib/experiments/ipc/experiments-ipc-rpc-service");
var ipc_rpc_1 = require("../lib/ipc/ipc-rpc");
var _experiments;
function getExperiments() {
    if (_experiments) {
        return _experiments;
    }
    var rpc = new ipc_rpc_1.IpcRpc(electron_1.ipcRenderer, experiments_ipc_rpc_service_1.EXPERIMENTS_SERVICE_CHANNEL);
    return _experiments = new experiments_proxy_1.ExperimentsProxy(rpc);
}
exports.getExperiments = getExperiments;
//# sourceMappingURL=experiments-factory.js.map